import type { Table } from 'dexie'
import { db, enqueue, nextSeq, nowIso, upsertLWW, uuid, type NoteRecord, type OutboxRecord, type Place, type PersonRecord, type RelationshipRecord, type GeoLayerRecord, type LocationRecord, type PhotoRecord } from './db'
import { bboxTileUrls, boundaryRing, type Bbox } from './map/config'
import { loadZoneProfile, AREA_HALF_SPAN } from './zone.config'
export { canDeleteRow } from './permissions'

const GAS_URL_KEY = 'gas-url'
const PULL_CURSOR_KEY = 'pull-cursor'

export function getGasUrl(): string {
  return localStorage.getItem(GAS_URL_KEY) || import.meta.env.VITE_GAS_URL || ''
}
export function setGasUrl(url: string) {
  const next = url.trim()
  // new sheet → old pull cursor would skip its rows
  if (next !== localStorage.getItem(GAS_URL_KEY)) void db.config.delete(PULL_CURSOR_KEY)
  localStorage.setItem(GAS_URL_KEY, next)
}

// Deployed Apps Script web app, incl. Workspace form (script.google.com/a/macros/<domain>/s/…)
export const GAS_URL_RE =/^https:\/\/script\.google\.com\/(?:a\/macros\/[\w.-]+|macros)\/s\/[\w-]+\/exec$/

/** Zero-setup link: `?gas=<web app url>` saves the URL on first open, then strips it from the address bar.
 *  `keepInUrl` (in-app browsers): leave it so "Open in browser" hands the param on to Chrome/Safari. */
export function applyGasUrlFromQuery(keepInUrl = false) {
  const params = new URLSearchParams(location.search)
  const gas = params.get('gas')
  if (gas === null) return
  if (GAS_URL_RE.test(gas.trim())) setGasUrl(gas)
  else console.warn('ignored ?gas= — not an Apps Script /exec URL')
  if (keepInUrl) return
  params.delete('gas')
  const qs = params.toString()
  history.replaceState(history.state, '', location.pathname + (qs ? '?' + qs : '') + location.hash)
}
export function getStudentId(): string {
  let id = localStorage.getItem('student-id')
  if (!id) { id = 's-' + uuid().slice(0, 8); localStorage.setItem('student-id', id) }
  return id
}
export function getStudentName(): string {
  return localStorage.getItem('student-name') || ''
}
export function setStudentIdentity(name: string, zone: string, house: string) {
  localStorage.setItem('student-name', name)
  localStorage.setItem('student-zone', zone)
  localStorage.setItem('student-house', house)
}
export function getStudentIdentity() {
  return {
    studentId: getStudentId(),
    name: getStudentName(),
    zone: localStorage.getItem('student-zone') || '',
    house: localStorage.getItem('student-house') || '',
  }
}

export function getStudentRole(): string {
  return localStorage.getItem('student-role') || 'student'
}

export function setStudentRole(role: string) {
  localStorage.setItem('student-role', role)
}

// ---- Image compression (max 1024px, JPEG q=0.65, EXIF-aware) ----------------
export async function compressImage(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' })
  try {
    const MAX = 1024
    const scale = Math.min(1, MAX / Math.max(bitmap.width, bitmap.height))
    const w = Math.round(bitmap.width * scale), h = Math.round(bitmap.height * scale)
    const c = document.createElement('canvas')
    c.width = w; c.height = h
    const g = c.getContext('2d')!
    g.drawImage(bitmap, 0, 0, w, h)
    return c.toDataURL('image/jpeg', 0.65)
  } finally {
    bitmap.close()
  }
}

// ---- Batch Push: text first, photos separate (decoupled) -----------------
// Text records (Places, Notes, Persons, Geo) flush in one lightweight POST.
// Photos push separately so image base64 blobs never block or crash text sync.

const TEXT_KINDS = ['place', 'note', 'person', 'relationship', 'geoLayer', 'location'] as const
const ALL_KINDS = [...TEXT_KINDS, 'photo'] as const
type QueueKind = (typeof ALL_KINDS)[number]

let isFlushing = false
const POST_TIMEOUT_MS = 90_000 // GAS script lock waits up to 30 s, a photo upload adds Drive time

export async function flush(): Promise<{ sent: number; failed: number; error?: string }> {
  if (isFlushing) return { sent: 0, failed: 0 }
  isFlushing = true
  const url = getGasUrl()
  if (!url) { isFlushing = false; return { sent: 0, failed: 0, error: 'ยังไม่ได้ตั้งค่า Web App URL' } }
  if (!navigator.onLine) { isFlushing = false; return { sent: 0, failed: 0, error: 'ออฟไลน์อยู่' } }

  try {
    const outbox = await db.outbox.orderBy('seq').toArray()
    if (outbox.length === 0) return { sent: 0, failed: 0 }

    // ---- phase 1: text payload (lightweight, no images) -----------------------
    let textSent = 0
    const textOutbox = outbox.filter((o) => (TEXT_KINDS as readonly string[]).includes(o.kind))
    if (textOutbox.length > 0) {
      const chunkSize = 35
      for (let start = 0; start < textOutbox.length; start += chunkSize) {
        const chunk = textOutbox.slice(start, start + chunkSize)
        const batch: Record<string, unknown[]> = { place: [], note: [], person: [], relationship: [], geoLayer: [], location: [] }
        // every edit enqueues its own outbox row → same record may appear many times; send it once
        for (const item of chunk) {
          const ids = (batch as Record<string, unknown[]>)[item.kind]
          if (!ids.includes(item.refId)) ids.push(item.refId)
        }

        const payload: Record<string, unknown> = { type: 'batch', updatedBy: getStudentId(), ts: nowIso() }
        for (const kind of TEXT_KINDS) {
          const ids = batch[kind] as string[]
          payload[kind] = ids.length ? await collectKind(kind, ids) : []
        }

        try {
          await postJson(url, payload)
          await db.outbox.bulkDelete(chunk.map((o) => o.id))
          textSent += chunk.length
        } catch (err) {
          return { sent: textSent, failed: outbox.length - textSent, error: mapSyncError(err as Error) }
        }
      }
    }

    // ---- phase 2: photo payload (images, pushed separately) -------------------
    const photoOutbox = outbox.filter((o) => o.kind === 'photo')
    let photoOk = 0, photoFail = 0
    if (photoOutbox.length > 0) {
      const rows = await db.photos.bulkGet(photoOutbox.map((o) => o.refId))
      const byId = new Map(rows.filter((p): p is PhotoRecord => !!p).map((p) => [p.id, p]))
      // push photos one by one (each ~80–120 KB — manageable individually, but batching
      // them risks blowing the GAS URLFetch payload limit ~50 MB per request on the GAS side)
      const doneIds = new Set<string>()
      for (const p of byId.values()) {
        // already uploaded and nothing new to send → just drain the outbox row
        if (p.synced) { doneIds.add(p.id); continue }
        try {
          const json = await postJson(url, {
            type: 'photo',
            id: p.id,
            placeId: p.placeId,
            // re-sends of an uploaded photo (e.g. a delete) carry metadata only
            base64: p.fileId ? undefined : p.base64,
            createdBy: p.createdBy ?? getStudentId(),
            createdAt: p.createdAt,
            updatedAt: p.updatedAt ?? p.createdAt,
            deletedAt: p.deletedAt,
            updatedBy: getStudentId(),
            ts: nowIso(),
          })
          const sentStamp = p.updatedAt ?? p.createdAt
          await db.photos.where('id').equals(p.id).modify((r) => {
            if (typeof json.url === 'string') r.url = json.url
            if (typeof json.fileId === 'string') r.fileId = json.fileId
            // edited (e.g. deleted) while in flight → stay unsynced; its own outbox row re-sends it
            if ((r.updatedAt ?? r.createdAt) === sentStamp) r.synced = 1
          })
          doneIds.add(p.id)
          photoOk++
        } catch { photoFail++ }
      }
      // Drain outbox rows for uploaded photos and for photos that no longer exist locally
      await db.outbox.bulkDelete(
        photoOutbox.filter((o) => doneIds.has(o.refId) || !byId.has(o.refId)).map((o) => o.id)
      )
      if (photoFail > 0) {
        return { sent: textSent + photoOk, failed: photoFail, error: `ส่งรูปไม่ผ่าน ${photoFail} รูป` }
      }
    }

    return { sent: textSent + photoOk, failed: 0 }
  } finally {
    isFlushing = false
  }
}

/** POST JSON to GAS. GAS answers HTTP 200 even on lock timeout / script error,
 *  so the body's `ok` flag is the real success signal. Throws unless ok === true. */
async function postJson(url: string, payload: unknown): Promise<Record<string, unknown>> {
  // A stalled upload (weak field signal) must not hold flush() open forever: isFlushing would
  // stay true and every later text sync would be skipped. Give up after POST_TIMEOUT_MS; the
  // outbox row stays queued and the next flush retries it.
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), POST_TIMEOUT_MS)
  let res: Response
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payload),
      signal: ctl.signal,
    })
  } catch (err) {
    throw ctl.signal.aborted ? new Error('Failed to fetch (timeout)') : err
  } finally {
    clearTimeout(timer)
  }
  if (!res.ok) throw new Error(`GAS ${res.status}`)
  let json: Record<string, unknown>
  try {
    json = await res.json() as Record<string, unknown>
  } catch {
    throw new Error('bad json response from GAS')
  }
  if (json.ok !== true) throw new Error(typeof json.error === 'string' ? json.error : 'GAS error')
  return json
}

async function collectKind(kind: OutboxRecord['kind'], ids: string[]): Promise<unknown[]> {
  switch (kind) {
    case 'place': return db.places.bulkGet(ids).then((rs) => rs.filter(Boolean))
    case 'note': return db.notes.bulkGet(ids).then((rs) => rs.filter(Boolean))
    case 'person': return db.persons.bulkGet(ids).then((rs) => rs.filter(Boolean))
    case 'relationship': return db.relationships.bulkGet(ids).then((rs) => rs.filter(Boolean))
    case 'geoLayer': return db.geoLayers.bulkGet(ids).then((rs) => rs.filter(Boolean))
    case 'location': return db.locations.bulkGet(ids).then((rs) => rs.filter(Boolean))
    case 'photo': return db.photos.bulkGet(ids).then((rs) => rs.filter(Boolean))
  }
}

// ---- Manual Pull (no polling) ----------------------------------------------
export async function pull(): Promise<{ applied: number; skipped: number; error?: string }> {
  const url = getGasUrl()
  if (!url) return { applied: 0, skipped: 0, error: 'ยังไม่ได้ตั้งค่า Web App URL' }
  if (!navigator.onLine) return { applied: 0, skipped: 0, error: 'ออฟไลน์อยู่' }

  const cursor = (await db.config.get(PULL_CURSOR_KEY))?.value || '1970-01-01T00:00:00.000Z'

  try {
    const res = await fetch(`${url}?action=pull&since=${encodeURIComponent(cursor)}`, {
      method: 'GET',
    })
    if (!res.ok) throw new Error(`GAS ${res.status}`)
    const data = await res.json() as Record<string, unknown>
    if (data.error) throw new Error(String(data.error))

    const outboxItems = await db.outbox.toArray()
    const pendingIds = new Set(outboxItems.map((o) => o.refId))

    let applied = 0, skipped = 0
    for (const kind of ['places', 'notes', 'persons', 'relationships', 'geoLayers', 'locations'] as const) {
      const rows = Array.isArray(data[kind]) ? (data[kind] as Record<string, unknown>[]) : []
      for (const raw of rows) {
        const r = normalizeRow(raw)
        if (!r.id || pendingIds.has(r.id as string)) { skipped++; continue }
        const res2 = await applyPulled(kind, r as never)
        if (res2 === 'applied') applied++; else skipped++
      }
    }
    // Photos: metadata + Drive URL only. Never clobber a local row that still holds base64.
    const photoRows = Array.isArray(data.photos) ? (data.photos as Record<string, unknown>[]) : []
    for (const raw of photoRows) {
      const r = normalizeRow(raw) as Partial<PhotoRecord>
      if (!r.id || !r.placeId || pendingIds.has(r.id)) { skipped++; continue }
      const cur = await db.photos.get(r.id)
      const incomingStamp = r.updatedAt ?? r.createdAt ?? ''
      const curStamp = cur ? (cur.updatedAt ?? cur.createdAt) : ''
      if (cur && (curStamp > incomingStamp || (curStamp === incomingStamp && cur.url))) { skipped++; continue }
      await db.photos.put({
        ...cur,
        id: r.id,
        placeId: r.placeId,
        url: r.url ?? cur?.url,
        fileId: r.fileId ?? cur?.fileId,
        createdBy: r.createdBy ?? cur?.createdBy,
        createdAt: r.createdAt ?? cur?.createdAt ?? nowIso(),
        updatedAt: r.updatedAt ?? cur?.updatedAt,
        deletedAt: r.deletedAt,
        synced: 1,
      })
      applied++
    }
    // Apply own role from Roles sheet → localStorage
    if (data.roles && Array.isArray(data.roles)) {
      const myId = getStudentId()
      const myRoleEntry = (data.roles as { studentId?: string; role?: string }[]).find((r) => r.studentId === myId)
      if (myRoleEntry && myRoleEntry.role) {
        setStudentRole(myRoleEntry.role)
      }
    }
    // Cursor = server clock (rows are filtered by server-stamped syncedAt), so
    // client clock skew and late offline pushes can't slip past it.
    const serverTime = typeof data.serverTime === 'string' ? data.serverTime : nowIso()
    await db.config.put({ key: PULL_CURSOR_KEY, value: serverTime })
    return { applied, skipped }
  } catch (err) {
    return { applied: 0, skipped: 0, error: mapSyncError(err as Error) }
  }
}

// Sheets hands back numbers as strings (text-formatted columns), blanks as '',
// and server-only columns (recordType, syncedAt). Coerce to the Dexie shapes.
const NUMERIC_FIELDS = ['lat', 'lng', 'age', 'accuracy']
const FLAG_FIELDS = ['isCaution', 'isDeceased', 'isBedridden']
const SERVER_ONLY_FIELDS = ['recordType', 'syncedAt']

function normalizeRow(raw: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(raw)) {
    if (SERVER_ONLY_FIELDS.includes(k)) continue
    if (v === '' || v === null || v === undefined) continue // optional field absent
    if (NUMERIC_FIELDS.includes(k)) {
      const n = Number(v)
      if (Number.isFinite(n)) out[k] = n
    } else if (FLAG_FIELDS.includes(k)) {
      out[k] = v === true || v === 1 || v === '1' || v === 'TRUE' || v === 'true' ? 1 : 0
    } else {
      out[k] = typeof v === 'string' ? v : String(v)
    }
  }
  for (const f of FLAG_FIELDS) if (f in raw && !(f in out)) out[f] = 0
  return out
}

async function applyPulled(kind: 'places' | 'notes' | 'persons' | 'relationships' | 'geoLayers' | 'locations', row: Place & NoteRecord & PersonRecord & RelationshipRecord & GeoLayerRecord & LocationRecord): Promise<'applied' | 'skipped'> {
  switch (kind) {
    case 'places': return upsertLWW(db.places, row as Place)
    case 'notes': return upsertLWW(db.notes, row as NoteRecord)
    case 'persons': return upsertLWW(db.persons, row as PersonRecord)
    case 'relationships': return upsertLWW(db.relationships, row as RelationshipRecord)
    case 'geoLayers': return upsertLWW(db.geoLayers, row as GeoLayerRecord)
    case 'locations': {
      // locations are append-only heartbeat; just put
      await db.locations.put(row as LocationRecord)
      return 'applied'
    }
  }
}

// ---- Convenience wrappers (write to Dexie + enqueue outbox) -----------------
export async function savePlace(p: Place): Promise<void> {
  p.updatedAt = nowIso()
  if (!p.id) p.id = uuid()
  if (!p.createdAt) p.createdAt = p.updatedAt
  if (!p.createdBy) p.createdBy = getStudentId()
  await db.places.put(p)
  await enqueue('place', p.id)
  if (navigator.onLine && getGasUrl()) void flush()
}

export async function saveNote(n: NoteRecord): Promise<void> {
  n.updatedAt = nowIso()
  if (!n.id) n.id = uuid()
  if (!n.createdAt) n.createdAt = n.updatedAt
  if (!n.author) n.author = getStudentId()
  await db.notes.put(n)
  await enqueue('note', n.id)
  if (navigator.onLine && getGasUrl()) void flush()
}

export async function savePerson(p: PersonRecord): Promise<void> {
  p.updatedAt = nowIso()
  if (!p.id) p.id = uuid()
  if (!p.createdAt) p.createdAt = p.updatedAt
  await db.persons.put(p)
  await enqueue('person', p.id)
  if (navigator.onLine && getGasUrl()) void flush()
}

export async function saveRelationship(r: RelationshipRecord): Promise<void> {
  r.updatedAt = nowIso()
  if (!r.id) r.id = uuid()
  if (!r.createdAt) r.createdAt = r.updatedAt
  await db.relationships.put(r)
  await enqueue('relationship', r.id)
  if (navigator.onLine && getGasUrl()) void flush()
}

export async function saveGeoLayer(g: GeoLayerRecord): Promise<void> {
  g.updatedAt = nowIso()
  if (!g.id) g.id = uuid()
  if (!g.createdAt) g.createdAt = g.updatedAt
  if (!g.createdBy) g.createdBy = getStudentId()
  await db.geoLayers.put(g)
  await enqueue('geoLayer', g.id)
  if (navigator.onLine && getGasUrl()) void flush()
}

/** Bulk saveGeoLayer for footprint imports (~1,000+ roofs): one transaction, one flush. */
export async function saveGeoLayers(gs: GeoLayerRecord[]): Promise<void> {
  if (gs.length === 0) return
  const now = nowIso(), me = getStudentId()
  for (const g of gs) {
    g.updatedAt = now
    if (!g.id) g.id = uuid()
    if (!g.createdAt) g.createdAt = now
    if (!g.createdBy) g.createdBy = me
  }
  await db.transaction('rw', db.geoLayers, db.outbox, async () => {
    await db.geoLayers.bulkPut(gs)
    await db.outbox.bulkPut(gs.map((g) => ({ id: uuid(), kind: 'geoLayer' as const, refId: g.id, seq: nextSeq() })))
  })
  if (navigator.onLine && getGasUrl()) void flush()
}

/** Save a new village boundary; it replaces (soft-deletes) every older live boundary. */
export async function saveBoundary(g: GeoLayerRecord): Promise<void> {
  const old = (await db.geoLayers.where('kind').equals('boundary').toArray()).filter((b) => !b.deletedAt && b.id !== g.id)
  await saveGeoLayer(g) // new one first: a failure mid-way never leaves zero boundaries
  for (const o of old) await softDelete('geoLayers', o.id)
}

export async function saveLocation(loc: Omit<LocationRecord, 'id' | 'ts'>): Promise<void> {
  const row: LocationRecord = { ...loc, id: uuid(), ts: nowIso() }
  await db.locations.put(row)
  await enqueue('location', row.id)
}

export async function savePhotoBlob(placeId: string, base64: string): Promise<string> {
  const id = uuid()
  const ts = nowIso()
  const row: PhotoRecord = { id, placeId, base64, createdBy: getStudentId(), createdAt: ts, updatedAt: ts, synced: 0 }
  await db.photos.put(row)
  await enqueue('photo', id)
  if (navigator.onLine && getGasUrl()) void flush()
  return id
}

/** Soft-delete one photo (same shape as the photo branch of softDeletePlace). */
export async function softDeletePhoto(id: string): Promise<void> {
  const p = await db.photos.get(id)
  if (!p || p.deletedAt) return
  const ts = nowIso()
  await db.photos.put({ ...p, deletedAt: ts, updatedAt: ts, synced: 0 })
  await enqueue('photo', id)
  if (navigator.onLine && getGasUrl()) void flush()
}

export async function softDelete(table: 'places' | 'notes' | 'persons' | 'relationships' | 'geoLayers', id: string): Promise<void> {
  const tbl = db[table]
  const row = await tbl.get(id)
  if (!row) return
  await tbl.put({ ...row, deletedAt: nowIso(), updatedAt: nowIso() } as never)
  await enqueue(OUTBOX_KIND[table], id)
  if (navigator.onLine && getGasUrl()) void flush()
}

const OUTBOX_KIND = {
  places: 'place', notes: 'note', persons: 'person', relationships: 'relationship', geoLayers: 'geoLayer',
} as const

/** Soft-delete a person and every relationship that references them (either side). */
export async function softDeletePerson(id: string): Promise<void> {
  const ts = nowIso()
  await db.transaction('rw', [db.persons, db.relationships, db.outbox], async () => {
    const person = await db.persons.get(id)
    if (!person) return
    await markDeleted('persons', [person], ts)
    const rels = await relsTouching([id])
    await markDeleted('relationships', rels, ts)
  })
  if (navigator.onLine && getGasUrl()) void flush()
}

/** Soft-delete a place and its child notes, photos, persons, and their relationships. */
export async function softDeletePlace(id: string): Promise<void> {
  const ts = nowIso()
  await db.transaction('rw', [db.places, db.notes, db.photos, db.persons, db.relationships, db.outbox], async () => {
    const place = await db.places.get(id)
    if (!place) return
    await markDeleted('places', [place], ts)
    await markDeleted('notes', await db.notes.where('placeId').equals(id).toArray(), ts)
    const persons = await db.persons.where('placeId').equals(id).toArray()
    await markDeleted('persons', persons, ts)
    const byPlace = await db.relationships.where('placeId').equals(id).toArray()
    const byPerson = await relsTouching(persons.map((p) => p.id))
    const rels = new Map([...byPlace, ...byPerson].map((r) => [r.id, r]))
    await markDeleted('relationships', [...rels.values()], ts)
    const photos = (await db.photos.where('placeId').equals(id).toArray()).filter((p) => !p.deletedAt)
    for (const p of photos) {
      await db.photos.put({ ...p, deletedAt: ts, updatedAt: ts, synced: 0 })
      await enqueue('photo', p.id)
    }
  })
  if (navigator.onLine && getGasUrl()) void flush()
}

async function relsTouching(personIds: string[]): Promise<RelationshipRecord[]> {
  if (!personIds.length) return []
  const [a, b] = await Promise.all([
    db.relationships.where('person1Id').anyOf(personIds).toArray(),
    db.relationships.where('person2Id').anyOf(personIds).toArray(),
  ])
  return [...new Map([...a, ...b].map((r) => [r.id, r])).values()]
}

/** Mark rows deleted (skipping already-deleted ones) and enqueue each. Call inside a transaction. */
async function markDeleted<T extends { id: string; deletedAt?: string; updatedAt: string }>(
  table: 'places' | 'notes' | 'persons' | 'relationships',
  rows: T[],
  ts: string,
): Promise<void> {
  const live = rows.filter((r) => !r.deletedAt)
  if (!live.length) return
  await (db[table] as unknown as Table<T, string>).bulkPut(live.map((r) => ({ ...r, deletedAt: ts, updatedAt: ts })))
  for (const r of live) await enqueue(OUTBOX_KIND[table], r.id)
}

export async function pendingCount(): Promise<number> {
  return db.outbox.count()
}

export async function clearLocalData(): Promise<void> {
  await db.places.clear()
  await db.notes.clear()
  await db.photos.clear()
  await db.persons.clear()
  await db.relationships.clear()
  await db.geoLayers.clear()
  await db.locations.clear()
  await db.outbox.clear()
  // geoLayers also held the roster + zone profile: drop the cursor so the next pull brings them back
  await db.config.delete(PULL_CURSOR_KEY)
  // keep gas-url, identity (localStorage)
}

// ---- Active work area -----------------------------------------------------------
// Centre + bbox of this zone's village: drawn boundary → zone profile centre ± AREA_HALF_SPAN.
// Drives the offline tile download and the "ศูนย์กลางหมู่บ้าน" fly-back.
export async function activeArea(): Promise<{ center: [number, number]; bbox: Bbox }> {
  const live = (await db.geoLayers.where('kind').equals('boundary').toArray()).filter((b) => !b.deletedAt)
  live.sort((a, b) => (b.updatedAt ?? '').localeCompare(a.updatedAt ?? ''))
  // a hand-edited Sheet row can carry non-numeric coordinates: NaN here would poison bbox + centre
  const ring = live[0] ? boundaryRing(live[0].geojson)?.filter((p) => Number.isFinite(p[0]) && Number.isFinite(p[1])) : null
  if (ring && ring.length >= 3) {
    const lats = ring.map((p) => p[0]), lngs = ring.map((p) => p[1])
    const bbox = { s: Math.min(...lats), n: Math.max(...lats), w: Math.min(...lngs), e: Math.max(...lngs) }
    return { center: [(bbox.s + bbox.n) / 2, (bbox.w + bbox.e) / 2], bbox }
  }
  const { center } = await loadZoneProfile()
  const [lat, lng] = center, d = AREA_HALF_SPAN
  return { center, bbox: { s: lat - d, n: lat + d, w: lng - d, e: lng + d } }
}

// ---- Tile pre-caching ---------------------------------------------------------
// Same cache name as the SW's runtime Esri route, and URLs built from the same template
// Leaflet uses, so the SW's CacheFirst serves these byte-for-byte offline.
const TILE_CACHE = 'esri-tiles'
const MAX_TILES = 4000 // guard against a huge boundary; SW route maxEntries is above this
type TileResult = { ok: boolean; cached: number; total: number }
let tileJob: Promise<TileResult> | null = null
const tileListeners = new Set<(pct: number) => void>()

export const isCachingTiles = () => tileJob !== null

/** Download z15–18 satellite tiles for the active area. A second call while running joins the same job. */
export function cacheTiles(onProgress: (pct: number) => void): Promise<TileResult> {
  tileListeners.add(onProgress)
  if (!tileJob) tileJob = runTileJob().finally(() => { tileJob = null; tileListeners.clear() })
  return tileJob
}

async function runTileJob(): Promise<TileResult> {
  if (!('caches' in window)) return { ok: false, cached: 0, total: 0 }
  const urls = bboxTileUrls((await activeArea()).bbox, 15, 18)
  const total = urls.length
  if (total > MAX_TILES) return { ok: false, cached: 0, total }
  const cache = await caches.open(TILE_CACHE)
  let next = 0, done = 0, cached = 0

  const fetchTile = async (url: string): Promise<boolean> => {
    // Tiles already viewed are in the cache as opaque (no-cors <img>) responses; a cors fetch
    // of those through the SW's CacheFirst would reject, so count a cache hit as done.
    if (await cache.match(url)) return true
    try {
      const res = await fetch(url, { mode: 'cors' })
      if (!res.ok) return false
      await cache.put(url, res)
      return true
    } catch {
      return false
    }
  }

  const worker = async () => {
    while (next < urls.length) {
      if (await fetchTile(urls[next++])) cached++
      done++
      const pct = Math.round((done / total) * 100)
      tileListeners.forEach((l) => l(pct))
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker))
  return { ok: cached === total, cached, total }
}

/** How many of the active area's z15–18 tiles are stored offline. */
export async function cachedTileCount(): Promise<{ cached: number; total: number }> {
  if (!('caches' in window)) return { cached: 0, total: 0 }
  const urls = bboxTileUrls((await activeArea()).bbox, 15, 18)
  const keys = new Set((await (await caches.open(TILE_CACHE)).keys()).map((r) => r.url))
  return { cached: urls.filter((u) => keys.has(u)).length, total: urls.length }
}

// ---- Error mapping ------------------------------------------------------------
function mapSyncError(err: Error): string {
  const msg = err.message || ''
  if (msg.includes('404') || msg.includes('Failed to fetch')) {
    return 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ — ตรวจสอบเน็ตหรือ URL ในหน้าตั้งค่า'
  }
  if (msg.includes('Lock timeout') || msg.includes('503')) {
    return 'มีผู้ใช้งานส่งข้อมูลพร้อมกันจำนวนมาก — กรุณารอ 1 นาทีแล้วลองใหม่'
  }
  if (msg.includes('bad json')) {
    return 'รูปแบบข้อมูลผิดพลาด — กรุณาตรวจโค้ด Code.gs'
  }
  return msg
}