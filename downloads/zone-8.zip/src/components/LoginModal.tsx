import React, { useEffect, useRef, useState } from 'react'
import { findStudent, useRoster, MIN_ID_LENGTH, type Student } from '../roster'
import { getGasUrl, pull } from '../sync'
import { loadZoneProfile } from '../zone.config'

interface Props {
  onClose: () => void
  onLogin?: (student: Student) => void
}

const STUDENT_KEYS = ['student-id', 'student-name', 'student-zone', 'student-house', 'student-role']

/** Store the identity on this device. Everyone starts as 'student'; the next pull applies the real role. */
export async function signIn(student: Student) {
  const { zone } = await loadZoneProfile()
  localStorage.setItem('student-id', student.id)
  localStorage.setItem('student-name', student.name)
  localStorage.setItem('student-zone', zone ? String(zone) : '')
  localStorage.setItem('student-house', student.house ?? '')
  localStorage.setItem('student-role', 'student')
}

/** The roster lives in the zone's sheet: pull it once when this device has none yet.
 *  Returns true while that pull is running. */
export function useRosterPull(roster: Student[] | undefined, gasUrl: string): boolean {
  const [fetching, setFetching] = useState(false)
  const tried = useRef(false)
  useEffect(() => {
    if (tried.current || !roster || roster.length > 0 || !gasUrl || !navigator.onLine) return
    tried.current = true
    setFetching(true)
    void pull().finally(() => setFetching(false))
  }, [roster, gasUrl])
  return fetching
}

export const LoginModal: React.FC<Props> = ({ onClose, onLogin }) => {
  const roster = useRoster()
  const fetching = useRosterPull(roster, getGasUrl())
  const [id, setId] = useState('')
  const [name, setName] = useState('')
  const [student, setStudent] = useState<Student | undefined>()
  const [searched, setSearched] = useState(false)

  const idOk = id.replace(/[\s-]/g, '').length >= MIN_ID_LENGTH
  // no roster on this device (zone lead has not imported one yet) → type id + name by hand
  const manual = !!roster && roster.length === 0 && !fetching

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (manual) {
      if (name.trim()) setStudent({ id: id.trim(), name: name.trim() })
    } else {
      setStudent(findStudent(roster ?? [], id))
    }
    setSearched(true)
  }

  const confirmLogin = async () => {
    if (!student) return
    await signIn(student)
    onLogin?.(student)
    onClose()
  }

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl">
        <h2 className="mb-1 text-xl font-semibold text-gray-900">เข้าสู่ระบบ</h2>
        <p className="mb-4 text-sm text-gray-500">กรอกรหัสนักศึกษาเพื่อเริ่มใช้งาน</p>

        {fetching && <p className="mb-3 rounded-lg bg-blue-50 p-3 text-sm text-blue-700">กำลังดึงรายชื่อของเขต…</p>}
        {manual && (
          <p className="mb-3 rounded-lg bg-amber-50 p-3 text-sm text-amber-800">
            ยังไม่มีรายชื่อของเขตในเครื่องนี้ — กรอกรหัสและชื่อของคุณเองได้เลย
          </p>
        )}

        <form onSubmit={handleSearch}>
          <label className="block">
            <span className="text-sm font-medium text-gray-700">รหัสนักศึกษา</span>
            <input
              autoFocus
              inputMode="numeric"
              value={id}
              onChange={(e) => { setId(e.target.value); setSearched(false); setStudent(undefined) }}
              placeholder="เช่น 650000001"
              className="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2.5 text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </label>
          {manual && (
            <label className="mt-3 block">
              <span className="text-sm font-medium text-gray-700">ชื่อ-นามสกุล</span>
              <input
                value={name}
                onChange={(e) => { setName(e.target.value); setSearched(false); setStudent(undefined) }}
                className="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2.5 text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </label>
          )}
          <button
            type="submit"
            disabled={!idOk || fetching || (manual && !name.trim())}
            className="mt-3 w-full rounded-full bg-blue-600 py-2.5 text-sm font-medium text-white disabled:opacity-40"
          >
            ตรวจสอบรหัส
          </button>
        </form>

        {searched && !student && (
          <p className="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">
            ไม่พบรหัสนักศึกษาในรายชื่อของเขต — ตรวจสอบรหัส หรือแจ้งหัวหน้าเขต
          </p>
        )}

        {student && (
          <div className="mt-4 rounded-xl bg-blue-50 p-4 text-sm text-gray-800">
            <p className="font-semibold">{student.name}</p>
            <p>รหัส: {student.id}</p>
            {student.house && <p>บ้านพักหลังที่: {student.house}</p>}
            <button onClick={() => { void confirmLogin() }} className="mt-3 w-full rounded-full bg-emerald-600 py-2.5 font-medium text-white">
              ใช่ นี่คือฉัน
            </button>
          </div>
        )}

        <button
          onClick={onClose}
          className="mt-3 w-full rounded-full border border-gray-300 py-2.5 text-sm text-gray-700"
        >
          ยกเลิก
        </button>
      </div>
    </div>
  )
}

export function clearStudentIdentity() {
  STUDENT_KEYS.forEach((key) => localStorage.removeItem(key))
}
