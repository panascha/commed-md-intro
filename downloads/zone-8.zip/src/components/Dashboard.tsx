import React from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, type Place, type NoteRecord, type PersonRecord } from '../db';
import { placeStatus, ROOF_STATUS } from '../map/roofStatus';
import { ChartColumn, Users, Building, FileText } from 'lucide-react';

interface Props {
  onOpenPlace: (placeId: string) => void;
}

const chip = 'flex items-center gap-2 rounded-xl bg-white px-4 py-3 shadow-sm border border-gray-100';

export function Dashboard({ onOpenPlace }: Props) {
  const places = useLiveQuery(() => db.places.toArray(), []) as Place[] | undefined;
  const notes = useLiveQuery(() => db.notes.toArray(), []) as NoteRecord[] | undefined;
  const persons = useLiveQuery(() => db.persons.toArray(), []) as PersonRecord[] | undefined;
  const outbox = useLiveQuery(() => db.outbox.count(), []);

  const stats = React.useMemo(() => {
    if (!places) return null;
    const counts: Record<string, number> = {};
    for (const p of places) {
      const s = placeStatus(p, notes ?? [], persons ?? []);
      const key = s ?? 'unvisited';
      counts[key] = (counts[key] ?? 0) + 1;
    }
    return counts;
  }, [places, notes, persons]);

  if (!places) return <div className="p-4 text-sm text-gray-500">กำลังโหลด...</div>;

  return (
    <div className="flex flex-col gap-4 p-4">
      <h1 className="text-xl font-bold text-gray-900">ภาพรวมหมู่บ้าน</h1>

      <div className="grid grid-cols-2 gap-3">
        <div className={chip}>
          <Building size={20} className="text-blue-600" />
          <div>
            <div className="text-lg font-bold text-gray-900">{places.length}</div>
            <div className="text-xs text-gray-500">หลังคาเรือนทั้งหมด</div>
          </div>
        </div>
        <div className={chip}>
          <Users size={20} className="text-purple-600" />
          <div>
            <div className="text-lg font-bold text-gray-900">{persons?.length ?? 0}</div>
            <div className="text-xs text-gray-500">คนในระบบ</div>
          </div>
        </div>
        <div className={chip}>
          <FileText size={20} className="text-emerald-600" />
          <div>
            <div className="text-lg font-bold text-gray-900">{notes?.length ?? 0}</div>
            <div className="text-xs text-gray-500">บันทึก</div>
          </div>
        </div>
        <div className={chip}>
          <ChartColumn size={20} className="text-amber-600" />
          <div>
            <div className="text-lg font-bold text-gray-900">{outbox ?? 0}</div>
            <div className="text-xs text-gray-500">รอส่ง</div>
          </div>
        </div>
      </div>

      {stats && (
        <div className="space-y-2">
          <h2 className="text-sm font-medium text-gray-700">สถานะการเก็บข้อมูล</h2>
          {Object.entries(ROOF_STATUS).map(([key, { label, color }]) => (
            <div key={key} className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-full" style={{ backgroundColor: color }} />
              <span className="flex-1 text-sm text-gray-700">{label}</span>
              <span className="text-sm font-medium text-gray-900">{stats[key] ?? 0}</span>
            </div>
          ))}
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full border border-gray-300 bg-gray-100" />
            <span className="flex-1 text-sm text-gray-700">ยังไม่เริ่ม</span>
            <span className="text-sm font-medium text-gray-900">{stats.unvisited ?? 0}</span>
          </div>
        </div>
      )}

      <div className="space-y-2">
        <h2 className="text-sm font-medium text-gray-700">บ้านล่าสุด</h2>
        {places.slice(-5).reverse().map((p) => (
          <button
            key={p.id}
            onClick={() => onOpenPlace(p.id)}
            className="flex w-full items-center gap-3 rounded-lg border border-gray-200 px-3 py-2 text-left hover:bg-gray-50"
          >
            <span className="text-sm font-medium text-gray-900">
              {p.houseNo ? `บ้านเลขที่ ${p.houseNo}` : p.tag === 'house' ? 'บ้าน' : p.tag}
            </span>
            <span className="ml-auto text-xs text-gray-400">{new Date(p.updatedAt).toLocaleDateString('th')}</span>
          </button>
        ))}
        {places.length === 0 && (
          <p className="text-sm text-gray-400">ยังไม่มีข้อมูล กดที่หลังคาบนแผนที่เพื่อเริ่ม</p>
        )}
      </div>
    </div>
  );
}
