import React, { useState } from 'react';
import { Settings, X } from 'lucide-react';
import { getGasUrl, setGasUrl, getStudentIdentity, setStudentIdentity, getStudentId, pull, saveGeoLayer, clearLocalData, pendingCount } from '../sync'
import { OfflineTilesButton } from './OfflineTilesButton'
import { InstallAppButton } from './InstallAppButton'
import { clearStudentIdentity } from './LoginModal'
import { useRoster, parseRoster, readRosterFile, rosterRow, type RosterParse } from '../roster'
import { useZoneProfile } from '../zone.config'
import { canManageZone, canAssignRoles } from '../permissions'
import { db, type Place, type NoteRecord, type PersonRecord, type RelationshipRecord, type GeoLayerRecord, type LocationRecord, type PhotoRecord } from '../db';
import { xlsx, type Sheet } from '../xlsx';
import { download, confirmAction } from '../ui/common';

interface Props {
  onClose: () => void;
  onUserChanged?: () => void;
  onLogout?: () => void;
  onOpenZoneSetup?: () => void;
}

/** One settings group: titled card. */
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-2.5 rounded-xl border border-gray-100 bg-gray-50/60 p-3.5">
      <h4 className="text-sm font-semibold text-gray-800">{title}</h4>
      {children}
    </section>
  );
}

export const SettingsPanel: React.FC<Props> = ({ onClose, onUserChanged, onLogout, onOpenZoneSetup }) => {
  const [url, setUrl] = useState(getGasUrl());
  const { name, zone, house } = getStudentIdentity();
  const [sName, setSName] = useState(name);
  const [sHouse, setSHouse] = useState(house);
  const [saved, setSaved] = useState(false);
  const canManageRoles = canAssignRoles();
  const canManage = canManageZone();
  const profile = useZoneProfile();
  const zoneLabel = profile?.zone ? String(profile.zone) : zone;
  const roster = useRoster() ?? [];
  const [rosterText, setRosterText] = useState('');
  const [rosterMsg, setRosterMsg] = useState('');
  const rosterDraft: RosterParse | null = rosterText.trim() ? parseRoster(rosterText) : null;
  const [roleAssigning, setRoleAssigning] = useState<Record<string, string>>({});
  const [pulling, setPulling] = useState(false);
  const [pullMsg, setPullMsg] = useState('');

  const handleSave = () => {
    setGasUrl(url);
    setStudentIdentity(sName, zoneLabel, sHouse);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleRosterFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // same file can be picked again
    if (file) setRosterText(await readRosterFile(file));
  };

  const handleSaveRoster = async () => {
    if (!rosterDraft || rosterDraft.error) return;
    try {
      await saveGeoLayer(rosterRow(rosterDraft.students));
      setRosterMsg(`บันทึกรายชื่อ ${rosterDraft.students.length} คนแล้ว — กด "ส่งข้อมูล" เพื่อให้เพื่อนในเขตได้รับ`);
      setRosterText('');
    } catch {
      setRosterMsg('บันทึกรายชื่อไม่สำเร็จ');
    }
  };

  const handleLogout = () => {
    clearStudentIdentity();
    onClose();
    onLogout?.();
  };

  const handleAssignRole = async (targetId: string, targetName: string, role: string) => {
    const base = getGasUrl();
    if (!base) return;
    try {
      const res = await fetch(base, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          type: 'role',
          studentId: targetId,
          name: targetName,
          role,
          updatedBy: getStudentId(),
          ts: new Date().toISOString(),
        }),
      });
      const j = await res.json() as { ok?: boolean };
      if (j.ok) setRoleAssigning((r) => ({ ...r, [targetId]: role })); // GAS refuses non-developer/coreteam senders
    } catch { /* offline — ignore, retry manually later */ }
  };

  const handleExportExcel = async () => {
    const places = await db.places.toArray();
    const persons = await db.persons.toArray();

    const placesSheet: Sheet = {
      name: 'Places',
      rows: [
        ['id', 'buildingId', 'houseNo', 'tag', 'status', 'note', 'lat', 'lng', 'createdBy', 'createdAt', 'updatedAt'],
        ...places.filter((p) => !p.deletedAt).map((p) => [
          p.id, p.buildingId ?? '', p.houseNo ?? '', p.tag, p.status, p.note ?? '', p.lat, p.lng, p.createdBy, p.createdAt, p.updatedAt,
        ]),
      ],
    };
    const personsSheet: Sheet = {
      name: 'Persons',
      rows: [
        ['id', 'placeId', 'name', 'nickname', 'gender', 'age', 'isDeceased', 'isBedridden', 'chronic', 'createdAt', 'updatedAt'],
        ...persons.filter((p) => !p.deletedAt).map((p) => [
          p.id, p.placeId, p.name, p.nickname ?? '', p.gender, p.age ?? '', p.isDeceased, p.isBedridden, p.chronic ?? '', p.createdAt, p.updatedAt,
        ]),
      ],
    };

    const blob = xlsx([placesSheet, personsSheet]);
    download(blob, `commed-os-export-${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleBackupJson = async () => {
    const allData: Record<string, unknown[]> = {};
    for (const table of [
      db.places, db.notes, db.persons, db.relationships, db.geoLayers, db.locations, db.outbox, db.config, db.photos
    ]) {
      allData[table.name] = await table.toArray();
    }
    const blob = new Blob([JSON.stringify(allData, null, 2)], { type: 'application/json' });
    download(blob, `commed-v3-backup-${new Date().toISOString().slice(0, 10)}.json`);
  };

  const handlePull = async () => {
    setPulling(true);
    setPullMsg('');
    try {
      const res = await pull();
      setPullMsg(res.error ? `ผิดพลาด: ${res.error}` : `ดึงแล้ว · ใหม่ ${res.applied} · ข้าม ${res.skipped}`);
    } finally {
      setPulling(false);
    }
  };

  // Admin: drop every local table, then re-fetch the whole sheet. Unsent outbox rows are lost.
  const handleHardPull = async () => {
    if (!getGasUrl()) { setPullMsg('ผิดพลาด: ยังไม่ได้ตั้งค่า Web App URL'); return; }
    if (!navigator.onLine) { setPullMsg('ผิดพลาด: ออฟไลน์อยู่ ต้องมีอินเทอร์เน็ตก่อนล้างข้อมูล'); return; }
    const unsent = await pendingCount();
    const ok = await confirmAction(
      'ล้างข้อมูลในเครื่องแล้วดึงใหม่',
      unsent > 0
        ? `มี ${unsent} รายการที่ยังไม่ได้ส่งเข้า Google Sheet รายการเหล่านี้จะหายถาวร ควรกด "ส่งข้อมูล" ก่อน ข้อมูลอื่นในเครื่องนี้จะถูกลบแล้วดึงใหม่จาก Google Sheet ทั้งหมด`
        : 'ข้อมูลในเครื่องนี้จะถูกลบ แล้วดึงใหม่จาก Google Sheet ทั้งหมด (ไม่มีรายการค้างส่ง)',
      unsent > 0 ? `ล้างและทิ้ง ${unsent} รายการ` : 'ล้างและดึงใหม่',
      true,
    );
    if (!ok) return;
    setPulling(true);
    setPullMsg('');
    try {
      await clearLocalData();
      const res = await pull();
      setPullMsg(res.error ? `ล้างแล้ว แต่ดึงใหม่ไม่สำเร็จ: ${res.error} · กด "ดึงข้อมูลล่าสุด" อีกครั้ง` : `ล้างและดึงใหม่แล้ว · ${res.applied} รายการ`);
    } finally {
      setPulling(false);
    }
  };

  const input = 'mt-1 block w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500';
  const fieldLabel = 'text-xs font-medium text-gray-600';

  return (
    <div className="fixed inset-0 z-[1400] flex items-center justify-center bg-black/50 p-4 sm:p-6">
      <div className="flex max-h-[85vh] w-full max-w-md flex-col rounded-2xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-gray-100 px-5 py-3">
          <h3 className="text-lg font-medium text-gray-900">ตั้งค่า</h3>
          <button
            onClick={() => { onClose(); onUserChanged?.(); }}
            className="grid h-9 w-9 place-items-center rounded-full bg-gray-100 text-gray-600"
            aria-label="ปิด"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          <Section title="⚙️ การเชื่อมต่อระบบ (Sync & Connectivity)">
            <label className="block">
              <span className={fieldLabel}>GAS Web App URL</span>
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://script.google.com/macros/s/..."
                className={input}
              />
            </label>
            <OfflineTilesButton />
            <div>
              <button
                onClick={handlePull}
                disabled={pulling}
                className="w-full rounded-xl border border-blue-200 bg-blue-50 py-2.5 text-sm font-medium text-blue-700 hover:bg-blue-100 disabled:opacity-50"
              >
                {pulling ? 'กำลังดึงข้อมูล...' : '📥 ดึงข้อมูลล่าสุด (Pull Sync)'}
              </button>
              {canManage && (
                <button
                  onClick={() => { void handleHardPull(); }}
                  disabled={pulling}
                  className="mt-2 w-full rounded-xl border border-red-200 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 disabled:opacity-50"
                >
                  🧹 ล้างข้อมูลในเครื่องแล้วดึงใหม่ (Hard Pull)
                </button>
              )}
              {pullMsg && <p className="mt-1 text-xs text-gray-500">{pullMsg}</p>}
            </div>
          </Section>

          <Section title="👤 ข้อมูลนักศึกษา (Student Profile)">
            <label className="block">
              <span className={fieldLabel}>ชื่อ-นามสกุล</span>
              <input type="text" value={sName} onChange={(e) => setSName(e.target.value)} className={input} />
            </label>
            <div className="grid grid-cols-2 items-end gap-2">
              <label className="block">
                <span className={fieldLabel}>เขต (Zone)</span>
                <input type="text" value={zoneLabel} readOnly className={`${input} bg-gray-100 text-gray-500`} />
              </label>
              <label className="block">
                <span className={fieldLabel}>บ้านพักหลังที่ (House No.)</span>
                <input type="text" value={sHouse} onChange={(e) => setSHouse(e.target.value)} className={input} />
              </label>
            </div>
          </Section>

          {canManage && onOpenZoneSetup && (
            <Section title="🧭 พื้นที่และการสำรวจ">
              <button
                onClick={onOpenZoneSetup}
                className="w-full rounded-xl border border-gray-300 bg-white py-2.5 text-sm text-gray-700 hover:bg-gray-50"
              >
                เปิดหน้าตั้งค่าพื้นที่
              </button>
            </Section>
          )}

          {canManage && (
            <Section title="📋 รายชื่อนักศึกษา (Roster)">
              <p className="text-xs text-gray-600">
                ตอนนี้มีรายชื่อ <b>{roster.length}</b> คน · คัดลอกตารางจาก Excel / Google Sheet แล้ววางด้านล่าง
                เรียงคอลัมน์เป็น <b>รหัส · ชื่อ-นามสกุล · บ้านพักหลังที่</b> (หลังที่ไม่ใส่ก็ได้)
              </p>
              <textarea
                value={rosterText}
                onChange={(e) => { setRosterText(e.target.value); setRosterMsg(''); }}
                rows={4}
                placeholder={'650000001-0\tนาย ตัวอย่าง ใจดี\t1'}
                className={`${input} font-mono text-xs`}
              />
              <label className="block cursor-pointer rounded-xl border border-gray-300 bg-white py-2.5 text-center text-sm text-gray-700 hover:bg-gray-50">
                📂 หรือเลือกไฟล์ (.csv / .json / .txt)
                <input type="file" accept=".csv,.json,.txt,.tsv" className="hidden" onChange={(e) => { void handleRosterFile(e); }} />
              </label>
              {rosterDraft?.error && <p className="text-xs text-red-600">{rosterDraft.error}</p>}
              {rosterDraft && !rosterDraft.error && (
                <div className="rounded-lg bg-white px-3 py-2 text-xs text-gray-700">
                  <p className="font-medium">
                    อ่านได้ {rosterDraft.students.length} คน
                    {rosterDraft.skipped > 0 && ` · ข้าม ${rosterDraft.skipped} แถวที่ไม่มีรหัสหรือชื่อ`}
                  </p>
                  {rosterDraft.students.slice(0, 5).map((s) => (
                    <p key={s.id} className="truncate">{s.id} · {s.name}{s.house ? ` · หลังที่ ${s.house}` : ''}</p>
                  ))}
                  {rosterDraft.students.length > 5 && <p>…</p>}
                </div>
              )}
              <button
                onClick={() => { void handleSaveRoster(); }}
                disabled={!rosterDraft || !!rosterDraft.error}
                className="w-full rounded-xl bg-blue-600 py-2.5 text-sm font-medium text-white disabled:opacity-40"
              >
                บันทึกรายชื่อ{roster.length > 0 ? ' (แทนที่รายชื่อเดิม)' : ''}
              </button>
              {rosterMsg && <p className="text-xs text-emerald-700">{rosterMsg}</p>}
            </Section>
          )}

          {canManageRoles && roster.length > 0 && (
            <Section title="👥 จัดการสิทธิ์สมาชิก (Role Management)">
              <div className="space-y-2">
                {roster.map((s) => (
                  <div key={s.id} className="flex items-center gap-3 rounded-lg bg-white px-3 py-2">
                    <span className="flex-1 text-sm font-medium text-gray-800">{s.name}</span>
                    <select
                      value={roleAssigning[s.id] || 'student'}
                      onChange={(e) => handleAssignRole(s.id, s.name, e.target.value)}
                      className="rounded-md border border-gray-300 px-2 py-1 text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="student">Student</option>
                      <option value="coreteam">Coreteam</option>
                      <option value="developer">Developer</option>
                    </select>
                  </div>
                ))}
              </div>
            </Section>
          )}

          <Section title="📊 การส่งออกข้อมูล (Export & Backup)">
            <button
              onClick={handleExportExcel}
              className="w-full rounded-xl border border-emerald-300 bg-emerald-50 py-2.5 text-sm font-medium text-emerald-800 hover:bg-emerald-100"
            >
              📥 Export Excel (.xlsx)
            </button>
            <button
              onClick={handleBackupJson}
              className="w-full rounded-xl border border-gray-300 bg-white py-2.5 text-sm text-gray-700 hover:bg-gray-50"
            >
              💾 สำรองข้อมูลทั้งหมด (JSON)
            </button>
          </Section>

          <Section title="🚪 บัญชีผู้ใช้งาน (Account)">
            <InstallAppButton variant="settings" />
            <button
              onClick={handleLogout}
              className="w-full rounded-xl border border-red-200 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50"
            >
              เปลี่ยนผู้ใช้งาน / ออกจากระบบ
            </button>
          </Section>
        </div>

        <div className="flex gap-2 border-t border-gray-100 px-5 py-3">
          <button
            onClick={onClose}
            className="flex-1 rounded-full border border-gray-300 py-3 text-sm text-gray-700 hover:bg-gray-50"
          >
            ยกเลิก
          </button>
          <button
            onClick={handleSave}
            className="flex-1 rounded-full bg-blue-600 py-3 text-sm font-medium text-white hover:bg-blue-700"
          >
            {saved ? 'บันทึกแล้ว ✓' : 'บันทึก'}
          </button>
        </div>
      </div>
    </div>
  );
};
