import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, uuid, nowIso, type PersonRecord, type RelationshipRecord, type Gender, type RelationType } from '../db';
import { savePerson, saveRelationship, softDelete, softDeletePerson, canDeleteRow } from '../sync';
import { FullScreen, confirmAction } from '../ui/common';
import { Network, Plus, Trash2 } from 'lucide-react';

interface Props {
  placeId: string;
  onClose: () => void;
  onGenogram: () => void;
  /** Receives the guarded close (dirty-state confirm) so Android Back can use it. */
  closeRef?: React.MutableRefObject<(() => void) | null>;
}

const GENDER_LABEL: Record<Gender, string> = { m: 'ชาย', f: 'หญิง', o: 'อื่นๆ' };

/** Person editor row: inline edit, save on blur. */
function PersonRow({ person, onDelete, canDelete }: { person: PersonRecord; onDelete: () => void; canDelete: boolean }) {
  const [name, setName] = useState(person.name);
  const [nickname, setNickname] = useState(person.nickname ?? '');
  const [age, setAge] = useState(person.age?.toString() ?? '');
  const [gender, setGender] = useState<Gender>(person.gender);
  const [isDeceased, setIsDeceased] = useState(person.isDeceased === 1);
  const [isBedridden, setIsBedridden] = useState(person.isBedridden === 1);

  // Select/checkbox handlers pass their new value in `next`: setState is async, so
  // reading state right after setX() would save the PREVIOUS value.
  const commit = async (next: Partial<{ gender: Gender; isDeceased: boolean; isBedridden: boolean }> = {}) => {
    const ageNum = age.trim() === '' ? undefined : Number(age);
    await savePerson({
      ...person,
      name: name.trim() || person.name,
      nickname: nickname.trim() || undefined,
      age: ageNum !== undefined && Number.isFinite(ageNum) && ageNum >= 0 ? ageNum : undefined,
      gender: next.gender ?? gender,
      isDeceased: (next.isDeceased ?? isDeceased) ? 1 : 0,
      isBedridden: (next.isBedridden ?? isBedridden) ? 1 : 0,
    });
  };

  return (
    <div className="space-y-2 rounded-lg border border-gray-200 p-3">
      <div className="flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} onBlur={() => void commit()} placeholder="ชื่อ-นามสกุล"
          className="flex-1 rounded-md border border-gray-200 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        {canDelete && (
          <button onClick={onDelete} className="rounded-md bg-red-50 px-2 text-red-600" aria-label="ลบคนนี้">
            <Trash2 size={16} />
          </button>
        )}
      </div>
      <div className="flex gap-2">
        <input value={nickname} onChange={(e) => setNickname(e.target.value)} onBlur={() => void commit()} placeholder="ชื่อเล่น"
          className="flex-1 rounded-md border border-gray-200 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        <input value={age} onChange={(e) => setAge(e.target.value)} onBlur={() => void commit()} placeholder="อายุ" type="number"
          className="w-20 rounded-md border border-gray-200 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
        <select value={gender} onChange={(e) => { const g = e.target.value as Gender; setGender(g); void commit({ gender: g }); }}
          className="rounded-md border border-gray-200 px-2 py-1.5 text-sm">
          {Object.entries(GENDER_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </div>
      <div className="flex gap-4 text-sm text-gray-700">
        <label className="flex items-center gap-1.5">
          <input type="checkbox" checked={isDeceased} onChange={(e) => { const v = e.target.checked; setIsDeceased(v); void commit({ isDeceased: v }); }} className="h-4 w-4 rounded border-gray-300" />
          เสียชีวิต
        </label>
        <label className="flex items-center gap-1.5">
          <input type="checkbox" checked={isBedridden} onChange={(e) => { const v = e.target.checked; setIsBedridden(v); void commit({ isBedridden: v }); }} className="h-4 w-4 rounded border-gray-300" />
          ติดเตียง
        </label>
      </div>
    </div>
  );
}

const RELATION_LABELS: Record<RelationType, string> = {
  spouse: 'คู่สมรส',
  parent_child: 'พ่อแม่-ลูก',
  sibling: 'พี่น้อง',
  other: 'อื่นๆ',
};

export function PersonSheet({ placeId, onClose, onGenogram, closeRef }: Props) {
  const persons = useLiveQuery(
    () => db.persons.where('placeId').equals(placeId).toArray(),
    [placeId]
  ) ?? [];
  const relationships = useLiveQuery(
    () => db.relationships.where('placeId').equals(placeId).toArray(),
    [placeId]
  ) ?? [];
  const place = useLiveQuery(() => db.places.get(placeId), [placeId]);

  // relationship creator state
  const [relPerson1, setRelPerson1] = useState('');
  const [relPerson2, setRelPerson2] = useState('');
  const [relType, setRelType] = useState<RelationType>('spouse');

  const handleAdd = async () => {
    const p: PersonRecord = {
      id: uuid(),
      placeId,
      name: 'สมาชิกใหม่',
      gender: 'm',
      isDeceased: 0,
      isBedridden: 0,
      createdAt: nowIso(),
      updatedAt: nowIso(),
    };
    await savePerson(p);
  };

  const handleDelete = async (id: string) => {
    const ok = await confirmAction('ลบสมาชิก', 'ลบข้อมูลคนนี้จากบ้านหรือไม่? ความสัมพันธ์ของคนนี้จะถูกลบด้วย', 'ลบ', true);
    if (!ok) return;
    await softDeletePerson(id);
  };

  const handleAddRelationship = async () => {
    if (!relPerson1 || !relPerson2 || relPerson1 === relPerson2) return;
    // a pull can delete a picked person while this sheet is open: never save a link to a missing id
    if (![relPerson1, relPerson2].every((id) => activePersons.some((p) => p.id === id))) {
      setRelPerson1('');
      setRelPerson2('');
      return;
    }
    const r: RelationshipRecord = {
      id: uuid(),
      placeId,
      person1Id: relPerson1,
      person2Id: relPerson2,
      relationType: relType,
      createdAt: nowIso(),
      updatedAt: nowIso(),
    };
    await saveRelationship(r);
    setRelPerson1('');
    setRelPerson2('');
  };

  const handleDeleteRelationship = async (id: string) => {
    await softDelete('relationships', id);
  };

  // Member fields save on blur, so blur first to commit the field being typed in; only a
  // half-picked relationship is still unsaved after that.
  const requestClose = async () => {
    (document.activeElement as HTMLElement | null)?.blur?.();
    const dirty = relPerson1 !== '' || relPerson2 !== '';
    if (dirty && !(await confirmAction('ยังไม่ได้บันทึก', 'มีข้อมูลที่ยังไม่ได้บันทึก ต้องการปิดหน้านี้หรือไม่?', 'ปิดโดยไม่บันทึก', true, 'กลับไปแก้ไข'))) return;
    onClose();
  };
  if (closeRef) closeRef.current = () => void requestClose();

  const activeRels = relationships.filter((r) => !r.deletedAt);
  const activePersons = persons.filter((p) => !p.deletedAt);

  return (
    <FullScreen
      title="สมาชิกในบ้าน"
      onClose={() => void requestClose()}
      footer={
        <div className="flex gap-2">
          <button onClick={() => void requestClose()} className="flex-1 rounded-full border border-gray-300 py-3 text-sm text-gray-700">
            ปิด
          </button>
          <button
            onClick={onGenogram}
            disabled={activePersons.length === 0}
            className="flex flex-1 items-center justify-center gap-2 rounded-full bg-purple-600 py-3 text-sm font-medium text-white disabled:opacity-50"
          >
            <Network size={16} />
            แผนภูมิครอบครัว
          </button>
        </div>
      }
    >
      <div className="space-y-3">
        {activePersons.map((p) => (
          <PersonRow key={p.id} person={p} onDelete={() => handleDelete(p.id)} canDelete={canDeleteRow(place?.createdBy)} />
        ))}
        <button
          onClick={handleAdd}
          className="flex w-full items-center justify-center gap-2 rounded-lg border-2 border-dashed border-gray-300 py-3 text-sm text-gray-600 hover:border-blue-400"
        >
          <Plus size={16} />
          เพิ่มสมาชิก
        </button>
        {activePersons.length === 0 && (
          <p className="text-center text-sm text-gray-400">ยังไม่มีข้อมูลสมาชิกในบ้านนี้</p>
        )}

        {/* ---- relationship creator (only if 2+ persons) ---- */}
        {activePersons.length >= 2 && (
          <div className="border-t border-gray-100 pt-3">
            <h4 className="mb-2 text-sm font-medium text-gray-700">ความสัมพันธ์</h4>
            {activeRels.length > 0 && (
              <div className="mb-3 space-y-1">
                {activeRels.map((r) => {
                  const p1 = activePersons.find((p) => p.id === r.person1Id);
                  const p2 = activePersons.find((p) => p.id === r.person2Id);
                  return (
                    <div key={r.id} className="flex items-center justify-between rounded-md bg-gray-50 px-3 py-1.5 text-sm">
                      <span>
                        {p1?.name ?? '?'} — {RELATION_LABELS[r.relationType] ?? r.relationType} — {p2?.name ?? '?'}
                      </span>
                      {canDeleteRow(place?.createdBy) && (
                        <button onClick={() => handleDeleteRelationship(r.id)}
                          className="ml-2 text-red-500 hover:text-red-700" aria-label="ลบความสัมพันธ์">
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            <div className="grid grid-cols-3 gap-2">
              <select value={relPerson1} onChange={(e) => setRelPerson1(e.target.value)}
                className="rounded-md border border-gray-200 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">คนที่ 1</option>
                {activePersons.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <select value={relType} onChange={(e) => setRelType(e.target.value as RelationType)}
                className="rounded-md border border-gray-200 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                {Object.entries(RELATION_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
              <select value={relPerson2} onChange={(e) => setRelPerson2(e.target.value)}
                className="rounded-md border border-gray-200 px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">คนที่ 2</option>
                {activePersons.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <button onClick={handleAddRelationship} disabled={!relPerson1 || !relPerson2 || relPerson1 === relPerson2}
              className="mt-2 w-full rounded-full bg-blue-600 py-2 text-sm font-medium text-white disabled:opacity-50">
              เพิ่มความสัมพันธ์
            </button>
          </div>
        )}
      </div>
    </FullScreen>
  );
}