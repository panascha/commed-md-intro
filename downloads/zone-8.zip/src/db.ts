import Dexie, { type Table } from 'dexie'

// ---- Record shapes (all syncable, flat — backend is a single Google Sheet per type) ----

export type RoofStatus = 'unvisited' | 'prepared' | 'in_progress' | 'completed' | 'family_study'
export type PlaceTag = 'house' | 'lodging' | 'shop' | 'temple' | 'school' | 'community_hall' | 'bus_stop' | 'other'
export type Gender = 'm' | 'f' | 'o'
export type RelationType = 'spouse' | 'parent_child' | 'sibling' | 'other'
// 'roster' / 'zoneProfile' are not map layers: one fixed-id row each, JSON in `geojson`,
// carried by the Geo_Layers sheet so every phone of the zone receives them (see roster.ts, zone.ts).
export type GeoKind = 'boundary' | 'customBuilding' | 'roster' | 'zoneProfile'

export interface Place {
  id: string
  buildingId?: string // buildings.geojson feature id = plus code (if tapped an existing roof)
  houseNo?: string
  tag: PlaceTag
  status: RoofStatus
  note?: string // handover caution (v2: also the main text field)
  lat: number
  lng: number
  createdBy: string // local student id
  createdAt: string // ISO
  updatedAt: string
  deletedAt?: string
}

export interface NoteRecord {
  id: string
  placeId: string
  body: string
  isCaution: 0 | 1 // handover caution flag
  author: string
  createdAt: string
  updatedAt: string
  deletedAt?: string
}

export interface PhotoRecord {
  id: string
  placeId: string
  base64?: string // already downscaled client-side, max ~120 KB; absent on photos pulled from other devices
  url?: string // Drive thumbnail URL, set after upload / on pull
  fileId?: string
  createdBy?: string
  createdAt: string
  updatedAt?: string
  deletedAt?: string
  synced: 0 | 1 // gas-handled separately (Drive upload)
}

export interface PersonRecord {
  id: string
  placeId: string
  name: string
  nickname?: string
  gender: Gender
  age?: number
  isDeceased: 0 | 1
  isBedridden: 0 | 1
  chronic?: string // comma-separated disease names
  createdAt: string
  updatedAt: string
  deletedAt?: string
}

export interface RelationshipRecord {
  id: string
  placeId: string
  person1Id: string
  person2Id: string
  relationType: RelationType
  relationLabel?: string // free text for 'other'
  createdAt: string
  updatedAt: string
  deletedAt?: string
}

export interface GeoLayerRecord {
  id: string
  name: string
  kind: GeoKind
  geojson: string // stringified GeoJSON Polygon/LineString
  createdBy: string
  createdAt: string
  updatedAt: string
  deletedAt?: string
}

export interface LocationRecord {
  id: string
  studentId: string
  studentName?: string
  zone?: string
  house?: string
  lat: number
  lng: number
  accuracy: number
  ts: string // ISO
}

export interface OutboxRecord {
  id: string
  kind: 'place' | 'note' | 'person' | 'relationship' | 'geoLayer' | 'location' | 'photo'
  refId: string
  seq: number // insertion order, sync must respect this
}

export interface ConfigRecord {
  key: string
  value: string
}

class CommedOSDemoDB extends Dexie {
  places!: Table<Place, string>
  notes!: Table<NoteRecord, string>
  photos!: Table<PhotoRecord, string>
  persons!: Table<PersonRecord, string>
  relationships!: Table<RelationshipRecord, string>
  geoLayers!: Table<GeoLayerRecord, string>
  locations!: Table<LocationRecord, string>
  outbox!: Table<OutboxRecord, string>
  config!: Table<ConfigRecord, string>

  constructor() {
    super('commed-os-demo-v3')
    this.version(1).stores({
      places: 'id, buildingId, status, updatedAt',
      notes: 'id, placeId, isCaution, updatedAt',
      photos: 'id, placeId, synced',
      persons: 'id, placeId, updatedAt',
      relationships: 'id, placeId, person1Id, person2Id, updatedAt',
      geoLayers: 'id, kind, updatedAt',
      locations: 'id, studentId, ts',
      outbox: 'id, seq, kind',
      config: 'key',
    })
  }
}

export const db = new CommedOSDemoDB()

export function uuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    return (([1e7] as any) + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c: number) =>
      (c ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))).toString(16)
    )
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

let seqCounter = Date.now()
export function nextSeq(): number {
  seqCounter += 1
  return seqCounter
}

/** Deterministic place id for a roof, so two phones tapping the same roof offline
 *  create the same row instead of two competing ones. One place per roof. */
export function placeIdForBuilding(buildingId: string): string {
  return 'bld-' + buildingId
}

export function nowIso(): string {
  return new Date().toISOString()
}

// Helpers
export async function alive<T extends { deletedAt?: string }>(rows: T[]): Promise<T[]> {
  return rows.filter((r) => !r.deletedAt)
}

/** Upsert by id, respecting updatedAt last-writer-wins. */
export async function upsertLWW<T extends { id: string; updatedAt: string }>(
  table: Table<T, string>,
  incoming: T
): Promise<'applied' | 'skipped'> {
  const cur = await table.get(incoming.id)
  // equal stamp = same write (pull windows overlap on purpose) → nothing to do
  if (cur && cur.updatedAt >= incoming.updatedAt) return 'skipped'
  await table.put(incoming)
  return 'applied'
}

export async function enqueue(kind: OutboxRecord['kind'], refId: string) {
  await db.outbox.put({ id: uuid(), kind, refId, seq: nextSeq() })
}

export async function setConfig(key: string, value: string) {
  await db.config.put({ key, value })
}
export async function getConfig(key: string): Promise<string | null> {
  const r = await db.config.get(key)
  return r?.value ?? null
}
