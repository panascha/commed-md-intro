import React, { useState, useEffect, useRef } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, type Place } from '../db';
import { Search, X } from 'lucide-react';
import { TAGS } from './PlaceSheet';

interface Props {
  onSelect: (place: Place) => void;
  onClose: () => void;
}

function fuzzyMatch(q: string, s: string): number {
  const a = q.toLowerCase();
  const b = s.toLowerCase();
  if (b.includes(a)) return 0;
  for (let i = 0, j = 0; i < b.length; i++) {
    if (b[i] === a[j]) j++;
    if (j === a.length) return i - j + 1;
  }
  return -1;
}

export function SearchBar({ onSelect, onClose }: Props) {
  const [q, setQ] = useState('');
  const [focused, setFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // live places only: a deleted house must not come back through a matching person or note
  const places = useLiveQuery(() => db.places.filter((p) => !p.deletedAt).toArray(), []) ?? [];
  const persons = useLiveQuery(() => db.persons.toArray(), []) ?? [];
  const notes = useLiveQuery(() => db.notes.toArray(), []) ?? [];

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const results = !q.trim()
    ? []
    : (() => {
        const ql = q.trim().toLowerCase();
        const matchedPlaceIds = new Set<string>();

        // Places: match houseNo, tag name, note
        places.filter((p) => !p.deletedAt && fuzzyMatch(ql, `${p.houseNo ?? ''} ${p.note ?? ''}`) >= 0)
          .forEach((p) => matchedPlaceIds.add(p.id));

        // Persons: match name, nickname → include their place
        persons.filter((p) => !p.deletedAt && fuzzyMatch(ql, `${p.name} ${p.nickname ?? ''}`) >= 0)
          .forEach((p) => matchedPlaceIds.add(p.placeId));

        // Notes: match body → include their place
        notes.filter((n) => !n.deletedAt && fuzzyMatch(ql, n.body) >= 0)
          .forEach((n) => matchedPlaceIds.add(n.placeId));

        // Collect full Place objects for matched IDs
        const out: Place[] = [];
        const seen = new Set<string>();
        for (const pid of matchedPlaceIds) {
          const place = places.find((p) => p.id === pid && !p.deletedAt);
          if (place && !seen.has(place.id)) { seen.add(place.id); out.push(place); }
        }
        return out.slice(0, 10);
      })();

  const handlePick = (p: Place) => {
    onSelect(p);
  };

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-white">
      <div className="flex items-center gap-2 border-b border-gray-200 px-4 py-3">
        <div className="flex flex-1 items-center gap-2 rounded-full bg-gray-100 px-3 py-2">
          <Search size={18} className="text-gray-400" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={() => setTimeout(() => setFocused(false), 150)}
            placeholder="ค้นหาบ้านเลขที่, ชื่อ, บันทึก"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-gray-400"
          />
          {q && (
            <button onClick={() => setQ('')} className="rounded-full p-0.5 text-gray-400 hover:text-gray-600">
              <X size={16} />
            </button>
          )}
        </div>
        <button onClick={onClose} className="text-sm text-blue-600">ยกเลิก</button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {focused && q.trim() && (
          <div>
            <div className="px-4 py-2 text-xs font-semibold uppercase tracking-wide text-gray-400">ผลลัพธ์</div>
            {results.length === 0 ? (
              <p className="px-4 py-4 text-sm text-gray-400">ไม่พบผลลัพธ์</p>
            ) : (
              results.map((p) => (
                <button key={p.id} onMouseDown={() => handlePick(p)}
                  className="w-full border-b border-gray-50 px-4 py-3 text-left">
                  <div className="font-medium text-gray-800">
                    {p.houseNo?.trim() ? ('บ้านเลขที่ ' + p.houseNo) : (p.tag === 'house' ? 'บ้าน (ไม่มีเลขที่)' : (TAGS.find((t) => t.value === p.tag)?.label ?? p.tag))}
                  </div>
                  {p.note && <div className="text-xs text-gray-400">{p.note}</div>}
                </button>
              ))
            )}
          </div>
        )}
        {!q.trim() && (
          <div>
            <div className="px-4 py-2 text-xs font-semibold uppercase tracking-wide text-gray-400">รายการทั้งหมด</div>
            {places.length === 0 ? (
              <p className="px-4 py-4 text-sm text-gray-400">ไม่มีข้อมูล</p>
            ) : (
              places.filter((p) => !p.deletedAt).map((p) => (
                <button key={p.id} onMouseDown={() => handlePick(p)}
                  className="w-full border-b border-gray-50 px-4 py-3 text-left">
                  <div className="font-medium text-gray-800">{p.houseNo?.trim() ? ('บ้านเลขที่ ' + p.houseNo) : (p.tag === 'house' ? 'บ้าน (ไม่มีเลขที่)' : (TAGS.find((t) => t.value === p.tag)?.label ?? p.tag))}</div>
                </button>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}