import { useEffect, useMemo, useRef, useState, useCallback } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { AlertTriangle, ChartColumn, Check, CornerUpLeft, HousePlus, Info, Layers, LocateFixed, MapPin, Menu, PenLine, RefreshCw, Search, Settings, X } from 'lucide-react'
import { useLiveQuery } from 'dexie-react-hooks'
import { db, uuid, nowIso, type PlaceTag } from './db'
import { savePlace, saveGeoLayer, saveBoundary, saveLocation, flush, pull, getGasUrl, getStudentIdentity, activeArea } from './sync'
import { isInAppBrowser, useOverlayStack, confirmAction, confirmOpen, exportSvgString, copyToClipboard } from './ui/common'
import { onUpdateReady, applyUpdate } from './pwa'
import { cachedZoneProfile, hasZoneCenter, loadZoneProfile, BUILDINGS_FILE, EMPTY_ZOOM, VILLAGE_ZOOM } from './zone.config'
import { isAdmin, canEditBoundary, getRole } from './permissions'
import { MAX_ZOOM, BASEMAPS, DEFAULT_BASE, IDLE_STYLE, DRAFT_ROOF_STYLE, SNAP_METERS, BOUNDARY_STYLE, polygonArea, formatArea, type BaseKey } from './map/config'
import { Pentagon } from 'lucide-react'
import { placeStatus, buildingStatuses, groupByPlace, roofStyle, ROOF_STATUS, type RoofStatus, type RoofStyle } from './map/roofStatus'
import { Dashboard } from './components/Dashboard'
import { SearchBar } from './components/SearchBar'
import { SettingsPanel } from './components/SettingsPanel'
import { PlaceSheet, type Target } from './components/PlaceSheet'
import { PersonSheet } from './components/PersonSheet'
import { genogramSvg, escapeXml } from './genogram'
import { LoginModal } from './components/LoginModal'
import { ZoneSetupModal } from './components/ZoneSetupModal'
import { OnboardingModal } from './components/OnboardingModal'
import { InstallAppButton } from './components/InstallAppButton'
import { OfflineTilesButton } from './components/OfflineTilesButton'

// ---- in-app browser detection -------------------------------------------------
const inApp = isInAppBrowser()

const IDLE: RoofStyle = {
  fillColor: IDLE_STYLE.fillColor!, color: IDLE_STYLE.color!, fillOpacity: IDLE_STYLE.fillOpacity!, weight: IDLE_STYLE.weight!,
}

type RoofLayer = L.Polygon & { feature?: GeoJSON.Feature }

/** Flatten Leaflet polygon latlngs (Polygon or MultiPolygon nesting) into rings. */
function ringsOf(lls: L.LatLng[] | L.LatLng[][] | L.LatLng[][][]): L.LatLng[][] {
  if (!lls.length) return []
  if (L.LineUtil.isFlat(lls as L.LatLng[])) return [lls as L.LatLng[]]
  return (lls as (L.LatLng[] | L.LatLng[][])[]).flatMap((x) => ringsOf(x))
}

/** Ray-cast point-in-ring test in pixel space. */
function insideRing(p: L.Point, ring: L.Point[]): boolean {
  let inside = false
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const a = ring[i], b = ring[j]
    if ((a.y > p.y) !== (b.y > p.y) && p.x < ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x) inside = !inside
  }
  return inside
}

export default function App() {
  const mapEl = useRef<HTMLDivElement>(null)
  const map = useRef<L.Map | null>(null)
  const baseLayer = useRef<L.TileLayer | null>(null)
  const footprints = useRef<L.GeoJSON | null>(null)
  const customLayer = useRef<L.GeoJSON | null>(null)
  const boundaryLayer = useRef<L.GeoJSON | null>(null)
  const pinLayer = useRef<L.LayerGroup | null>(null)
  const myPos = useRef<L.LatLng | null>(null)

  // state
  const [panel, setPanel] = useState<string | null>(null) // 'dashboard' | 'search' | 'settings'
  const [target, setTarget] = useState<Target | null>(null)
  const [personSheetPlaceId, setPersonSheetPlaceId] = useState<string | null>(null)
  const [genogramPlaceId, setGenogramPlaceId] = useState<string | null>(null)
  const [inAppWarn, setInAppWarn] = useState(inApp.detected)
  const [base, setBase] = useState<keyof typeof BASEMAPS>(DEFAULT_BASE)
  const [filter, setFilter] = useState<RoofStatus | 'all'>('all')
  const [legend, setLegend] = useState(false)
  const [gpsAcc, setGpsAcc] = useState<number | null>(null)
  const [gpsErr, setGpsErr] = useState<string | null>(null)
  const [follow, setFollow] = useState(false)
  const followRef = useRef(follow) // read by the locationfound handler (init-effect closure)
  followRef.current = follow
  const gpsDot = useRef<L.Marker | null>(null)
  const gpsCircle = useRef<L.Circle | null>(null)
  const [fpReady, setFpReady] = useState(0) // bumped each time buildings.geojson is (re)drawn into `footprints`
  const roofOpts = useRef<L.GeoJSONOptions | null>(null) // built in map init (closes over openRoof)
  const fpData = useRef<GeoJSON.FeatureCollection | null>(null) // fetched buildings.geojson
  const lastStyle = useRef(new WeakMap<L.Path, string>()) // per-roof style key → skip no-op setStyle

  // drawing state
  const [drawing, setDrawing] = useState(false)
  const [drawKind, setDrawKind] = useState<'building' | 'boundary'>('building')
  const [draft, setDraft] = useState<[number, number][]>([])
  const draftArea = useMemo(() => polygonArea(draft), [draft])
  const drawingRef = useRef(drawing)
  const draftRef = useRef(draft)
  drawingRef.current = drawing
  draftRef.current = draft
  const rubber = useRef<L.Polyline | null>(null)
  const draftLayer = useRef<L.LayerGroup | null>(null)

  const [currentUser, setCurrentUser] = useState(() => getStudentIdentity())
  const [showLogin, setShowLogin] = useState(!currentUser.studentId || currentUser.studentId.startsWith('s-'))
  const [showOnboarding, setShowOnboarding] = useState(!getGasUrl())

  const places = useLiveQuery(() => db.places.toArray(), []) ?? []
  const notes = useLiveQuery(() => db.notes.toArray(), []) ?? []
  const persons = useLiveQuery(() => db.persons.toArray(), []) ?? []
  const rels = useLiveQuery(() => db.relationships.toArray(), []) ?? []
  const geoLayers = useLiveQuery(() => db.geoLayers.toArray(), []) ?? []
  const pendingCount = useLiveQuery(() => db.outbox.count(), []) ?? 0

  // Ref for latest places — map click handlers captured in useEffect([]) see a
  // stale `places` closure otherwise.
  const placesRef = useRef(places)
  placesRef.current = places

  // ---- map init ----------------------------------------------------------------
  useEffect(() => {
    if (map.current || !mapEl.current) return
    const start = cachedZoneProfile()
    const m = L.map(mapEl.current, {
      zoomControl: false, attributionControl: false,
      center: start.center, zoom: hasZoneCenter(start) ? VILLAGE_ZOOM : EMPTY_ZOOM, maxZoom: MAX_ZOOM,
    })
    map.current = m
    // first open on this device: no cached profile yet → jump once zone.json is read
    if (!hasZoneCenter(start)) {
      void loadZoneProfile().then((p) => { if (map.current === m && hasZoneCenter(p)) m.setView(p.center, VILLAGE_ZOOM) })
    }

    // Phone: the place sheet covers the lower part of the map, so bring the tapped spot into
    // the visible strip above it. Desktop (side panel) just centres.
    const panToTapped = (c: L.LatLng) => {
      if (matchMedia('(min-width: 768px)').matches) m.panTo(c, { animate: true })
      else m.panTo(m.unproject(m.project(c).add([0, m.getSize().y * 0.25])), { animate: true })
    }
    L.control.attribution({ position: 'bottomleft', prefix: false }).addTo(m)

    // ensure tiles render even if container sized after init
    const ro = new ResizeObserver(() => m.invalidateSize())
    ro.observe(mapEl.current)
    setTimeout(() => m.invalidateSize(), 0)

    draftLayer.current = L.layerGroup().addTo(m)
    rubber.current = L.polyline([], { weight: 2, dashArray: '4 4', opacity: 0.8, interactive: false }).addTo(m)
    pinLayer.current = L.layerGroup().addTo(m)
    boundaryLayer.current = L.geoJSON(undefined, { style: BOUNDARY_STYLE }).addTo(m)

    // base layer
    const b = BASEMAPS[DEFAULT_BASE]
    baseLayer.current = L.tileLayer(b.url, { maxZoom: MAX_ZOOM, maxNativeZoom: b.nativeMax, attribution: b.attr }).addTo(m)

    const addVertex = (ll: L.LatLng) => {
      setDraft((d) => [...d, [ll.lat, ll.lng]])
    }

    // Open the live place on a roof, or a "new place" sheet anchored to it.
    const openRoof = (layer: RoofLayer) => {
      const bid = layer.feature?.properties?.id as string | undefined
      const existing = bid ? placesRef.current.find((p) => p.buildingId === bid && !p.deletedAt) : undefined
      const c = layer.getBounds().getCenter()
      panToTapped(c)
      if (existing) { setTarget({ kind: 'place', placeId: existing.id }); return }
      setTarget({ kind: 'new', lat: c.lat, lng: c.lng, buildingId: bid ?? null })
    }

    // Nearest roof (OSM footprints + custom-drawn) by true point-to-edge distance, in metres.
    // Centroid distance fails on long buildings (schools, temple halls): a tap at one end
    // can be >15 m from the centre while standing right at the wall.
    const nearestBuilding = (latlng: L.LatLng): { layer: RoofLayer; distance: number } | null => {
      const p = m.latLngToLayerPoint(latlng)
      const mPerPx = (40075016.686 * Math.cos((latlng.lat * Math.PI) / 180)) / Math.pow(2, m.getZoom() + 8)
      const maxPx = SNAP_METERS / mPerPx
      let best: { layer: RoofLayer; distance: number } | null = null
      for (const g of [footprints.current, customLayer.current]) {
        g?.eachLayer((l) => {
          const poly = l as RoofLayer
          if (!poly.feature || !poly.getBounds) return
          const b = poly.getBounds()
          if (!b.isValid()) return
          // cheap bbox reject before walking edges
          const nw = m.latLngToLayerPoint(b.getNorthWest()), se = m.latLngToLayerPoint(b.getSouthEast())
          if (p.x < nw.x - maxPx || p.x > se.x + maxPx || p.y < nw.y - maxPx || p.y > se.y + maxPx) return
          let dPx = Infinity
          for (const ring of ringsOf(poly.getLatLngs() as L.LatLng[][])) {
            const pts = ring.map((ll) => m.latLngToLayerPoint(ll))
            if (pts.length < 2) continue
            if (insideRing(p, pts)) { dPx = 0; break }
            for (let i = 0; i < pts.length; i++) {
              dPx = Math.min(dPx, L.LineUtil.pointToSegmentDistance(p, pts[i], pts[(i + 1) % pts.length]))
            }
          }
          const d = dPx * mPerPx
          if (!best || d < best.distance) best = { layer: poly, distance: d }
        })
      }
      return best
    }

    m.on('click', (e: L.LeafletMouseEvent) => {
      if (drawingRef.current) { addVertex(e.latlng); return }
      // Find nearest building; if within SNAP_METERS of its edge, select it. Else ground pin.
      const nb = nearestBuilding(e.latlng)
      if (nb && nb.distance < SNAP_METERS) {
        openRoof(nb.layer)
      } else {
        // ground tap — open new POI sheet (no buildingId)
        panToTapped(e.latlng)
        setTarget({ kind: 'new', lat: e.latlng.lat, lng: e.latlng.lng, buildingId: null })
      }
    })

    m.on('mousemove', (e: L.LeafletMouseEvent) => {
      const d = draftRef.current
      rubber.current?.setLatLngs(drawingRef.current && d.length ? [d[d.length - 1], e.latlng] : [])
    })
    m.on('mouseout', () => rubber.current?.setLatLngs([]))

    // roof layer options; footprints are loaded by the effect below
    roofOpts.current = {
      style: () => IDLE_STYLE,
      onEachFeature: (f, layer) => {
        layer.on('click', (e: L.LeafletMouseEvent) => {
          L.DomEvent.stopPropagation(e)
          if (drawingRef.current) { addVertex(e.latlng); return }
          openRoof(layer as RoofLayer)
        })
      },
    }
    customLayer.current = L.geoJSON(undefined, roofOpts.current).addTo(m)

    // location tracking: blue dot + pulsing accuracy circle; both non-interactive so a tap
    // on the house the surveyor is standing at still reaches the roof underneath.
    let gpsErrShown = false
    let lastPing: { at: number; pos: L.LatLng } | null = null
    m.on('locationfound', (e: L.LocationEvent) => {
      myPos.current = e.latlng
      setGpsAcc(Math.round(e.accuracy))
      setGpsErr(null)
      if (!gpsDot.current || !gpsCircle.current) {
        gpsCircle.current = L.circle(e.latlng, { radius: e.accuracy, className: 'gps-acc', color: '#1a73e8', weight: 1, fillColor: '#1a73e8', fillOpacity: 0.15, interactive: false }).addTo(m)
        gpsDot.current = L.marker(e.latlng, { icon: L.divIcon({ className: '', html: '<div class="gps-dot"></div>', iconSize: [14, 14], iconAnchor: [7, 7] }), interactive: false, keyboard: false }).addTo(m)
      } else {
        gpsDot.current.setLatLng(e.latlng)
        gpsCircle.current.setLatLng(e.latlng).setRadius(e.accuracy)
      }
      if (followRef.current) m.panTo(e.latlng)
      // heartbeat: one row per 60 s, or sooner after moving > 25 m (watchPosition fires every second or so)
      const now = Date.now()
      if (lastPing && now - lastPing.at < 60_000 && lastPing.pos.distanceTo(e.latlng) <= 25) return
      lastPing = { at: now, pos: e.latlng }
      void saveLocation({
        studentId: localStorage.getItem('student-id') ?? 'anon',
        lat: e.latlng.lat, lng: e.latlng.lng, accuracy: Math.round(e.accuracy),
      })
    })
    // watchPosition can repeat errors: toast only the first; the locate button re-explains on tap
    m.on('locationerror', (e: L.ErrorEvent) => {
      setGpsErr(e.message)
      if (!gpsErrShown && !myPos.current) { gpsErrShown = true; setToast('ยังไม่พบสัญญาณ GPS') }
    })
    m.on('dragstart', () => setFollow(false))
    m.locate({ watch: true, enableHighAccuracy: true, setView: false, maximumAge: 5000 })

    return () => { ro.disconnect(); m.stopLocate(); m.remove(); map.current = null; gpsDot.current = null; gpsCircle.current = null }
  }, [])

  // ---- footprints: base roof layer from /buildings.geojson --------------------------
  // Roofs already saved as a custom copy (same plus code, e.g. "extract in boundary")
  // are left out here, so the custom layer is the only one drawing them.
  const copiedRoofs = useMemo(() => {
    const ids: string[] = []
    for (const g of geoLayers) {
      if (g.deletedAt || g.kind !== 'customBuilding') continue
      try { const pc = (JSON.parse(g.geojson) as GeoJSON.Feature).properties?.plus_code; if (pc) ids.push(pc) } catch { /* skip malformed */ }
    }
    return ids.sort().join('\n')
  }, [geoLayers])

  useEffect(() => {
    const m = map.current, opts = roofOpts.current
    if (!m || !opts) return
    let cancelled = false
    const draw = (gj: GeoJSON.FeatureCollection, fit: boolean) => {
      const hide = new Set(copiedRoofs.split('\n'))
      footprints.current?.remove()
      footprints.current = L.geoJSON(gj, { ...opts, filter: (f) => !hide.has(f.properties?.plus_code) }).addTo(m)
      customLayer.current?.bringToFront()
      if (fit && footprints.current.getBounds().isValid()) m.fitBounds(footprints.current.getBounds())
      setFpReady((n) => n + 1) // paint effect runs with current data
    }
    if (fpData.current) { draw(fpData.current, false); return }
    fetch(BUILDINGS_FILE)
      .then((r) => r.json())
      .then((gj: GeoJSON.FeatureCollection) => {
        if (cancelled || map.current !== m) return
        fpData.current = gj
        draw(gj, true)
      })
      .catch(() => {})
    return () => { cancelled = true }
  }, [copiedRoofs])

  // ---- paint footprint colours -------------------------------------------------
  // Only touches layers whose computed style changed: Dexie live queries fire on every
  // write, and restyling all ~300 SVG paths each time causes visible jank on phones.
  function paintFootprints() {
    const statuses = buildingStatuses(places, notes, persons)
    const cache = lastStyle.current
    for (const g of [footprints.current, customLayer.current]) {
      g?.eachLayer((l) => {
        const f = (l as RoofLayer).feature
        if (!f) return
        const s = roofStyle(statuses.get(f.properties?.id as string), filter, IDLE)
        const key = `${s.fillColor}|${s.color}|${s.fillOpacity}|${s.weight}`
        if (cache.get(l as L.Path) === key) return
        cache.set(l as L.Path, key)
        ;(l as L.Path).setStyle(s)
      })
    }
  }

  // re-paint when data, filter, or loaded layers change
  useEffect(() => { paintFootprints() }, [places, notes, persons, filter, fpReady])

  // ---- pin layer: render places with no buildingId -----------------------------
  useEffect(() => {
    const layer = pinLayer.current
    if (!layer) return
    layer.clearLayers()
    const notesBy = groupByPlace(notes)
    const personsBy = groupByPlace(persons)

    const TAG_PIN_COLORS: Record<PlaceTag, string> = {
      house: '#eab308',
      lodging: '#2563eb',
      shop: '#f59e0b',
      temple: '#f97316',
      school: '#0891b2',
      community_hall: '#6366f1',
      bus_stop: '#059669',
      other: '#6b7280',
    }

    for (const p of places) {
      if (p.buildingId || p.deletedAt) continue

      const status = placeStatus(p, notesBy.get(p.id) ?? [], personsBy.get(p.id) ?? []) ?? 'unvisited'
      let markerColor = TAG_PIN_COLORS[p.tag] ?? '#6b7280'
      let markerFillOpacity = 0.9
      let markerWeight = 2

      if (filter !== 'all') {
        if (status !== filter) {
          markerColor = '#94a3b8'
          markerFillOpacity = 0.4
          markerWeight = 1
        }
      }

      const m = L.circleMarker([p.lat, p.lng], {
        radius: 8, fillColor: markerColor, color: '#fff', weight: markerWeight, fillOpacity: markerFillOpacity,
      }).bindTooltip(escapeXml(p.houseNo) || 'ไม่มีเลข', { direction: 'top', offset: [0, -6] })

      if (p.tag === 'lodging') {
        const lodgingIcon = L.divIcon({
          className: 'leaflet-div-icon',
          html: `<div style="background-color:${markerColor}; width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-weight:bold; font-size:12px; border:2px solid white;">${escapeXml(p.houseNo) || '🏥'}</div>`,
          iconSize: [30, 30],
          iconAnchor: [15, 15],
        })
        const lodgingMarker = L.marker([p.lat, p.lng], { icon: lodgingIcon })
        lodgingMarker.on('click', () => setTarget({ kind: 'place', placeId: p.id }))
        layer.addLayer(lodgingMarker)
      } else {
        m.on('click', () => setTarget({ kind: 'place', placeId: p.id }))
        layer.addLayer(m)
      }
    }
  }, [places, filter, notes, persons])

  // ---- draft visibility: render vertex circles + dashed polygon -----------------
  useEffect(() => {
    const layer = draftLayer.current
    if (!layer) return
    layer.clearLayers()
    const vertexColor = drawKind === 'boundary' ? '#f97316' : '#1a73e8'
    rubber.current?.setStyle({ color: vertexColor })
    if (!drawing || draft.length === 0) { rubber.current?.setLatLngs([]); return }
    // vertex circles
    draft.forEach(([lat, lng]) => {
      L.circleMarker([lat, lng], { radius: 5, color: vertexColor, fillColor: '#fff', fillOpacity: 1, weight: 2 })
        .addTo(layer)
    })
    // dashed polygon if 3+ vertices; dashed line at 2 (touch has no mousemove rubberband)
    const style = { ...(drawKind === 'boundary' ? BOUNDARY_STYLE : DRAFT_ROOF_STYLE), dashArray: '6 3', interactive: false }
    if (draft.length >= 3) L.polygon(draft, style).addTo(layer)
    else if (draft.length === 2) L.polyline(draft, style).addTo(layer)
  }, [draft, drawing, drawKind])

  // ---- custom building layer: load from geoLayers ---------------------------------
  // Added through customLayer.addData so roofOpts.onEachFeature binds the roof click,
  // and each feature carries properties.id = geoLayer id (used as the place buildingId).
  useEffect(() => {
    const layer = customLayer.current
    if (!layer) return
    layer.clearLayers()
    for (const g of geoLayers) {
      if (g.deletedAt || g.kind !== 'customBuilding') continue
      try {
        const gj = JSON.parse(g.geojson) as GeoJSON.Geometry | GeoJSON.Feature
        const geometry = gj.type === 'Feature' ? gj.geometry : gj
        // a copy of a zone-file roof keeps its plus code as id, so places made on the base roof still match
        const id = (gj.type === 'Feature' && gj.properties?.plus_code) || g.id
        layer.addData({ type: 'Feature', properties: { id }, geometry } as GeoJSON.Feature)
      } catch { /* skip malformed */ }
    }
    paintFootprints() // new layers only; cached ones are skipped
  }, [geoLayers])

  // ---- boundary layer: render from geoLayers (kind='boundary') ------------------
  useEffect(() => {
    const layer = boundaryLayer.current
    if (!layer) return
    layer.clearLayers()
    for (const g of geoLayers) {
      if (g.deletedAt || g.kind !== 'boundary') continue
      try {
        const gj = JSON.parse(g.geojson) as GeoJSON.GeoJSON
        L.geoJSON(gj, { style: BOUNDARY_STYLE }).eachLayer((l) => {
          layer.addLayer(l)
        })
      } catch { /* skip malformed */ }
    }
  }, [geoLayers])

  // ---- drawing controls --------------------------------------------------------
  function startDrawing(kind: 'building' | 'boundary' = 'building') { setDrawKind(kind); setDrawing(true); setDraft([]) }
  function startBoundaryDraft() { startDrawing('boundary') }

  function undoVertex() { setDraft((d) => d.slice(0, -1)) }

  function cancelDrawing() { setDrawing(false); setDraft([]) }

  // Android Back while drawing: don't silently drop placed vertices
  async function requestCancelDrawing() {
    if (draftRef.current.length && !(await confirmAction('ยกเลิกการวาด', 'จุดที่วางไว้จะหายไป ต้องการยกเลิกหรือไม่?', 'ยกเลิกการวาด', true, 'วาดต่อ'))) return
    cancelDrawing()
  }

  async function saveDraft() {
    if (draft.length < 3) return
    const ring = [...draft.map(([lat, lng]) => [lng, lat]), [draft[0][1], draft[0][0]]]
    const kind: 'customBuilding' | 'boundary' = drawKind === 'boundary' ? 'boundary' : 'customBuilding'
    const rec = {
      id: uuid(),
      name: kind === 'boundary' ? 'ขอบเขตชุมชน' : 'custom-building',
      kind,
      geojson: JSON.stringify({ type: 'Polygon', coordinates: [ring] }),
      createdBy: localStorage.getItem('student-id') ?? 'anon',
      createdAt: nowIso(),
      updatedAt: nowIso(),
    }
    if (kind === 'boundary') {
      if (!canEditBoundary()) { setToast('เฉพาะ developer / coreteam เท่านั้นที่กำหนดขอบเขตได้'); cancelDrawing(); return }
      if ((await loadZoneProfile()).boundaryLocked) { setToast('ขอบเขตถูกล็อกอยู่ — ปลดล็อกในหน้าตั้งค่าพื้นที่ก่อน'); cancelDrawing(); return }
      // one active village boundary: the new one replaces (soft-deletes) older ones
      const hasOld = geoLayers.some((g) => g.kind === 'boundary' && !g.deletedAt)
      if (hasOld && !(await confirmAction('แทนที่ขอบเขตเดิม', 'ขอบเขตชุมชนเดิมจะถูกแทนที่ด้วยขอบเขตใหม่นี้ ต้องการบันทึกหรือไม่?', 'บันทึกแทนที่'))) return
      await saveBoundary(rec)
    } else {
      await saveGeoLayer(rec)
    }
    setDrawing(false)
    setDraft([])
  }

  // ---- basemap switch ----------------------------------------------------------
  useEffect(() => {
    const m = map.current; if (!m) return
    baseLayer.current?.remove()
    const b = BASEMAPS[base]
    baseLayer.current = L.tileLayer(b.url, { maxZoom: MAX_ZOOM, maxNativeZoom: b.nativeMax, attribution: b.attr }).addTo(m)
    baseLayer.current.bringToBack()
  }, [base])

  // ---- sync -------------------------------------------------------------------
  const [syncing, setSyncing] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(null), 3000)
    return () => clearTimeout(t)
  }, [toast])

  async function handleSync() {
    setSyncing(true)
    try {
      const res = await flush()
      setToast(res.error ? `Sync: ${res.error}` : `ส่ง ${res.sent} รายการแล้ว`)
    } finally { setSyncing(false) }
  }

  async function handlePull() {
    setSyncing(true)
    try {
      const res = await pull()
      setToast(res.error ? `Pull: ${res.error}` : `ดึงข้อมูลแล้ว · ใหม่ ${res.applied} · ข้าม ${res.skipped}`)
    } finally { setSyncing(false) }
  }

  // After sign-in / back online / back in view: pull, then re-render (permissions read the role from localStorage).
  function pullRole() {
    void pull().then(() => setCurrentUser(getStudentIdentity()))
  }

  const [online, setOnline] = useState(navigator.onLine)
  useEffect(() => {
    // Background pull: each one makes Apps Script read every sheet, so at most one per 45 s
    // (flaky signal / flipping between apps), and never while the user is typing in a field.
    let lastAutoPull = 0
    const autoPull = () => {
      const tag = document.activeElement?.tagName
      if (tag === 'INPUT' || tag === 'TEXTAREA' || Date.now() - lastAutoPull < 45_000) return
      lastAutoPull = Date.now()
      pullRole()
    }
    const handleOnline = () => { setOnline(true); void handleSync(); autoPull() }
    const handleOffline = () => setOnline(false)
    const handleVisible = () => { if (document.visibilityState === 'visible' && navigator.onLine) autoPull() }
    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)
    document.addEventListener('visibilitychange', handleVisible)
    return () => {
      window.removeEventListener('online', handleOnline); window.removeEventListener('offline', handleOffline)
      document.removeEventListener('visibilitychange', handleVisible)
    }
  }, [])

  // ---- GPS locate -------------------------------------------------------------
  function locate() {
    const m = map.current
    if (!myPos.current || !m) { setToast(gpsErr ? `ยังไม่พบสัญญาณ GPS (${gpsErr})` : 'ยังไม่พบสัญญาณ GPS'); return }
    if (follow) { setFollow(false); return } // toggle Follow Me off
    setFollow(true)
    m.setView(myPos.current, Math.max(m.getZoom(), 18))
  }

  // Fallback when lost / no GPS: fly to this zone's village (boundary → zone profile)
  async function flyToVillage() {
    setFollow(false)
    const { center } = await activeArea()
    map.current?.flyTo(center, 17)
  }

  // The genogram opens from a house's person sheet: closing it goes back there, not to the bare map
  function closeGenogram() {
    setPersonSheetPlaceId(genogramPlaceId)
    setGenogramPlaceId(null)
  }

  // ---- Android Back: close only the topmost overlay (bottom → top) -------------------
  const placeCloseRef = useRef<(() => void) | null>(null)
  const personCloseRef = useRef<(() => void) | null>(null)
  useOverlayStack([
    { open: drawing, close: () => void requestCancelDrawing() },
    { open: panel !== null, close: () => setPanel(null) },
    { open: legend, close: () => setLegend(false) },
    { open: target !== null, close: () => (placeCloseRef.current ? placeCloseRef.current() : setTarget(null)) },
    { open: personSheetPlaceId !== null, close: () => (personCloseRef.current ? personCloseRef.current() : setPersonSheetPlaceId(null)) },
    { open: genogramPlaceId !== null, close: closeGenogram },
  ])

  // ---- PWA update: reload only when nothing unsaved can be on screen -----------------
  const [updateReady, setUpdateReady] = useState(false)
  useEffect(() => onUpdateReady(() => setUpdateReady(true)), [])
  const busy = drawing || panel !== null || legend || target !== null || personSheetPlaceId !== null
    || genogramPlaceId !== null || showLogin || showOnboarding
  useEffect(() => {
    if (updateReady && !busy && !confirmOpen()) applyUpdate()
  }, [updateReady, busy])

  // filter definitions (map v2 ROOF_STATUS to chip labels/colors)
  const FILTERS = useMemo(() => [
    { key: 'all' as const, label: 'ทั้งหมด', color: null },
    ...Object.entries(ROOF_STATUS).map(([k, v]) => ({ key: k as RoofStatus, label: v.label, color: v.color })),
  ], [])

  // Genogram: all live persons go in so layout() can pull in relatives from other
  // houses (2 degrees); memoized so it isn't rebuilt on every App render.
  const genogram = useMemo(() => {
    if (!genogramPlaceId) return null
    const live = persons.filter((p) => !p.deletedAt)
    const ids = new Set(live.map((p) => p.id))
    const liveRels = rels.filter((r) => !r.deletedAt && ids.has(r.person1Id) && ids.has(r.person2Id))
    const houseCount = live.filter((p) => p.placeId === genogramPlaceId).length
    return { houseCount, ...genogramSvg(genogramPlaceId, live, liveRels) }
  }, [genogramPlaceId, persons, rels])

  const roundBtn ='grid h-11 w-11 place-items-center rounded-full bg-white text-gray-700 shadow-md active:bg-gray-100'

  // ---- render -----------------------------------------------------------------
  return (
    <div className="relative h-dvh w-screen overflow-hidden bg-white">
      {/* map */}
      <div ref={mapEl} className="absolute inset-0" />

      {/* login prompt */}
      {(!currentUser.studentId || currentUser.studentId.startsWith('s-')) && !showLogin && (
        <button onClick={() => setShowLogin(true)} className="absolute inset-x-6 top-20 z-[1600] rounded-xl bg-blue-600 px-4 py-3 text-sm font-medium text-white shadow-lg">
          เข้าสู่ระบบด้วยรหัสนักศึกษา
        </button>
      )}
      {showOnboarding && (
        <OnboardingModal onDone={() => { setShowOnboarding(false); setShowLogin(false); setCurrentUser(getStudentIdentity()); pullRole() }} />
      )}
      {showLogin && !showOnboarding && (
        <LoginModal onClose={() => setShowLogin(false)} onLogin={() => { setCurrentUser(getStudentIdentity()); setShowLogin(false); pullRole() }} />
      )}

      {/* in-app browser warning */}
      {inAppWarn && (
        <div className="fixed inset-0 z-[3100] flex items-center justify-center bg-black/70 p-4">
          <div className="max-h-full w-full max-w-sm overflow-y-auto rounded-2xl bg-white p-5 text-sm text-gray-800 shadow-2xl">
            <p className="mb-2 text-lg font-bold text-red-700"><AlertTriangle size={20} className="mr-1 inline -mt-1" /> เปิดในเบราว์เซอร์จริงก่อนใช้งาน</p>
            <p className="mb-3">ตอนนี้เปิดอยู่ในหน้าต่างของ {inApp.vendor} ซึ่งเก็บข้อมูลออฟไลน์ ถ่ายรูป และติดตั้งแอปได้ไม่ครบ ข้อมูลที่จดอาจหาย</p>
            <p className="font-medium">Android</p>
            <p className="mb-2">กด <b>⋮</b> หรือ <b>…</b> มุมขวาบน → <b>เปิดใน Chrome</b> (Open in browser)</p>
            <p className="font-medium">iPhone / iPad</p>
            <p className="mb-3">กดปุ่ม <b>แชร์</b> หรือ <b>…</b> มุมขวาล่าง → <b>เปิดใน Safari</b> (Open in browser)</p>
            <p className="mb-3 text-gray-600">ถ้าไม่มีเมนูนี้ ให้คัดลอกลิงก์ แล้วไปวางในช่องที่อยู่ของ Chrome หรือ Safari</p>
            <button
              onClick={() => { void copyToClipboard(location.href).then((ok) => setToast(ok ? 'คัดลอกลิงก์แล้ว นำไปวางใน Chrome / Safari' : 'คัดลอกไม่สำเร็จ กดค้างที่แถบที่อยู่เพื่อคัดลอกเอง')) }}
              className="w-full rounded-xl bg-blue-600 py-3 text-sm font-medium text-white"
            >
              คัดลอกลิงก์
            </button>
            <button onClick={() => setInAppWarn(false)} className="mt-3 block w-full py-2 text-xs text-gray-500 underline">ใช้งานต่อในหน้านี้ (ไม่แนะนำ)</button>
          </div>
        </div>
      )}

      {/* top bar — floating pill with Menu, title, sync status */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-[1000] px-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div className="pointer-events-auto flex h-12 items-center gap-1.5 whitespace-nowrap rounded-full bg-white pl-1 pr-2 shadow-md">
          <button onClick={() => setPanel(panel === 'menu' ? null : 'menu')} className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-gray-600 active:bg-gray-100" aria-label="เมนู">
            <Menu size={22} />
          </button>
          <span className="min-w-0 truncate text-[14px] font-medium text-gray-900">{currentUser.name || 'COMMED OS'}</span>
          {getRole() === 'developer' && <span className="shrink-0 rounded-full bg-purple-100 px-1.5 py-0.5 text-[10px] font-bold text-purple-700">DEV</span>}
          {getRole() === 'coreteam' && <span className="shrink-0 rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">CORE</span>}
          <span className={`ml-auto shrink-0 text-[12px] ${online ? 'text-emerald-700' : 'text-gray-500'}`} title={online ? 'เชื่อมต่ออินเทอร์เน็ต' : 'ออฟไลน์ — ข้อมูลเก็บในเครื่อง'}>
            {online ? '🟢' : '⚪'}<span className="hidden min-[400px]:inline">{online ? ' Online' : ' Offline'}</span>
          </span>
          <button
            onClick={handleSync}
            disabled={syncing}
            className={`flex h-8 shrink-0 items-center gap-1.5 rounded-full px-3 text-[13px] font-medium shadow-sm ${pendingCount > 0 ? 'bg-amber-500 text-white hover:bg-amber-600' : 'bg-emerald-100 text-emerald-700'} disabled:opacity-60`}
            title={pendingCount > 0 ? `มี ${pendingCount} รายการรอส่ง` : 'ส่งข้อมูลครบแล้ว'}
          >
            {syncing ? (
              <>
                <RefreshCw size={12} className="animate-spin" />
                <span>กำลังส่ง...</span>
              </>
            ) : pendingCount > 0 ? (
              <>
                <span>🔄 ส่งข้อมูล ({pendingCount})</span>
              </>
            ) : (
              <>
                <span>✓ ส่งครบแล้ว</span>
              </>
            )}
          </button>
          <button onClick={() => void handlePull()} disabled={syncing} className="flex h-8 shrink-0 items-center gap-1 rounded-full border border-blue-200 bg-blue-50 px-3 text-[13px] font-medium text-blue-700 hover:bg-blue-100 disabled:opacity-60" title="ดึงข้อมูลล่าสุด" aria-label="ดึงข้อมูลล่าสุด">
            📥<span className="hidden sm:inline"> ดึงข้อมูล</span>
          </button>
        </div>
      </div>

      {/* filter chips row (phone: under top bar, hidden while panel/target/drawing open) */}
      {!drawing && !target && !panel && (
        <div className="absolute inset-x-0 top-[calc(max(0.75rem,env(safe-area-inset-top))+3.5rem)] z-[900] flex items-center gap-1.5 overflow-x-auto px-3 pb-1 pr-16 [scrollbar-width:none]">
          {FILTERS.map((f) => (
            <button key={f.key} onClick={() => setFilter(f.key)}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1 text-[13px] shadow ${filter === f.key ? 'bg-blue-600 text-white font-medium shadow-md' : 'bg-white text-gray-700'}`}>
              {f.color && <span className="h-2.5 w-2.5 rounded-full border border-black/10" style={{ background: f.color }} />}{f.label}
            </button>
          ))}
        </div>
      )}

      {/* right controls: layers + draw buttons */}
      <div className="absolute right-4 top-[calc(max(0.75rem,env(safe-area-inset-top))+4rem)] z-[900]">
        <button onClick={() => setPanel(panel === 'layers' ? null : 'layers')} className={roundBtn} aria-label="ชั้นแผนที่"><Layers size={20} /></button>
        <button onClick={drawing ? cancelDrawing : () => startDrawing()} className={`${roundBtn} mt-3 ${drawing ? 'bg-red-500! text-white!' : ''}`} aria-label={drawing ? 'ยกเลิกวาด' : 'วาดอาคารใหม่'}>
          {drawing ? <X size={20} /> : <HousePlus size={20} className="text-[#1a73e8]" />}
        </button>
      </div>

      {/* village fly-back + locate buttons (bottom-right) */}
      <div className={`absolute right-4 z-[900] flex flex-col items-center gap-3 transition-[bottom] ${target ? 'bottom-[calc(55%+0.75rem)]' : 'bottom-[max(1.5rem,env(safe-area-inset-bottom))]'}`}>
        <button onClick={() => void flyToVillage()} className={`${roundBtn} text-xl`} aria-label="ศูนย์กลางหมู่บ้าน" title="ศูนย์กลางหมู่บ้าน">
          🏘️
        </button>
        <button onClick={locate} className={`grid h-14 w-14 place-items-center rounded-full bg-white shadow-lg active:bg-gray-100 ${follow ? 'text-[#1a73e8]' : 'text-gray-700'}`} aria-label="ตำแหน่งของฉัน">
          <LocateFixed size={24} />
        </button>
      </div>

      {/* drawing controls (bottom bar) */}
      {drawing && (
        <div className="absolute inset-x-3 bottom-[max(1.5rem,env(safe-area-inset-bottom))] right-20 z-[900] rounded-2xl bg-white p-3 shadow-lg">
          <p className="mb-2 text-[13px] text-gray-600">
            {drawKind === 'boundary' ? (
              <>โหมดกำหนดขอบเขต · แตะแผนที่เพื่อวางจุด ({draft.length} จุด · พื้นที่ ~{formatArea(draftArea)})</>
            ) : (
              <>วาดอาคารใหม่ · แตะมุมหลังคาทีละจุด ({draft.length} จุด)</>
            )}
          </p>
          <div className="grid grid-cols-3 gap-2 text-sm">
            <button onClick={undoVertex} disabled={!draft.length} className="rounded-lg border border-gray-200 py-2 text-gray-700 disabled:opacity-40">ย้อนกลับ 1 จุด</button>
            <button onClick={() => setDraft([])} disabled={!draft.length} className="rounded-lg border border-gray-200 py-2 text-gray-700 disabled:opacity-40">ล้างเส้น</button>
            <button onClick={saveDraft} disabled={draft.length < 3} className={`rounded-lg py-2 text-white disabled:opacity-40 ${drawKind === 'boundary' ? 'bg-orange-500' : 'bg-[#1a73e8]'}`}>
              {drawKind === 'boundary' ? 'บันทึกขอบเขต' : 'บันทึกหลังคา'}
            </button>
          </div>
          <button onClick={cancelDrawing} className="mt-2 w-full py-1 text-xs text-gray-500">ยกเลิก</button>
        </div>
      )}

      {/* bottom-left legend button */}
      {!drawing && !target && !panel && (
        <button onClick={() => setLegend(true)} className="absolute bottom-[max(1rem,env(safe-area-inset-bottom))] left-3 z-[900] flex items-center gap-1.5 rounded-full bg-white px-3 py-2 text-sm text-gray-700 shadow-lg active:bg-gray-50">
          <Info size={16} /> สัญลักษณ์สี
        </button>
      )}
      {/* legend modal */}
      {legend && (
        <div className="absolute inset-0 z-[1500] flex items-center justify-center bg-black/50 p-4" onClick={() => setLegend(false)}>
          <div className="max-h-full w-full max-w-sm rounded-2xl bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-gray-100 px-5 py-3">
              <h3 className="text-lg font-semibold text-gray-900">สัญลักษณ์สี</h3>
              <button onClick={() => setLegend(false)} className="grid h-8 w-8 place-items-center rounded-full bg-gray-100"><X size={16} /></button>
            </div>
            <div className="space-y-2.5 p-4 text-sm text-gray-800">
              <p>⚪ <b>สีเทา</b>: ยังไม่เคยลงสำรวจ</p>
              <p><span className="inline-block h-3 w-3 rounded-full align-middle mr-1" style={{ background: ROOF_STATUS.prepared.color }} /> <b>{ROOF_STATUS.prepared.label}</b>: มีบ้านเลขที่แล้ว</p>
              <p><span className="inline-block h-3 w-3 rounded-full align-middle mr-1" style={{ background: ROOF_STATUS.in_progress.color }} /> <b>{ROOF_STATUS.in_progress.label}</b>: มีโน้ต/กำลังเก็บข้อมูล</p>
              <p><span className="inline-block h-3 w-3 rounded-full align-middle mr-1" style={{ background: ROOF_STATUS.completed.color }} /> <b>{ROOF_STATUS.completed.label}</b>: ทำแบบสอบถามครบ</p>
              <p><span className="inline-block h-3 w-3 rounded-full align-middle mr-1" style={{ background: ROOF_STATUS.family_study.color }} /> <b>{ROOF_STATUS.family_study.label}</b>: มีสมาชิกในบ้าน</p>
            </div>
          </div>
        </div>
      )}

      {/* hint text: tap instruction (only when no panel/target/drawing open) */}
      {!target && !panel && !drawing && (
        <div className="pointer-events-none absolute inset-x-0 bottom-[calc(max(1rem,env(safe-area-inset-bottom))+3.25rem)] z-[899] flex justify-center">
          <span className="rounded-full bg-white/95 px-3 py-1.5 text-[13px] text-gray-600 shadow">
            แตะหลังคาหรือพื้นที่เพื่อบันทึก
          </span>
        </div>
      )}

      {/* toast */}
      {toast && (
        <div className="absolute inset-x-0 top-[calc(max(0.75rem,env(safe-area-inset-top))+4rem)] z-[3200] flex justify-center">
          <span className="rounded-lg bg-gray-900 px-4 py-2 text-sm text-white shadow-lg" onClick={() => setToast(null)}>{toast}</span>
        </div>
      )}

      {/* ---- panels ---- */}
      {panel === 'dashboard' && (
        <div className="absolute inset-x-0 bottom-0 top-12 z-[1000] overflow-y-auto bg-white/95 backdrop-blur">
          <Dashboard buildingCount={(footprints.current?.getLayers().length ?? 0) + (customLayer.current?.getLayers().length ?? 0)} onOpenPlace={(id) => { setTarget({ kind: 'place', placeId: id }); setPanel(null) }} />
          <button onClick={() => setPanel(null)} className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-gray-200"><X size={16} /></button>
        </div>
      )}

      {panel === 'search' && (
        <SearchBar
          onSelect={(p) => {
            if (Number.isFinite(p.lat) && Number.isFinite(p.lng)) map.current?.flyTo([p.lat, p.lng], 18)
            setTarget({ kind: 'place', placeId: p.id }); setPanel(null)
          }}
          onClose={() => setPanel(null)}
        />
      )}

      {panel === 'settings' && (
        <SettingsPanel onClose={() => setPanel(null)} onUserChanged={() => setCurrentUser(getStudentIdentity())} onLogout={() => { setCurrentUser(getStudentIdentity()); setShowLogin(true) }} onOpenZoneSetup={() => setPanel('zonesetup')} />
      )}

      {panel === 'zonesetup' && isAdmin() && (
        <ZoneSetupModal onClose={() => setPanel(null)} map={map.current} onStartBoundaryDraft={startBoundaryDraft} />
      )}

      {/* layers modal (basemap picker) */}
      {panel === 'layers' && (
        <div className="absolute inset-0 z-[1500] flex items-center justify-center bg-black/50 p-4" onClick={() => setPanel(null)}>
          <div className="max-h-full w-full max-w-sm rounded-2xl bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-gray-100 px-5 py-3">
              <h3 className="text-lg font-semibold text-gray-900">ประเภทแผนที่</h3>
              <button onClick={() => setPanel(null)} className="grid h-8 w-8 place-items-center rounded-full bg-gray-100"><X size={16} /></button>
            </div>
            <div className="grid grid-cols-2 gap-3 p-4">
              {(Object.keys(BASEMAPS) as BaseKey[]).map((k) => (
                <button key={k} onClick={() => { setBase(k); setPanel(null) }}
                  className={`rounded-xl border-2 p-3 text-sm ${base === k ? 'border-[#1a73e8] text-[#1a73e8]' : 'border-gray-200 text-gray-700'}`}>
                  <div className={`mb-2 h-16 rounded-lg ${k === 'sat' ? 'bg-[linear-gradient(135deg,#3f5a3a,#6b7f4f,#4a5d3f)]' : 'bg-[#f1efe9] [background-image:linear-gradient(#fff_2px,transparent_2px),linear-gradient(90deg,#fff_2px,transparent_2px)] [background-size:18px_18px]'}`} />
                  {BASEMAPS[k].label}
                </button>
              ))}
            </div>
            <div className="border-t border-gray-100 px-4 pt-4">
              <OfflineTilesButton />
            </div>
            <div className="p-4">
              <button onClick={() => { startDrawing(); setPanel(null) }} className="flex w-full items-center gap-3 rounded-xl border border-gray-200 px-4 py-3 text-left text-sm text-gray-800 active:bg-gray-50">
                <HousePlus size={20} className="text-[#1a73e8]" />
                <span>วาดอาคารใหม่<span className="block text-xs text-gray-500">บ้าน/เพิงที่ไม่มีหลังคาบนแผนที่ · แตะมุมทีละจุด</span></span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* menu modal */}
      {panel === 'menu' && (
        <div className="absolute inset-0 z-[1500] flex items-center justify-center bg-black/50 p-4" onClick={() => setPanel(null)}>
          <div className="max-h-full w-full max-w-sm rounded-2xl bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-gray-100 px-5 py-3">
              <h3 className="text-lg font-semibold text-gray-900">COMMED OS</h3>
              <button onClick={() => setPanel(null)} className="grid h-8 w-8 place-items-center rounded-full bg-gray-100"><X size={16} /></button>
            </div>
            <div className="p-4 space-y-1">
              <button onClick={() => { setPanel('dashboard'); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50">
                <ChartColumn size={18} className="text-gray-500" /> ภาพรวม
              </button>
              <button onClick={() => { setPanel('search'); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50">
                <Search size={18} className="text-gray-500" /> ค้นหา
              </button>
              <button onClick={() => { setPanel('settings'); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50">
                <Settings size={18} className="text-gray-500" /> ตั้งค่า
              </button>
              {isAdmin() && (
                <button onClick={() => { setPanel('zonesetup'); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50">
                  <MapPin size={18} className="text-gray-500" /> 🧭 ตั้งค่าพื้นที่
                </button>
              )}
              <hr className="my-2 border-gray-100" />
              <button onClick={() => { startDrawing(); setPanel(null); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50">
                <HousePlus size={18} className="text-[#1a73e8]" /> วาดอาคารใหม่
              </button>
              <button onClick={() => { void handleSync(); setPanel(null); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50">
                <RefreshCw size={18} className="text-gray-500" /> ส่งข้อมูล
              </button>
              <button onClick={() => { void handlePull(); setPanel(null); }} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50">
                📥 ดึงข้อมูลล่าสุด
              </button>
              <hr className="my-2 border-gray-100" />
              <InstallAppButton variant="menu" />
            </div>
          </div>
        </div>
      )}

      {/* place sheet */}
      {target && (
        <PlaceSheet
          key={target.kind === 'place' ? target.placeId : `new:${target.lat},${target.lng}`} // fresh state per building
          closeRef={placeCloseRef}
          target={target} onClose={() => setTarget(null)} onSaved={() => { setTarget(null); setToast('บันทึกข้อมูลเรียบร้อย') }} onError={(msg) => setToast(msg)} onOpenPeople={(id) => { setPersonSheetPlaceId(id); setTarget(null) }} />
      )}

      {/* person sheet */}
      {personSheetPlaceId && (
        <PersonSheet
          placeId={personSheetPlaceId}
          closeRef={personCloseRef}
          onClose={() => setPersonSheetPlaceId(null)}
          onGenogram={() => { setGenogramPlaceId(personSheetPlaceId); setPersonSheetPlaceId(null) }}
        />
      )}

      {/* genogram modal */}
      {genogramPlaceId && genogram && (() => {
        const houseNo = places.find((p) => p.id === genogramPlaceId)?.houseNo
        const exportAs = (as: 'svg' | 'png') =>
          exportSvgString(genogram.svg, `genogram-${houseNo || genogramPlaceId.slice(0, 8)}`, as, genogram.width, genogram.height)
            .catch((e: Error) => setToast('ดาวน์โหลดไม่สำเร็จ: ' + e.message))
        return (
          <div className="absolute inset-0 z-[1500] flex items-center justify-center bg-black/60 p-4">
            <div className="flex max-h-full w-full max-w-xl flex-col rounded-2xl bg-white shadow-2xl">
              <div className="flex items-center gap-2 border-b border-gray-100 px-4 py-3">
                <h3 className="min-w-0 flex-1 truncate text-lg font-semibold text-gray-900">ผังเครือญาติ (Genogram)</h3>
                {genogram.houseCount > 0 && (
                  <>
                    <button onClick={() => void exportAs('png')}
                      className="shrink-0 whitespace-nowrap rounded-full bg-blue-600 px-3 py-1.5 text-sm font-medium text-white">
                      📥 ดาวน์โหลด PNG
                    </button>
                    <button onClick={() => void exportAs('svg')}
                      className="shrink-0 rounded-full border border-blue-600 px-3 py-1.5 text-sm font-medium text-blue-700">
                      SVG
                    </button>
                  </>
                )}
                <button onClick={closeGenogram}
                  className="shrink-0 rounded-full bg-gray-100 px-4 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-200">
                  ปิด
                </button>
              </div>
              {/* native scroll = touch pan both axes; svg keeps its natural width so wide families scroll */}
              <div className="min-h-0 flex-1 overflow-auto overscroll-contain p-4 [touch-action:pan-x_pan-y] [-webkit-overflow-scrolling:touch]" dangerouslySetInnerHTML={{ __html: genogram.houseCount === 0 ? '<p class="text-gray-400 text-sm text-center py-8">ไม่มีสมาชิกในบ้านนี้</p>' : genogram.svg }} />
            </div>
          </div>
        )
      })()}
    </div>
  )
}