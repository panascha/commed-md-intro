import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { VitePWA } from 'vite-plugin-pwa';
import { readFileSync } from 'node:fs';
import type { Plugin } from 'vite';

/** Build-time roster filter: src/students.json holds every zone, but the site folder being built
 *  serves one zone (public/zone.json). Only that zone's rows, and only id / name / house, reach
 *  the bundle. Anything else in the file (other zones, extra columns) is dropped. If zone.json
 *  cannot be read, no roster is bundled at all. */
function zoneRoster(): Plugin {
  return {
    name: 'zone-roster',
    enforce: 'pre',
    transform(code, id) {
      if (!id.replace(/\\/g, '/').split('?')[0].endsWith('/src/students.json')) return null
      let rows: { id?: unknown; name?: unknown; zone?: unknown; house?: unknown }[] = []
      try {
        const zone = Number(JSON.parse(readFileSync('public/zone.json', 'utf8')).zone)
        const all = JSON.parse(code) as typeof rows
        if (Number.isFinite(zone) && Array.isArray(all)) rows = all.filter((s) => Number(s.zone) === zone)
      } catch { rows = [] }
      const kept = rows.filter((s) => s.id && s.name).map((s) => ({ id: String(s.id), name: String(s.name), house: s.house ?? '' }))
      return { code: JSON.stringify(kept), map: null }
    },
  }
}

export default defineConfig({
  plugins: [
    zoneRoster(),
    react(),
    tailwindcss(),
    VitePWA({
      registerType: 'autoUpdate',
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,geojson,json}'],
        maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/[abc]\.tile\.openstreetmap\.org\//,
            handler: 'CacheFirst',
            options: { cacheName: 'osm-tiles', expiration: { maxEntries: 500, maxAgeSeconds: 5184000 }, cacheableResponse: { statuses: [0, 200] } },
          },
          {
            // cacheName shared with cacheTiles() in sync.ts (offline pre-download) — keep in step
            urlPattern: /^https:\/\/server\.arcgisonline\.com\/ArcGIS\/rest\/services\/World_Imagery\/.*/,
            handler: 'CacheFirst',
            options: { cacheName: 'esri-tiles', expiration: { maxEntries: 5000, maxAgeSeconds: 5184000 }, cacheableResponse: { statuses: [0, 200] } },
          },
          {
            // photos pulled from other devices (Drive thumbnails) — viewable offline after first view
            urlPattern: /^https:\/\/(drive\.google\.com\/thumbnail|[a-z0-9-]+\.googleusercontent\.com\/)/,
            handler: 'CacheFirst',
            options: { cacheName: 'photos', expiration: { maxEntries: 1000, maxAgeSeconds: 2592000 }, cacheableResponse: { statuses: [0, 200] } },
          },
        ],
      },
      manifest: {
        name: 'COMMED OS',
        short_name: 'COMMED',
        description: 'Offline-first community reconnaissance tool for Commed field practicum',
        lang: 'th',
        display: 'standalone',
        orientation: 'portrait',
        theme_color: '#0f766e',
        background_color: '#ffffff',
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
        ],
      },
    }),
  ],
});