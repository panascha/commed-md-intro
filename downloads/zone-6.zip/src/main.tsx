import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import 'leaflet/dist/leaflet.css';
import './styles/index.css';
import { applyGasUrlFromQuery } from './sync';
import { isInAppBrowser } from './ui/common';
import './pwa';

void navigator.storage?.persist?.();
applyGasUrlFromQuery(isInAppBrowser().detected);

createRoot(document.getElementById('root')!).render(
  <StrictMode><App /></StrictMode>,
);