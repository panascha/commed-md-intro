// Who may do what. Roles live in the sheet's Roles tab and reach the phone on pull
// (localStorage 'student-role'). The Apps Script backend only checks role *assignment*;
// everything else here is enforced in the app, not on the server.
//
//   developer, coreteam  zone settings, roster, roles, village boundary (draw / lock), delete anything
//   student              view, tag roofs, notes, photos, family members; delete only what they created

export type Role = 'student' | 'coreteam' | 'developer'

export function getRole(): Role {
  const r = localStorage.getItem('student-role')
  return r === 'developer' || r === 'coreteam' ? r : 'student'
}

/** developer or coreteam */
export function isAdmin(): boolean {
  return getRole() !== 'student'
}

const me = () => localStorage.getItem('student-id') ?? ''

/** Delete (or reset) a record: admins always, students only their own. */
export function canDeleteRow(createdBy?: string): boolean {
  return isAdmin() || (!!createdBy && createdBy === me())
}

export const canManageZone = isAdmin // zone profile, footprint import, roster
export const canAssignRoles = isAdmin
export const canEditBoundary = isAdmin
