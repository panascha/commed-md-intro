import { useLiveQuery } from 'dexie-react-hooks'
import { db, nowIso, type GeoLayerRecord } from './db'

/**
 * Zone configuration: the single place that knows which zone this site serves.
 *
 * Nothing here names a zone, a village or a coordinate. The values come from, in order:
 *   1. the override saved by a developer/coreteam in ☰ → ตั้งค่าพื้นที่ (a Geo_Layers row,
 *      kind 'zoneProfile', pulled by every phone of the zone),
 *   2. /zone.json shipped in the site folder (one per release pack, precached),
 *   3. EMPTY_PROFILE, a neutral map view, when neither can be read.
 */
export interface ZoneProfile {
  zone: number // 0 = not set
  village: string
  center: [number, number] // [lat, lng]
  /** true = the village boundary may not be redrawn until an admin unlocks it */
  boundaryLocked?: boolean
}

/** Files shipped in the site folder (public/). */
export const ZONE_FILE = '/zone.json'
export const BUILDINGS_FILE = '/buildings.geojson'

export const ZONE_PROFILE_ID = 'zone-profile'
/** Half-width of the default work area around the centre, in degrees (≈ ±700 m): offline tiles. */
export const AREA_HALF_SPAN = 0.0065
/** Neutral start view (Thailand) for a site with no readable profile. */
const EMPTY_PROFILE: ZoneProfile = { zone: 0, village: '', center: [15.0, 101.0] }
export const EMPTY_ZOOM = 6
export const VILLAGE_ZOOM = 17

// last resolved profile, so the map can start on the village before any async read finishes
const CACHE_KEY = 'zone-profile-cache'

function parse(p: unknown): ZoneProfile | null {
  const z = p as Partial<ZoneProfile> | null
  if (!z || !Array.isArray(z.center) || z.center.length !== 2) return null
  const lat = Number(z.center[0]), lng = Number(z.center[1]), zone = Number(z.zone)
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null
  return {
    zone: Number.isFinite(zone) ? zone : 0,
    village: String(z.village ?? ''),
    center: [lat, lng],
    boundaryLocked: z.boundaryLocked === true,
  }
}

function fromJson(text: string | null | undefined): ZoneProfile | null {
  if (!text) return null
  try { return parse(JSON.parse(text)) } catch { return null }
}

let bundled: Promise<ZoneProfile | null> | null = null
function bundledProfile(): Promise<ZoneProfile | null> {
  bundled ??= fetch(ZONE_FILE)
    .then((r) => r.json() as Promise<unknown>)
    .then(parse)
    .catch(() => { bundled = null; return null })
  return bundled
}

/** Admin override → shipped zone.json → last known → neutral view. */
export async function loadZoneProfile(): Promise<ZoneProfile> {
  const row = await db.geoLayers.get(ZONE_PROFILE_ID)
  const profile = (row && !row.deletedAt ? fromJson(row.geojson) : null) ?? (await bundledProfile())
  if (profile) {
    try { localStorage.setItem(CACHE_KEY, JSON.stringify(profile)) } catch { /* storage full: cache is optional */ }
    return profile
  }
  return cachedZoneProfile()
}

/** Synchronous best guess (last resolved profile on this device). */
export function cachedZoneProfile(): ZoneProfile {
  return fromJson(localStorage.getItem(CACHE_KEY)) ?? EMPTY_PROFILE
}

/** false while no profile could be read (neutral view only). */
export const hasZoneCenter = (p: ZoneProfile) =>
  p.center[0] !== EMPTY_PROFILE.center[0] || p.center[1] !== EMPTY_PROFILE.center[1]

/** Live profile for components; undefined until the first read finishes. */
export function useZoneProfile(): ZoneProfile | undefined {
  return useLiveQuery(() => loadZoneProfile(), [])
}

/** Geo_Layers row carrying the admin override; save it with saveGeoLayer(). */
export function zoneProfileRow(p: ZoneProfile): GeoLayerRecord {
  return {
    id: ZONE_PROFILE_ID,
    name: 'zone-profile',
    kind: 'zoneProfile',
    geojson: JSON.stringify(p),
    createdBy: localStorage.getItem('student-id') ?? 'anon',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
}
