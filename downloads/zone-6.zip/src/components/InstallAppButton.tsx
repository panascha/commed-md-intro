import { useState } from 'react';
import { X } from 'lucide-react';
import { usePwaInstall } from '../ui/usePwaInstall';
import { isInAppBrowser } from '../ui/common';

/** "Install app" button: native prompt on Android/desktop, step-by-step guide on iOS or when no prompt is available. */
export function InstallAppButton({ variant }: { variant: 'menu' | 'settings' }) {
  const { installed, ios, installApp } = usePwaInstall();
  const [guide, setGuide] = useState(false);

  const cls = variant === 'menu'
    ? 'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm hover:bg-gray-50 disabled:opacity-50 disabled:hover:bg-transparent'
    : 'w-full rounded-full border border-gray-300 py-2.5 text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:hover:bg-transparent';

  if (installed) {
    return <button disabled className={cls}>✓ ติดตั้งลงในเครื่องแล้ว</button>;
  }

  const onClick = async () => {
    if ((await installApp()) === 'manual') setGuide(true);
  };

  const inApp = isInAppBrowser();
  return (
    <>
      <button onClick={() => void onClick()} className={cls}>📥 ติดตั้งแอปลงเครื่อง (Install App)</button>
      {guide && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center bg-black/50 p-4" onClick={() => setGuide(false)}>
          <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">ติดตั้งแอปลงเครื่อง</h3>
              <button onClick={() => setGuide(false)} className="grid h-8 w-8 place-items-center rounded-full bg-gray-100" aria-label="ปิด"><X size={16} /></button>
            </div>
            {inApp.detected ? (
              <p className="text-sm text-gray-700">
                เปิดจาก {inApp.vendor} ติดตั้งไม่ได้ — กดเมนู ⋯ แล้วเลือก "เปิดในเบราว์เซอร์" ({ios ? 'Safari' : 'Chrome'}) ก่อน แล้วกดติดตั้งอีกครั้ง
              </p>
            ) : ios ? (
              <ol className="list-decimal space-y-2 pl-5 text-sm text-gray-700">
                <li>กดปุ่มแชร์ (Share ⎋) ที่แถบเครื่องมือของ Safari</li>
                <li>เลื่อนลงแล้วเลือก "เพิ่มไปยังหน้าจอโฮม" (Add to Home Screen ⊞)</li>
                <li>กด "เพิ่ม" (Add) มุมขวาบน</li>
              </ol>
            ) : (
              <ol className="list-decimal space-y-2 pl-5 text-sm text-gray-700">
                <li>เปิดเมนูของเบราว์เซอร์ (⋮)</li>
                <li>เลือก "ติดตั้งแอป" หรือ "เพิ่มไปยังหน้าจอหลัก"</li>
              </ol>
            )}
            <button onClick={() => setGuide(false)} className="mt-4 w-full rounded-full bg-[#1a73e8] py-2.5 text-sm font-medium text-white">เข้าใจแล้ว</button>
          </div>
        </div>
      )}
    </>
  );
}
