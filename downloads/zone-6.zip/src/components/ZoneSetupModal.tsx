import { useState, useRef, useEffect } from 'react'
import L from 'leaflet'
import { X, MapPin, Upload, Pentagon, Home } from 'lucide-react'
import { useLiveQuery } from 'dexie-react-hooks'
import { saveGeoLayer, saveGeoLayers } from '../sync'
import { db, uuid, nowIso, type GeoLayerRecord } from '../db'
import { polygonArea, formatArea, boundaryRing } from '../map/config'
import { useZoneProfile, zoneProfileRow, BUILDINGS_FILE } from '../zone.config'

interface Props {
  onClose: () => void
  map: L.Map | null
  onStartBoundaryDraft?: () => void
}

type BuildingFC = GeoJSON.FeatureCollection<GeoJSON.Polygon>

// Footprints shipped with the site (Google Open Buildings, conf ≥ 0.70), precached by the PWA → works offline.
async function loadBuildings(): Promise<BuildingFC> {
  const res = await fetch(BUILDINGS_FILE)
  if (!res.ok) throw new Error(`buildings.geojson returned ${res.status}`)
  return await res.json() as BuildingFC
}

// Ray-cast point-in-polygon; ring is [lat, lng][] (boundaryRing order).
function insideRing(lat: number, lng: number, ring: [number, number][]): boolean {
  let inside = false
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const [yi, xi] = ring[i], [yj, xj] = ring[j]
    if ((yi > lat) !== (yj > lat) && lng < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside
  }
  return inside
}

// Vertex mean of a footprint's outer ring (closing duplicate excluded) → [lat, lng]
function footprintCenter(f: GeoJSON.Feature<GeoJSON.Polygon>): [number, number] {
  const pts = f.geometry.coordinates[0].slice(0, -1)
  const lng = pts.reduce((s, p) => s + p[0], 0) / pts.length
  const lat = pts.reduce((s, p) => s + p[1], 0) / pts.length
  return [lat, lng]
}

function toGeoLayer(f: GeoJSON.Feature, name: string): GeoLayerRecord {
  return {
    id: uuid(),
    name,
    kind: 'customBuilding',
    geojson: JSON.stringify(f),
    createdBy: localStorage.getItem('student-id') ?? 'anon',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
}

export function ZoneSetupModal({ onClose, map, onStartBoundaryDraft }: Props) {
  const profile = useZoneProfile()
  const [zoneNo, setZoneNo] = useState('')
  const [village, setVillage] = useState('')
  const [center, setCenter] = useState<[number, number] | null>(null)
  const [profileSaved, setProfileSaved] = useState(false)
  const loaded = useRef(false)
  useEffect(() => {
    if (!profile || loaded.current) return // fill the form once; later pulls must not overwrite typing
    loaded.current = true
    setZoneNo(profile.zone ? String(profile.zone) : '')
    setVillage(profile.village)
    setCenter(profile.center)
  }, [profile])
  const [fetching, setFetching] = useState(false)
  const fileInput = useRef<HTMLInputElement>(null)

  const boundaries = useLiveQuery(
    () => db.geoLayers.where('kind').equals('boundary').toArray(),
    [],
  ) ?? []
  // newest live boundary = the active one (saving a new boundary soft-deletes older ones)
  const aliveBoundaries = boundaries.filter((b) => !b.deletedAt).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  const activeBoundary = aliveBoundaries[0] ?? null
  const activeRing = activeBoundary ? boundaryRing(activeBoundary.geojson) : null
  const areaM2 = activeRing ? polygonArea(activeRing) : 0

  const pickMapCenter = () => {
    if (!map) return
    const c = map.getCenter()
    setCenter([Number(c.lat.toFixed(5)), Number(c.lng.toFixed(5))])
  }

  const handleSaveProfile = async () => {
    if (!center) return
    const zone = parseInt(zoneNo, 10)
    await saveGeoLayer(zoneProfileRow({ zone: Number.isFinite(zone) ? zone : 0, village: village.trim(), center, boundaryLocked: locked }))
    if (Number.isFinite(zone)) localStorage.setItem('student-zone', String(zone))
    setProfileSaved(true)
    setTimeout(() => setProfileSaved(false), 2000)
  }

  // Lock = nobody redraws the village boundary until an admin unlocks it (guards against a
  // second coreteam member replacing the agreed polygon by accident).
  const locked = profile?.boundaryLocked === true
  const toggleLock = async () => {
    if (!profile) return
    await saveGeoLayer(zoneProfileRow({ ...profile, boundaryLocked: !locked }))
  }

  const handleImportGeoJSON = () => {
    const file = fileInput.current?.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const gj = JSON.parse(e.target?.result as string) as GeoJSON.FeatureCollection
        if (!gj.features || !Array.isArray(gj.features)) {
          alert('Invalid GeoJSON: expected FeatureCollection with features array')
          return
        }
        const rows: GeoLayerRecord[] = []
        for (const feature of gj.features) {
          if (!feature.geometry || (feature.geometry.type !== 'Polygon' && feature.geometry.type !== 'MultiPolygon')) continue
          const id = feature.properties?.id || feature.id || uuid()
          feature.properties = { ...(feature.properties || {}), id }
          rows.push(toGeoLayer(feature, feature.properties?.name || `imported-building-${id}`))
        }
        saveGeoLayers(rows)
          .then(() => alert(`นำเข้าอาคาร ${rows.length} หลังแล้ว`))
          .catch(() => alert('บันทึกอาคารไม่สำเร็จ'))
      } catch {
        alert('ไม่สามารถอ่านไฟล์ GeoJSON ได้ — ตรวจสอบรูปแบบไฟล์')
      }
    }
    reader.readAsText(file)
  }

  const handleExtractInBoundary = async () => {
    if (!activeRing || activeRing.length < 3 || fetching) return
    setFetching(true)
    try {
      const gj = await loadBuildings()
      // skip roofs already saved as a custom copy (same plus code) → re-running extract adds no duplicates
      const saved = new Set<string>()
      for (const g of await db.geoLayers.where('kind').equals('customBuilding').toArray()) {
        if (g.deletedAt) continue
        try { const pc = (JSON.parse(g.geojson) as GeoJSON.Feature).properties?.plus_code; if (pc) saved.add(pc) } catch { /* skip malformed */ }
      }
      const inside = gj.features.filter((f) => !saved.has(f.properties?.plus_code) && insideRing(...footprintCenter(f), activeRing))
      await saveGeoLayers(inside.map((f) => toGeoLayer(f, `gob-building-${f.properties?.plus_code}`)))
      alert(`สกัดอาคารในกรอบ ${inside.length} หลังแล้ว`)
    } catch {
      alert('ไม่สามารถโหลดข้อมูลอาคารได้')
    } finally {
      setFetching(false)
    }
  }

  return (
    <div className="absolute inset-0 z-[1500] flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="max-h-full w-full max-w-sm overflow-y-auto rounded-2xl bg-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-gray-100 px-5 py-3">
          <h3 className="text-lg font-semibold text-gray-900">🧭 ตั้งค่าพื้นที่</h3>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full bg-gray-100"><X size={16} /></button>
        </div>
        <div className="space-y-4 p-4">
          <div>
            <p className="mb-2 text-sm font-medium text-gray-700">ข้อมูลเขต</p>
            <div className="grid grid-cols-[5rem_1fr] gap-2">
              <label className="block">
                <span className="text-xs font-medium text-gray-600">เขตที่</span>
                <input
                  inputMode="numeric"
                  value={zoneNo}
                  onChange={(e) => setZoneNo(e.target.value)}
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </label>
              <label className="block">
                <span className="text-xs font-medium text-gray-600">ชื่อหมู่บ้าน</span>
                <input
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </label>
            </div>
            <p className="mt-2 text-xs text-gray-500">
              จุดกลางหมู่บ้าน: {center ? `${center[0]}, ${center[1]}` : '—'}
            </p>
            <button
              onClick={pickMapCenter}
              className="mt-1 flex w-full items-center gap-2 rounded-full border border-gray-300 py-2.5 px-4 text-sm text-gray-700 hover:bg-gray-50"
            >
              <MapPin size={16} /> ใช้จุดกึ่งกลางแผนที่ตอนนี้
            </button>
            <button
              onClick={() => { void handleSaveProfile() }}
              disabled={!center}
              className="mt-2 w-full rounded-full bg-blue-600 py-2.5 text-sm font-medium text-white disabled:opacity-40"
            >
              {profileSaved ? 'บันทึกแล้ว ✓' : 'บันทึกข้อมูลเขต'}
            </button>
          </div>

          <div className="border-t border-gray-100 pt-3">
            <p className="mb-2 text-sm font-medium text-gray-700">ขอบเขตชุมชน</p>
            <button
              onClick={() => { onStartBoundaryDraft?.(); onClose() }}
              disabled={locked}
              className="flex w-full items-center gap-2 rounded-full border border-orange-300 bg-orange-50 py-2.5 px-4 text-sm text-orange-800 hover:bg-orange-100 disabled:opacity-40"
            >
              <Pentagon size={16} /> 📐 ตีกรอบขอบเขตชุมชน
            </button>
            {activeBoundary && (
              <button
                onClick={() => { void toggleLock() }}
                className="mt-2 flex w-full items-center gap-2 rounded-full border border-gray-300 py-2.5 px-4 text-sm text-gray-700 hover:bg-gray-50"
              >
                {locked ? '🔓 ปลดล็อกขอบเขต (ให้วาดใหม่ได้)' : '🔒 ล็อกขอบเขตนี้ (กันวาดทับ)'}
              </button>
            )}
            {activeBoundary && areaM2 > 0 && (
              <p className="mt-2 rounded-lg bg-orange-50 px-3 py-2 text-xs text-orange-900">
                ขอบเขต: <b>{activeBoundary.name}</b>
                <br />
                พื้นที่ ~{formatArea(areaM2)}
              </p>
            )}
            {activeRing && activeRing.length >= 3 && (
              <button
                onClick={() => { void handleExtractInBoundary() }}
                disabled={fetching}
                className="mt-2 flex w-full items-center gap-2 rounded-full border border-gray-300 py-2.5 px-4 text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50"
              >
                <Home size={16} className={fetching ? 'animate-spin' : ''} />
                {fetching ? 'กำลังสกัด…' : '🏠 สกัดหลังคาบ้านในกรอบนี้อัตโนมัติ'}
              </button>
            )}
          </div>

          <div className="border-t border-gray-100 pt-3">
            <p className="mb-2 text-sm font-medium text-gray-700">นำเข้าข้อมูลอาคาร</p>
            <div className="space-y-2">
              <input ref={fileInput} type="file" accept=".geojson,.json" className="hidden" onChange={handleImportGeoJSON} />
              <button
                onClick={() => fileInput.current?.click()}
                className="flex w-full items-center gap-2 rounded-full border border-gray-300 py-2.5 px-4 text-sm text-gray-700 hover:bg-gray-50"
              >
                <Upload size={16} /> 📂 อัปโหลดไฟล์ buildings.geojson จากเครื่อง
              </button>
            </div>
            {fetching && (
              <p className="mt-2 text-center text-xs text-blue-600">กำลังโหลดอาคาร… โปรดรอ</p>
            )}
            <p className="mt-1 text-xs text-gray-400">หลังคาของหมู่บ้านแสดงอัตโนมัติ — ข้อมูลมากับแอป ใช้ได้แม้ออฟไลน์</p>
          </div>
        </div>
      </div>
    </div>
  )
}
