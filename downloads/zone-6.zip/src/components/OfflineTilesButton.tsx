import { useEffect, useState } from 'react';
import { cacheTiles, cachedTileCount, isCachingTiles } from '../sync';

/** "Save satellite imagery for offline" button with live % and stored-tile count. */
export function OfflineTilesButton() {
  const [pct, setPct] = useState<number | null>(null); // null = idle
  const [count, setCount] = useState<{ cached: number; total: number } | null>(null);
  const [msg, setMsg] = useState('');

  const refresh = () => { void cachedTileCount().then(setCount); };

  const run = async () => {
    setPct(0);
    setMsg('');
    try {
      const res = await cacheTiles(setPct);
      if (res.total === 0) setMsg('เบราว์เซอร์นี้ไม่รองรับ');
      else if (res.total > 4000) setMsg('ขอบเขตใหญ่เกินไป');
      else if (res.cached === 0) setMsg('ดาวน์โหลดไม่สำเร็จ — ตรวจสอบอินเทอร์เน็ต');
      else if (!res.ok) setMsg(`ได้ ${res.cached}/${res.total} ภาพ — กดอีกครั้งเพื่อโหลดส่วนที่เหลือ`);
      else setMsg('พร้อมใช้ออฟไลน์แล้ว');
    } finally {
      setPct(null);
      refresh();
    }
  };

  // re-attach to a download still running from a previously open panel
  useEffect(() => { refresh(); if (isCachingTiles()) void run(); }, []);

  const busy = pct !== null;
  return (
    <div>
      <button
        onClick={() => void run()}
        disabled={busy}
        className="relative w-full overflow-hidden rounded-full border border-gray-300 py-2.5 text-sm text-gray-700 hover:bg-gray-50 disabled:text-blue-700"
      >
        {busy && <span className="absolute inset-y-0 left-0 bg-blue-100" style={{ width: `${pct}%` }} />}
        <span className="relative">{busy ? `กำลังบันทึกภาพดาวเทียม… ${pct}%` : '📥 บันทึกภาพดาวเทียมไว้ใช้ออฟไลน์'}</span>
      </button>
      <p className="mt-1 text-xs text-gray-400">
        {msg && <span className="text-gray-600">{msg} · </span>}
        {count ? `เก็บไว้ในเครื่อง ${count.cached}/${count.total} ภาพ (ซูม 15–18)` : ''}
      </p>
    </div>
  );
}
