import { useState } from 'react'
import codeGs from '../../gas/Code.gs?raw'
import { GAS_URL_RE, pull, setGasUrl, setStudentRole } from '../sync'
import { findStudent, useRoster, MIN_ID_LENGTH, type Student } from '../roster'
import { signIn, useRosterPull } from './LoginModal'

interface Props {
  onDone: () => void
}

type Step = 1 | 2 | 3 | 4
const STEP_TITLES = ['สร้างชีต', 'Deploy', 'ยืนยันตัวตน', 'แชร์ลิงก์']

const inputCls = 'mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500'
const primaryBtn = 'w-full rounded-full bg-blue-600 py-2.5 text-sm font-medium text-white disabled:opacity-40'
const secondaryBtn = 'w-full rounded-full border border-gray-300 py-2.5 text-sm font-medium text-gray-700'

/** Pull the /exec URL out of a pasted share link (`…?gas=<url>`) or accept a bare /exec URL. */
function gasFromSharedLink(text: string): string | null {
  const t = text.trim()
  if (GAS_URL_RE.test(t)) return t
  try {
    const gas = new URL(t).searchParams.get('gas')?.trim()
    return gas && GAS_URL_RE.test(gas) ? gas : null
  } catch {
    return null
  }
}

/** First-run setup wizard when gas-url is missing: zone lead builds Sheet+GAS, teammates paste the shared link. */
export function OnboardingModal({ onDone }: Props) {
  const [step, setStep] = useState<Step>(1)
  const [teammate, setTeammate] = useState(false)
  const [url, setUrl] = useState('')
  const [sharedLink, setSharedLink] = useState('')
  const [id, setId] = useState('')
  const [name, setName] = useState('')
  const [student, setStudent] = useState<Student | undefined>()
  const [searched, setSearched] = useState(false)
  const [toast, setToast] = useState('')
  // Everyone looks themselves up in the zone's roster (built into the pack, or pulled from the
  // sheet once its URL is saved). With no roster at all, id + name are typed by hand.
  const roster = useRoster()
  const [savedGas, setSavedGas] = useState('')
  const fetching = useRosterPull(roster, teammate ? savedGas : '')
  const manual = !!roster && roster.length === 0 && !fetching
  const idOk = id.replace(/[\s-]/g, '').length >= MIN_ID_LENGTH

  const urlValid = GAS_URL_RE.test(url.trim())
  const sharedGas = gasFromSharedLink(sharedLink)
  const shareUrl = `${location.origin}${location.pathname}?gas=${encodeURIComponent(url.trim())}&openExternalBrowser=1`

  const copy = async (text: string, msg: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setToast(msg)
    } catch {
      setToast('คัดลอกไม่สำเร็จ — กดค้างเพื่อคัดลอกเอง')
    }
    setTimeout(() => setToast(''), 2500)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (manual) {
      if (name.trim()) setStudent({ id: id.trim(), name: name.trim() })
    } else {
      setStudent(findStudent(roster ?? [], id))
    }
    setSearched(true)
  }

  const handleTeammateNext = () => {
    if (!sharedGas) return
    setUrl(sharedGas)
    setGasUrl(sharedGas) // saved now so the roster can be pulled before the identity step
    setSavedGas(sharedGas)
    setStep(3)
  }

  const handleStart = async () => {
    if (!student || !urlValid) return
    const gasUrl = url.trim()
    setGasUrl(gasUrl)
    // Everyone starts as student. Zone lead asks the sheet for developer: GAS grants it only when the
    // Roles tab is empty (new sheet) or they're already developer; the pull also applies it later.
    await signIn(student)
    void pull()
    if (!teammate) {
      const studentId = student.id
      void fetch(gasUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          type: 'role', studentId, name: student.name, role: 'developer', updatedBy: studentId, ts: new Date().toISOString(),
        }),
      })
        .then((r) => r.json() as Promise<{ ok?: boolean }>)
        .then((j) => { if (j.ok && localStorage.getItem('student-id') === studentId) setStudentRole('developer') })
        .catch(() => {})
    }
    onDone()
  }

  const back = () => {
    if (teammate && step === 3) { setStep(1); return }
    setStep((s) => (s > 1 ? ((s - 1) as Step) : s))
  }

  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center bg-black/60 p-4">
      <div className="relative max-h-[85vh] w-full max-w-md overflow-y-auto rounded-2xl bg-white p-5 shadow-2xl">
        <h3 className="text-lg font-semibold text-gray-900">เริ่มต้นใช้งาน COMMED OS</h3>

        {/* Mode tabs — only on the first screen */}
        {step === 1 && (
          <div className="mt-3 grid grid-cols-2 gap-1 rounded-full bg-gray-100 p-1 text-sm">
            <button
              onClick={() => setTeammate(false)}
              className={`rounded-full py-1.5 ${!teammate ? 'bg-white font-medium shadow' : 'text-gray-500'}`}
            >
              หัวหน้าเขต (ตั้งค่าใหม่)
            </button>
            <button
              onClick={() => setTeammate(true)}
              className={`rounded-full py-1.5 ${teammate ? 'bg-white font-medium shadow' : 'text-gray-500'}`}
            >
              สมาชิกในเขต
            </button>
          </div>
        )}

        {/* Progress */}
        {!(teammate && step === 1) && (
          <ol className="mt-4 flex gap-1.5">
            {STEP_TITLES.map((t, i) => (
              <li key={t} className="flex-1">
                <div className={`h-1.5 rounded-full ${i + 1 <= step ? 'bg-blue-600' : 'bg-gray-200'}`} />
                <p className={`mt-1 text-[11px] ${i + 1 === step ? 'font-medium text-blue-700' : 'text-gray-400'}`}>
                  {i + 1}. {t}
                </p>
              </li>
            ))}
          </ol>
        )}

        <div className="mt-4 space-y-3 text-sm text-gray-700">
          {/* Teammate: paste the link from the zone lead */}
          {step === 1 && teammate && (
            <>
              <p className="rounded-lg bg-amber-50 p-3 text-amber-800">
                สมาชิกทั่วไปในเขต <b>ไม่ต้องสร้างชีตใหม่</b> — ขอลิงก์ที่มี <code>?gas=</code> จากหัวหน้าเขตของคุณ
                (ปกติส่งในกลุ่ม LINE ของเขต) แล้วเปิดลิงก์นั้น หรือวางลิงก์ด้านล่าง
              </p>
              <label className="block">
                <span className="font-medium">ลิงก์จากหัวหน้าเขต</span>
                <input
                  type="url"
                  value={sharedLink}
                  onChange={(e) => setSharedLink(e.target.value)}
                  placeholder="https://…/?gas=https://script.google.com/…/exec"
                  className={inputCls}
                />
              </label>
              {sharedLink.trim() && !sharedGas && (
                <p className="text-red-600">ลิงก์ไม่ถูกต้อง — ต้องมี Apps Script URL ที่ลงท้ายด้วย /exec</p>
              )}
              <button onClick={handleTeammateNext} disabled={!sharedGas} className={primaryBtn}>
                ถัดไป — ยืนยันตัวตน
              </button>
            </>
          )}

          {/* Step 1: Sheet + Code.gs */}
          {step === 1 && !teammate && (
            <>
              <p className="font-medium text-gray-900">ขั้นที่ 1 · สร้าง Google Sheet และวางโค้ด Backend</p>
              <a
                href="https://sheets.new"
                target="_blank"
                rel="noopener noreferrer"
                className={`${secondaryBtn} block text-center`}
              >
                เปิด Google Sheet ใหม่ (sheets.new)
              </a>
              <button onClick={() => copy(codeGs, 'คัดลอกโค้ด Code.gs แล้ว')} className={primaryBtn}>
                คัดลอกโค้ด Apps Script (Code.gs)
              </button>
              <ol className="list-decimal space-y-1 pl-5">
                <li>ในชีตใหม่ ไปที่เมนู <b>ส่วนขยาย (Extensions) → Apps Script</b></li>
                <li>ลบโค้ดเดิมทั้งหมด แล้ว <b>วาง</b> โค้ดที่คัดลอกมา</li>
                <li>กด <b>บันทึก</b> (ไอคอนแผ่นดิสก์)</li>
                <li>เลือกฟังก์ชัน <code>setup</code> แล้วกด <b>Run</b> หนึ่งครั้ง (อนุญาตสิทธิ์เมื่อถูกถาม)</li>
              </ol>
              <button onClick={() => setStep(2)} className={primaryBtn}>ถัดไป</button>
            </>
          )}

          {/* Step 2: Deploy + URL */}
          {step === 2 && (
            <>
              <p className="font-medium text-gray-900">ขั้นที่ 2 · Deploy เป็น Web App แล้ววาง URL</p>
              <ol className="list-decimal space-y-1 pl-5">
                <li>กด <b>Deploy → New deployment</b></li>
                <li>ไอคอนเฟือง → เลือก <b>Web app</b></li>
                <li>Execute as: <b><code>Me</code></b></li>
                <li>Who has access: <b><code>Anyone</code></b></li>
                <li>กด <b>Deploy</b> แล้วคัดลอก <b>Web app URL</b></li>
              </ol>
              <label className="block">
                <span className="font-medium">GAS Web App URL</span>
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://script.google.com/macros/s/…/exec"
                  className={inputCls}
                />
              </label>
              {url.trim() && !urlValid && (
                <p className="text-red-600">URL ต้องเป็น https://script.google.com/…/exec</p>
              )}
              <button onClick={() => setStep(3)} disabled={!urlValid} className={primaryBtn}>ถัดไป</button>
            </>
          )}

          {/* Step 3: identity */}
          {step === 3 && (
            <>
              <p className="font-medium text-gray-900">ขั้นที่ 3 · ยืนยันตัวตน</p>
              {fetching && <p className="rounded-lg bg-blue-50 p-3 text-blue-700">กำลังดึงรายชื่อของเขต…</p>}
              {manual && (
                <p className="rounded-lg bg-amber-50 p-3 text-amber-800">
                  ยังไม่มีรายชื่อของเขตในเครื่องนี้ — กรอกรหัสและชื่อของคุณเองได้เลย
                </p>
              )}
              <form onSubmit={handleSearch}>
                <label className="block">
                  <span className="font-medium">รหัสนักศึกษา</span>
                  <input
                    inputMode="numeric"
                    value={id}
                    onChange={(e) => { setId(e.target.value); setSearched(false); setStudent(undefined) }}
                    placeholder="เช่น 650000001"
                    className={inputCls}
                  />
                </label>
                {manual && (
                  <label className="mt-2 block">
                    <span className="font-medium">ชื่อ-นามสกุล</span>
                    <input
                      value={name}
                      onChange={(e) => { setName(e.target.value); setSearched(false); setStudent(undefined) }}
                      className={inputCls}
                    />
                  </label>
                )}
                <button type="submit" disabled={!idOk || fetching || (manual && !name.trim())} className={`${primaryBtn} mt-2`}>
                  ตรวจสอบรหัส
                </button>
              </form>
              {searched && !student && (
                <p className="rounded-lg bg-red-50 p-3 text-red-700">ไม่พบรหัสนักศึกษาในรายชื่อของเขต — ตรวจสอบรหัส หรือแจ้งหัวหน้าเขต</p>
              )}
              {student && (
                <div className="rounded-xl bg-blue-50 p-4 text-gray-800">
                  <p className="font-semibold">{student.name}</p>
                  <p>รหัส: {student.id}</p>
                  {student.house && <p>บ้านพักหลังที่: {student.house}</p>}
                  <button
                    onClick={() => (teammate ? void handleStart() : setStep(4))}
                    className="mt-3 w-full rounded-full bg-emerald-600 py-2.5 font-medium text-white"
                  >
                    {teammate ? 'ใช่ นี่คือฉัน — เริ่มใช้งาน' : 'ใช่ นี่คือฉัน → ถัดไป'}
                  </button>
                </div>
              )}
            </>
          )}

          {/* Step 4: share + start */}
          {step === 4 && (
            <>
              <p className="font-medium text-gray-900">ขั้นที่ 4 · สำเร็จ! แชร์ลิงก์ให้เพื่อนในเขต</p>
              <p>เพื่อนในเขตเปิดลิงก์นี้แล้วใช้ชีตเดียวกันได้ทันที ไม่ต้องตั้งค่าเอง</p>
              <p className="break-all rounded-lg bg-gray-50 p-3 font-mono text-xs text-gray-600">{shareUrl}</p>
              <button onClick={() => copy(shareUrl, 'คัดลอกลิงก์แล้ว — วางในกลุ่ม LINE ของเขตได้เลย')} className={primaryBtn}>
                คัดลอกลิงก์ส่งเข้ากลุ่ม LINE ของเขต
              </button>
              {manual && (
                <p className="rounded-lg bg-amber-50 p-3 text-amber-800">
                  ก่อนส่งลิงก์: เข้าเมนู ☰ → ตั้งค่า → <b>รายชื่อนักศึกษา</b> วางรายชื่อของเขต แล้วกด <b>ส่งข้อมูล</b> 1 ครั้ง
                  เพื่อนจะยืนยันตัวด้วยรหัสนักศึกษาได้ทันที
                </p>
              )}
              <button onClick={() => { void handleStart() }} className="w-full rounded-full bg-emerald-600 py-2.5 font-medium text-white">
                เริ่มต้นใช้งานแผนที่
              </button>
            </>
          )}

          {step > 1 && (
            <button onClick={back} className={secondaryBtn}>ย้อนกลับ</button>
          )}

          {step === 1 && !teammate && (
            <p className="border-t pt-3 text-xs text-gray-500">
              หากคุณเป็นนักศึกษาทั่วไปในเขต ไม่ต้องสร้างชีตใหม่ ให้ขอลิงก์ที่มี <code>?gas=</code> จากหัวหน้าเขตของคุณ —{' '}
              <button onClick={() => setTeammate(true)} className="text-blue-600 underline">วางลิงก์ที่ได้รับ</button>
            </p>
          )}
        </div>

        {toast && (
          <div className="sticky bottom-0 mt-3 rounded-lg bg-gray-900 px-3 py-2 text-center text-sm text-white">{toast}</div>
        )}
      </div>
    </div>
  )
}
