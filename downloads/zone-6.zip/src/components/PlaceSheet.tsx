import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, uuid, nowIso, placeIdForBuilding, type Place, type NoteRecord } from '../db';
import { savePlace, saveNote, savePhotoBlob, softDeletePlace, softDeletePhoto, compressImage, canDeleteRow } from '../sync';
import { Modal, confirmAction, CautionBadge } from '../ui/common';
import { Camera, FileText, Trash2, Users, X } from 'lucide-react';

export const TAGS: { value: Place['tag']; label: string; color: string }[] = [
  { value: 'house', label: 'บ้าน', color: '#eab308' },
  { value: 'lodging', label: 'บ้านพัก นศพ. 🏥', color: '#2563eb' },
  { value: 'shop', label: 'ร้านค้า', color: '#f59e0b' },
  { value: 'temple', label: 'วัด', color: '#f97316' },
  { value: 'school', label: 'โรงเรียน', color: '#0891b2' },
  { value: 'community_hall', label: 'ศาลาชุมชน', color: '#6366f1' },
  { value: 'bus_stop', label: 'จุดจอดรถบัส 🚌', color: '#059669' },
  { value: 'other', label: 'อื่นๆ', color: '#6b7280' },
];

export type Target =
  | { kind: 'new'; lat: number; lng: number; buildingId: string | null }
  | { kind: 'place'; placeId: string };

interface Props {
  target: Target;
  onClose: () => void;
  onSaved: (placeId: string) => void;
  onError: (msg: string) => void;
  onOpenPeople: (placeId: string) => void;
  /** Receives the guarded close (dirty-state confirm) so Android Back can use it. */
  closeRef?: React.MutableRefObject<(() => void) | null>;
}

/** House number: saved on blur/Enter. */
function HouseNo({ place, onSave }: { place: Place; onSave: (v: string) => void }) {
  const [v, setV] = useState(place.houseNo ?? '');
  const [editing, setEditing] = useState(false);
  React.useEffect(() => { if (!editing) setV(place.houseNo ?? ''); }, [place.houseNo, editing]);
  return (
    <label className="mt-1 flex items-center gap-1.5 text-[13px] text-gray-500">
      บ้านเลขที่
      <input value={v} maxLength={30} placeholder="ระบุ"
        onFocus={() => setEditing(true)}
        onChange={(e) => setV(e.target.value)}
        onBlur={() => { setEditing(false); if (v.trim() !== (place.houseNo ?? '')) onSave(v.trim()); }}
        onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
        className="w-28 rounded-md border border-gray-200 px-2 py-0.5 text-[14px] text-gray-900 outline-none focus:border-blue-500" />
    </label>
  );
}

/** Photo grid for a place: tap to add. */
function PhotoGrid({ placeId, onError }: { placeId: string; onError: (m: string) => void }) {
  const photos = useLiveQuery(
    () => db.photos.where('placeId').equals(placeId).toArray(),
    [placeId]
  );

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = ''; // the same photo can be picked again
    for (const file of files) {
      try {
        const base64 = await compressImage(file);
        await savePhotoBlob(placeId, base64);
      } catch (err) {
        onError('อ่านรูปไม่สำเร็จ: ' + (err as Error).message);
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!(await confirmAction('ลบรูปภาพ', 'ต้องการลบรูปนี้หรือไม่?', 'ลบ', true))) return;
    try {
      await softDeletePhoto(id);
    } catch (err) {
      onError('ลบรูปไม่สำเร็จ: ' + (err as Error).message);
    }
  };

  // local base64 when this device took it; Drive thumbnail when pulled from another device
  const allPhotos = (photos ?? []).filter((p) => !p.deletedAt && (p.base64 || p.url));

  return (
    <div className="space-y-2">
      {allPhotos.length > 0 && (
        <div className="grid grid-cols-4 gap-2">
          {allPhotos.map((p) => (
            <div key={p.id} className="relative">
              <img src={p.base64 || p.url} alt="place" loading="lazy" referrerPolicy="no-referrer" className="h-20 w-full rounded-lg bg-gray-100 object-cover" />
              {canDeleteRow(p.createdBy) && (
                <button onClick={() => void handleDelete(p.id)} aria-label="ลบรูป"
                  className="absolute -right-1.5 -top-1.5 grid h-6 w-6 place-items-center rounded-full bg-black/70 text-white shadow">
                  <X size={14} />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
      <label className="flex cursor-pointer items-center gap-2 rounded-lg border-2 border-dashed border-gray-300 px-4 py-3 text-sm text-gray-500 hover:border-blue-400">
        <Camera size={18} />
        <span>เพิ่มรูปภาพ</span>
        {/* no `capture`: the phone offers camera AND gallery; display:none keeps the native control off screen */}
        <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { void handleFile(e); }} />
      </label>
    </div>
  );
}

export function PlaceSheet({ target, onClose, onSaved, onError, onOpenPeople, closeRef }: Props) {
  const isNew = target.kind === 'new';

  // When target says "new" but has a buildingId, check if a place for that
  // building already exists (e.g. from a stale click closure).  If so, treat
  // it as an existing place to avoid creating a duplicate.
  const byBid = useLiveQuery(
    () => target.kind === 'new' && target.buildingId
      ? db.places.where('buildingId').equals(target.buildingId).filter((p) => !p.deletedAt).first()
      : undefined,
    [target]
  )

  const resolvedPlaceId = byBid ? byBid.id : (target.kind === 'place' ? target.placeId : null)
  const existing = useLiveQuery(
    () => resolvedPlaceId ? db.places.get(resolvedPlaceId) : undefined,
    [resolvedPlaceId]
  )

  const notes = useLiveQuery(
    () => existing ? db.notes.where('placeId').equals(existing.id).filter((n) => !n.deletedAt).toArray() : [],
    [existing?.id]
  );
  const persons = useLiveQuery(
    () => existing ? db.persons.where('placeId').equals(existing.id).filter((p) => !p.deletedAt).toArray() : [],
    [existing?.id]
  );

  const place = existing && !existing.deletedAt ? existing : null;
  const [tag, setTag] = useState<Place['tag']>(place?.tag ?? 'house');
  // Sync tag when the resolved place loads (existing place for a "new" target).
  React.useEffect(() => { if (place) setTag(place.tag); }, [place?.id]);
  const [body, setBody] = useState('');
  const [isCaution, setIsCaution] = useState(false);
  const [saving, setSaving] = useState(false);

  // Close via ✕ / backdrop / ยกเลิก / Android Back. Notes, photos and members are already saved
  // to Dexie; only a typed-but-unsaved note or an unsaved type change is lost. Blur first so an
  // on-blur field (house no.) commits before unmount.
  const requestClose = async () => {
    (document.activeElement as HTMLElement | null)?.blur?.();
    const dirty = body.trim().length > 0 || tag !== (place?.tag ?? 'house');
    if (dirty && !(await confirmAction('ยังไม่ได้บันทึก', 'มีข้อมูลที่ยังไม่ได้บันทึก ต้องการปิดหน้านี้หรือไม่?', 'ปิดโดยไม่บันทึก', true, 'กลับไปแก้ไข'))) return;
    onClose();
  };
  if (closeRef) closeRef.current = () => void requestClose();

  const handleSave = async () => {
    if (saving) return;
    setSaving(true);
    try {
      if (!place) {
        if (!isNew) return; // target place was deleted meanwhile
        const buildingId = target.buildingId ?? undefined;
        // Roof → deterministic id, so two phones tapping the same roof offline
        // converge on one row. Reuse a soft-deleted row on that roof (undelete).
        const id = buildingId ? placeIdForBuilding(buildingId) : uuid();
        const prior = buildingId ? await db.places.get(id) : undefined;
        const p: Place = prior
          ? { ...prior, tag, deletedAt: undefined }
          : {
              id,
              buildingId,
              houseNo: '',
              tag,
              status: 'unvisited',
              lat: target.lat,
              lng: target.lng,
              createdBy: '',
              createdAt: nowIso(),
              updatedAt: nowIso(),
            };
        await savePlace(p);
        await saveTypedNote(p.id); // place first: note FK order in the outbox
        onSaved(p.id);
      } else {
        // preserve lat/lng so Google Sheet columns are never overwritten with 0
        await savePlace({ ...place, tag, lat: place.lat, lng: place.lng });
        await saveTypedNote(place.id); // don't drop a typed-but-unsaved note
        onSaved(place.id);
      }
    } catch (err) {
      onError('บันทึกไม่สำเร็จ: ' + (err as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!place) return;
    const ok = await confirmAction('ลบบ้านนี้', `ลบบ้านเลขที่ ${place.houseNo || '(ไม่มีเลขที่)'} หรือไม่? บันทึก รูปภาพ สมาชิก และความสัมพันธ์ของบ้านนี้จะถูกลบด้วย`, 'ลบ', true);
    if (!ok) return;
    try {
      await softDeletePlace(place.id);
      onClose();
    } catch (err) {
      onError('ลบไม่สำเร็จ: ' + (err as Error).message);
    }
  };

  // Typed note → saved under placeId; no-op when the box is empty.
  const saveTypedNote = async (placeId: string) => {
    if (!body.trim()) return;
    const n: NoteRecord = {
      id: uuid(),
      placeId,
      body: body.trim(),
      isCaution: isCaution ? 1 : 0,
      author: '',
      createdAt: nowIso(),
      updatedAt: nowIso(),
    };
    await saveNote(n);
    setBody('');
    setIsCaution(false);
  };

  const handleNoteSave = async () => {
    if (!place || !body.trim()) return;
    try {
      await saveTypedNote(place.id);
    } catch (err) {
      onError('บันทึกบันทึกไม่สำเร็จ: ' + (err as Error).message);
    }
  };

  const liveNotes = notes ?? [];
  const cautionCount = liveNotes.filter((n) => n.isCaution).length;

  return (
    <Modal title={place ? `บ้านเลขที่ ${place.houseNo || '(ไม่มีเลขที่)'}` : 'บ้านใหม่'} onClose={() => void requestClose()}>
      <div className="space-y-4">
        {/* Tag selector */}
        <div>
          <p className="mb-2 text-sm font-medium text-gray-700">ประเภท</p>
          <div className="-mx-4 flex gap-2 overflow-x-auto px-4 [scrollbar-width:none]">
            {TAGS.map((t) => (
              <button
                key={t.value}
                onClick={() => setTag(t.value)}
                className={`shrink-0 whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-medium ${
                  tag === t.value ? 'text-white' : 'bg-gray-100 text-gray-700'
                }`}
                style={{ backgroundColor: tag === t.value ? t.color : undefined }}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* House number */}
        {place && <HouseNo place={place} onSave={(v) => savePlace({ ...place, houseNo: v })} />}

        {/* Existing notes */}
        {liveNotes.length > 0 && (
          <div>
            <div className="mb-2 flex items-center gap-2">
              <FileText size={16} className="text-gray-500" />
              <span className="text-sm font-medium text-gray-700">บันทึก ({liveNotes.length})</span>
              {cautionCount > 0 && <CautionBadge count={cautionCount} />}
            </div>
            <div className="space-y-2">
              {liveNotes.map((n) => (
                <div key={n.id} className={`rounded-lg px-3 py-2 text-sm ${n.isCaution ? 'bg-red-50 text-red-800' : 'bg-gray-50 text-gray-800'}`}>
                  {n.isCaution === 1 && <span className="mr-1 font-medium">⚠️</span>}
                  {n.body}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* New note. On a brand-new pin the main บันทึก button saves place + this note together. */}
        {(place || isNew) && (
          <div>
            <p className="mb-2 text-sm font-medium text-gray-700">{place ? 'เพิ่มบันทึกใหม่' : 'บันทึก (ไม่บังคับ)'}</p>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="บันทึกการเยี่ยมบ้าน..."
              rows={3}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <label className="mt-2 flex items-center gap-2 text-sm text-gray-700">
              <input type="checkbox" checked={isCaution} onChange={(e) => setIsCaution(e.target.checked)} className="h-4 w-4 rounded border-gray-300" />
              <span>⚠️ ข้อควรระวัง (Caution)</span>
            </label>
            {place && (
              <button
                onClick={handleNoteSave}
                disabled={!body.trim()}
                className="mt-2 w-full rounded-full bg-emerald-600 py-2.5 text-sm font-medium text-white disabled:opacity-50"
              >
                บันทึกโน้ต
              </button>
            )}
          </div>
        )}

        {/* Photos */}
        {place && (
          <div>
            <p className="mb-2 text-sm font-medium text-gray-700">รูปภาพ</p>
            <PhotoGrid placeId={place.id} onError={onError} />
          </div>
        )}

        {/* Persons link */}
        {place && (
          <button
            onClick={() => onOpenPeople(place.id)}
            className="flex w-full items-center gap-2 rounded-lg border border-gray-200 px-3 py-2.5 text-sm text-gray-800 hover:bg-gray-50"
          >
            <Users size={18} className="text-blue-600" />
            <span>สมาชิกในบ้าน ({(persons ?? []).length} คน)</span>
          </button>
        )}

        {/* Save / Delete / Cancel */}
        <div className="flex gap-2 border-t border-gray-100 pt-3">
          <button
            onClick={() => void requestClose()}
            className="flex-1 rounded-full border border-gray-300 py-3 text-sm text-gray-700"
          >
            ยกเลิก
          </button>
          {place && canDeleteRow(place.createdBy) && (
            <button
              onClick={handleDelete}
              className="rounded-full bg-red-100 px-4 py-3 text-sm font-medium text-red-700"
              aria-label="ลบ"
            >
              <Trash2 size={16} />
            </button>
          )}
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 whitespace-nowrap rounded-full bg-blue-600 px-4 py-3 text-sm font-medium text-white disabled:opacity-50"
          >
            {saving ? 'กำลังบันทึก...' : place ? 'บันทึกการเปลี่ยนแปลง' : 'บันทึก'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
