import type L from 'leaflet'

// No village coordinates here: the zone's centre comes from zone.config.ts (zone.json / admin override).

// Esri satellite is the default basemap (avoids OSM IP-block risk during group recon)
export const BASEMAPS = {
  sat: { label: 'ดาวเทียม', url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', attr: 'Esri', nativeMax: 18 },
  osm: { label: 'แผนที่', url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', attr: '© OpenStreetMap', nativeMax: 19 },
} as const
export type BaseKey = keyof typeof BASEMAPS
export const DEFAULT_BASE: BaseKey = 'sat'

export const MAX_ZOOM = 22

export function tileXY(lat: number, lng: number, z: number) {
  const n = 2 ** z
  const x = Math.floor(((lng + 180) / 360) * n)
  const r = (lat * Math.PI) / 180
  const y = Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n)
  return { x, y }
}

/** m² of a [lat, lng] ring: shoelace on a local equirectangular projection (error ≪ 1% at village scale) */
export function polygonArea(pts: [number, number, number?][]): number {
  if (pts.length < 3) return 0
  const R = 6371008.8, rad = Math.PI / 180
  const k = Math.cos(pts.reduce((s, p) => s + p[0], 0) / pts.length * rad)
  let a = 0
  for (let i = 0; i < pts.length; i++) {
    const [lat1, lng1] = pts[i], [lat2, lng2] = pts[(i + 1) % pts.length]
    a += lng1 * k * lat2 - lng2 * k * lat1
  }
  return Math.abs(a) / 2 * (R * rad) ** 2
}

// 1 ไร่ = 1600 m², 1 งาน = 400 m², 1 ตร.วา = 4 m² (floored: never prints "100 ตร.วา")
export function raiNgan(m2: number) {
  const rai = Math.floor(m2 / 1600)
  const ngan = Math.floor((m2 - rai * 1600) / 400)
  return { rai, ngan, wa: Math.floor((m2 - rai * 1600 - ngan * 400) / 4) }
}

/** "2 ไร่ 1 งาน 37 ตร.วา (3,748 ตร.ม.)" */
export function formatArea(m2: number): string {
  const { rai, ngan, wa } = raiNgan(m2)
  return `${rai} ไร่ ${ngan} งาน ${wa} ตร.วา (${Math.round(m2).toLocaleString()} ตร.ม.)`
}

export const BOUNDARY_STYLE: L.PathOptions = { color: '#f97316', weight: 3, fillColor: '#f97316', fillOpacity: 0.06 }
export const DRAFT_ROOF_STYLE: L.PathOptions = { color: '#1a73e8', weight: 3, fillColor: '#1a73e8', fillOpacity: 0.15 }
export const IDLE_STYLE: L.PathOptions = { color: '#ffffff', weight: 1, opacity: 0.8, fillColor: '#ffffff', fillOpacity: 0.12 }
export const DIM_STYLE: L.PathOptions = { color: '#bbbbbb', weight: 1, opacity: 0.6, fillColor: '#999999', fillOpacity: 0.1 }
export const SNAP_HIGHLIGHT_STYLE: L.PathOptions = { color: '#22c55e', weight: 3 }

/** [lat, lng] ring of a stored boundary GeoJSON (Polygon / LineString, bare or Feature). */
export function boundaryRing(geojson: string): [number, number][] | null {
  try {
    const gj = JSON.parse(geojson) as GeoJSON.Geometry | GeoJSON.Feature
    const geom = (gj as GeoJSON.Feature).geometry ?? (gj as GeoJSON.Geometry)
    if (geom.type === 'Polygon') {
      return geom.coordinates[0].map(([lng, lat]) => [lat, lng] as [number, number])
    }
    if (geom.type === 'LineString') {
      return geom.coordinates.map(([lng, lat]) => [lat, lng] as [number, number])
    }
  } catch { /* skip */ }
  return null
}

export type Bbox = { s: number; n: number; w: number; e: number }
const TILE_LIST_CAP = 20000

export function bboxTileUrls(bbox: Bbox, minZ = 15, maxZ = 18): string[] {
  const urls: string[] = []
  for (let z = minZ; z <= maxZ; z++) {
    const a = tileXY(bbox.n, bbox.w, z)
    const b = tileXY(bbox.s, bbox.e, z)
    // an oversized boundary would build millions of strings before the caller's MAX_TILES check:
    // stop once the list is clearly over any sane cap (callers treat a long list as "too big")
    if (urls.length + (b.x - a.x + 1) * (b.y - a.y + 1) > TILE_LIST_CAP) { urls.length = TILE_LIST_CAP + 1; return urls }
    for (let x = a.x; x <= b.x; x++) {
      for (let y = a.y; y <= b.y; y++) {
        urls.push(BASEMAPS.sat.url.replace('{z}', String(z)).replace('{x}', String(x)).replace('{y}', String(y)))
      }
    }
  }
  return urls
}

// Snap-to-roof: vertex taps within this distance of a footprint edge snap onto that edge/vertex
// instead of dropping a free-floating point (drafting is touch-first; fat-finger precision is poor).
export const SNAP_METERS = 15

// NOTE: auto-fit-bounds from buildings.geojson is done in MapView itself via
// `L.geoJSON(gj).getBounds()` right after the fetch — no util needed here (avoids
// importing the full 'leaflet' module into a file that's also used for pure math).
