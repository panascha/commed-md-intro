// v2 roof status: 5 levels (refused removed, prepared added)
// Unvisited = grey (IDLE_STYLE), not listed here.

export const ROOF_STATUS = {
  family_study: { label: 'ครอบครัวกรณีศึกษา', color: '#9333ea' },
  completed: { label: 'เก็บข้อมูลครบ', color: '#16a34a' },
  in_progress: { label: 'กำลังเก็บข้อมูล', color: '#eab308' },
  prepared: { label: 'เตรียมการ (บ้านเลขที่)', color: '#2563eb' },
} as const
export type RoofStatus = keyof typeof ROOF_STATUS

import type { NoteRecord, PersonRecord, Place } from '../db'

/** Status of one place. Priority: family study > completed > in_progress > prepared. */
export function placeStatus(
  p: Place,
  notes: NoteRecord[],
  persons: PersonRecord[],
): RoofStatus | null {
  const ps = persons.filter((x) => x.placeId === p.id && !x.deletedAt)
  if (ps.length >= 1) return 'family_study'
  const ns = notes.filter((n) => n.placeId === p.id && !n.deletedAt)
  if (ns.some((n) => n.body && !n.isCaution)) return 'completed'
  if (ns.length > 0 || (p.houseNo && p.houseNo.trim())) return 'in_progress'
  return 'prepared'
}

/** Group live (not soft-deleted) rows by placeId. */
export function groupByPlace<T extends { placeId: string; deletedAt?: string }>(rows: T[]): Map<string, T[]> {
  const by = new Map<string, T[]>()
  for (const r of rows) {
    if (r.deletedAt) continue
    const a = by.get(r.placeId)
    if (a) a.push(r); else by.set(r.placeId, [r])
  }
  return by
}

/** Best status per building id across its live places (one pass, indexed lookups). */
export function buildingStatuses(places: Place[], notes: NoteRecord[], persons: PersonRecord[]): Map<string, RoofStatus> {
  const rank: RoofStatus[] = ['family_study', 'completed', 'in_progress', 'prepared']
  const notesBy = groupByPlace(notes)
  const personsBy = groupByPlace(persons)
  const best = new Map<string, RoofStatus>()
  for (const p of places) {
    if (!p.buildingId || p.deletedAt) continue
    const s = placeStatus(p, notesBy.get(p.id) ?? [], personsBy.get(p.id) ?? [])
    const cur = best.get(p.buildingId)
    if (s && (!cur || rank.indexOf(s) < rank.indexOf(cur))) best.set(p.buildingId, s)
  }
  return best
}

export interface RoofStyle { fillColor: string; color: string; fillOpacity: number; weight: number }

/** Leaflet style for one roof given its status (undefined = unvisited) and the active filter. */
export function roofStyle(status: RoofStatus | undefined, filter: RoofStatus | 'all', idle: RoofStyle): RoofStyle {
  const base = status ? ROOF_STATUS[status].color : null
  if (filter === 'all') return { fillColor: base ?? idle.fillColor, color: base ?? idle.color, fillOpacity: 0.5, weight: idle.weight }
  if (status === filter) return { fillColor: base ?? idle.fillColor, color: base ?? idle.color, fillOpacity: 0.75, weight: 2 }
  return { fillColor: '#94a3b8', color: '#cbd5e1', fillOpacity: 0.1, weight: 1 }
}