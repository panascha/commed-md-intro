import { useLiveQuery } from 'dexie-react-hooks'
import { db, nowIso, type GeoLayerRecord } from './db'
import students from './students.json'

export interface Student {
  id: string
  name: string
  house?: string
}

// Two sources, in order:
//   1. the roster a developer/coreteam saved in Settings: one Geo_Layers row (kind 'roster',
//      JSON in `geojson`), so the normal push/pull hands it to every phone of the zone;
//   2. src/students.json built into the site. The build keeps only the rows of this site's zone
//      (see zoneRoster() in vite.config.ts), so a zone pack never carries another zone's names.
// students.json may hold only id, name, zone, house. Never add e-mail, phone or citizen id.
const BUNDLED: Student[] = (students as { id: string; name: string; house?: string | number }[])
  .filter((s) => s && s.id && s.name)
  .map((s) => (s.house != null && s.house !== '' ? { id: String(s.id), name: s.name, house: String(s.house) } : { id: String(s.id), name: s.name }))

export const ROSTER_ID = 'roster'
// A Google Sheets cell holds 50,000 characters; stay under it.
export const ROSTER_MAX_CHARS = 45000
/** One zone is ~70–80 students; more than this is almost certainly the whole class pasted in. */
export const ROSTER_MAX_STUDENTS = 120

function fromRow(row?: GeoLayerRecord): Student[] | null {
  if (!row || row.deletedAt) return null
  try {
    const list = JSON.parse(row.geojson) as unknown
    return Array.isArray(list) ? (list as Student[]).filter((s) => s && s.id && s.name) : null
  } catch {
    return null
  }
}

export async function loadRoster(): Promise<Student[]> {
  return fromRow(await db.geoLayers.get(ROSTER_ID)) ?? BUNDLED
}

/** Live roster; undefined until the first read finishes. */
export function useRoster(): Student[] | undefined {
  return useLiveQuery(() => loadRoster(), [])
}

/** Geo_Layers row carrying the roster; save it with saveGeoLayer(). */
export function rosterRow(students: Student[]): GeoLayerRecord {
  return {
    id: ROSTER_ID,
    name: 'roster',
    kind: 'roster',
    geojson: JSON.stringify(students),
    createdBy: localStorage.getItem('student-id') ?? 'anon',
    createdAt: nowIso(),
    updatedAt: nowIso(),
  }
}

const clean = (s: string) => s.replace(/[\s-]/g, '')
export const MIN_ID_LENGTH = 5

export function findStudent(roster: Student[], input: string): Student | undefined {
  const typed = clean(input)
  if (typed.length < MIN_ID_LENGTH) return undefined
  return roster.find((s) => {
    const sid = clean(s.id)
    // KKU ids are 9 digits + check digit ("650000001-0"); typing the 9 digits is enough
    return sid === typed || (typed.length === 9 && sid.length === 10 && sid.startsWith(typed))
  })
}

// ---- import ------------------------------------------------------------------------

const ID_HEADERS = ['id', 'รหัส', 'รหัสนักศึกษา', 'studentid', 'student id', 'รหัสประจำตัว']
const NAME_HEADERS = ['name', 'ชื่อ', 'ชื่อ-นามสกุล', 'ชื่อ-สกุล', 'ชื่อนามสกุล', 'ชื่อ - สกุล']
const HOUSE_HEADERS = ['house', 'หลังที่', 'บ้านพัก', 'บ้านพักหลังที่', 'บ้าน']

/** Split one CSV line, honouring "quoted, cells" and "" escapes. */
function splitCsv(line: string): string[] {
  const out: string[] = []
  let cur = '', quoted = false
  for (let i = 0; i < line.length; i++) {
    const c = line[i]
    if (quoted) {
      if (c === '"' && line[i + 1] === '"') { cur += '"'; i++ }
      else if (c === '"') quoted = false
      else cur += c
    } else if (c === '"') quoted = true
    else if (c === ',') { out.push(cur); cur = '' }
    else cur += c
  }
  out.push(cur)
  return out
}

export interface RosterParse {
  students: Student[]
  skipped: number // non-blank lines without both an id and a name
  error?: string
}

/** Accepts a paste from Excel/Sheets (tab-separated), CSV text, or a JSON array.
 *  Columns: id, name, house (optional). A header row is detected and may reorder them. */
export function parseRoster(text: string): RosterParse {
  const body = text.replace(/^﻿/, '').trim()
  if (!body) return { students: [], skipped: 0, error: 'ยังไม่มีข้อมูลรายชื่อ' }

  let rows: string[][]
  if (body.startsWith('[')) {
    try {
      const list = JSON.parse(body) as Record<string, unknown>[]
      rows = list.map((o) => [String(o.id ?? o['รหัส'] ?? ''), String(o.name ?? o['ชื่อ'] ?? ''), String(o.house ?? o['หลังที่'] ?? '')])
    } catch {
      return { students: [], skipped: 0, error: 'อ่านไฟล์ JSON ไม่ได้ — ตรวจสอบรูปแบบไฟล์' }
    }
  } else {
    const lines = body.split(/\r?\n/).filter((l) => l.trim())
    const tabbed = lines.some((l) => l.includes('\t'))
    rows = lines.map((l) => (tabbed ? l.split('\t') : splitCsv(l)).map((c) => c.trim()))
  }

  // header row → column positions; otherwise id, name, house in that order
  let idCol = 0, nameCol = 1, houseCol = 2
  const head = (rows[0] ?? []).map((c) => c.toLowerCase())
  const at = (names: string[]) => head.findIndex((c) => names.includes(c))
  if (at(ID_HEADERS) >= 0 || at(NAME_HEADERS) >= 0) {
    idCol = at(ID_HEADERS); nameCol = at(NAME_HEADERS); houseCol = at(HOUSE_HEADERS)
    if (idCol < 0 || nameCol < 0) return { students: [], skipped: 0, error: 'หัวตารางต้องมีคอลัมน์ "รหัส" และ "ชื่อ"' }
    rows = rows.slice(1)
  }

  const byId = new Map<string, Student>()
  let skipped = 0
  for (const r of rows) {
    const id = (r[idCol] ?? '').trim(), name = (r[nameCol] ?? '').trim()
    if (clean(id).length < MIN_ID_LENGTH || !name) { skipped++; continue }
    const house = houseCol >= 0 ? (r[houseCol] ?? '').trim() : ''
    byId.set(clean(id), house ? { id, name, house } : { id, name }) // same id twice → last row wins
  }
  const students = [...byId.values()]
  if (students.length === 0) return { students, skipped, error: 'ไม่พบแถวที่มีทั้งรหัสและชื่อ' }
  if (students.length > ROSTER_MAX_STUDENTS) {
    return { students: [], skipped, error: `รายชื่อมี ${students.length} คน เกิน ${ROSTER_MAX_STUDENTS} คน — ใส่เฉพาะนักศึกษาในเขตของคุณ ไม่ใช่ทั้งรุ่น` }
  }
  if (JSON.stringify(students).length > ROSTER_MAX_CHARS) {
    return { students: [], skipped, error: `รายชื่อยาวเกินไป (${students.length} คน) — ใส่เฉพาะนักศึกษาของเขตนี้` }
  }
  return { students, skipped }
}

/** Read an uploaded roster file. Thai Excel often saves CSV as Windows-874, not UTF-8. */
export async function readRosterFile(file: File): Promise<string> {
  const buf = await file.arrayBuffer()
  const utf8 = new TextDecoder('utf-8').decode(buf)
  if (!utf8.includes('�')) return utf8
  try {
    return new TextDecoder('windows-874').decode(buf)
  } catch {
    return utf8
  }
}
