import { registerSW } from 'virtual:pwa-register'

// autoUpdate: the new service worker activates on its own; we only choose WHEN to reload,
// so a half-typed note or half-drawn boundary is never wiped. App calls applyUpdate()
// once no sheet, modal, confirm dialog or drawing session is open.
let ready = false
const listeners = new Set<() => void>()
export const onUpdateReady = (l: () => void) => { listeners.add(l); if (ready) l(); return () => { listeners.delete(l) } }
export const applyUpdate = () => window.location.reload()

registerSW({
  immediate: true,
  onNeedReload() { ready = true; listeners.forEach((l) => l()) },
  onRegisteredSW(_url, r) {
    if (!r) return
    setInterval(() => void r.update(), 60 * 60 * 1000)
    document.addEventListener('visibilitychange', () => { if (!document.hidden && navigator.onLine) void r.update() })
  },
})
