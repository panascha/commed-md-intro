import { createContext, useContext, useEffect, useRef, useState } from 'react'
import { AlertTriangle, X } from 'lucide-react'

/** Modal: bottom-sheet on mobile, in-panel on md+. */
export function Modal({ title, onClose, children, footer }: { title: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode }) {
  const inPanel = useContext(InPanel)
  if (inPanel) {
    return (
      <div className="px-4 py-3">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-medium text-gray-900">{title}</h2>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-full bg-gray-100 text-gray-600" aria-label="ปิด"><X size={18} /></button>
        </div>
        {children}
        {footer && <div className="border-t border-gray-100 px-0 py-3">{footer}</div>}
      </div>
    )
  }
  return <BottomSheet title={title} onClose={onClose} footer={footer}>{children}</BottomSheet>
}

const SHEET_CLOSE_PX = 90 // drag the header down further than this → close
const SHEET_GROW_PX = 40 // drag it up further than this → full height

/** Phone bottom sheet (centred dialog on md+). The grabber + title row drags: down closes
 *  (through onClose, so a dirty-state confirm still runs), up expands to full height. */
function BottomSheet({ title, onClose, children, footer }: { title: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode }) {
  const [full, setFull] = useState(false)
  const [dy, setDy] = useState(0) // live drag offset, px (positive = down)
  const startY = useRef<number | null>(null)

  const onDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('button')) return // ✕ stays a plain tap
    startY.current = e.clientY
    e.currentTarget.setPointerCapture(e.pointerId)
  }
  const onMove = (e: React.PointerEvent) => {
    if (startY.current !== null) setDy(e.clientY - startY.current)
  }
  const onUp = () => {
    if (startY.current === null) return
    startY.current = null
    if (dy > SHEET_CLOSE_PX) { if (full) setFull(false); else onClose() }
    else if (dy < -SHEET_GROW_PX) setFull(true)
    setDy(0) // always reset: a refused close (unsaved-changes confirm) must not leave the sheet shifted
  }

  return (
    <div className="fixed inset-0 z-[1300] flex items-end bg-black/30 md:items-center md:justify-center" onClick={onClose}>
      <div
        className={`flex w-full flex-col rounded-t-2xl bg-white md:max-h-[90dvh] md:max-w-md md:rounded-2xl ${full ? 'h-[calc(100dvh-env(safe-area-inset-top)-0.5rem)] md:h-auto' : 'max-h-[85dvh]'} ${dy === 0 ? 'transition-transform' : ''}`}
        style={{ transform: dy > 0 ? `translateY(${dy}px)` : undefined }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="shrink-0 touch-none select-none px-4 pt-2 md:touch-auto"
          onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}
        >
          <div className="mx-auto mb-2 h-1.5 w-10 rounded-full bg-gray-300 md:hidden" />
          <div className="mb-2 flex items-center justify-between gap-2">
            <h2 className="min-w-0 truncate text-lg font-medium text-gray-900">{title}</h2>
            <button onClick={onClose} className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-gray-100 text-gray-600 md:h-9 md:w-9" aria-label="ปิด"><X size={18} /></button>
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
          {children}
          {footer && <div className="border-t border-gray-100 px-0 py-3">{footer}</div>}
        </div>
      </div>
    </div>
  )
}

/** Full-screen layer for things like Genogram that need the whole canvas. */
export function FullScreen({ title, onClose, children, footer }: { title: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode }) {
  const inPanel = useContext(InPanel)
  if (inPanel) {
    return (
      <div className="flex min-h-0 flex-1 flex-col bg-white">
        <div className="flex items-start gap-2 border-b border-gray-100 px-4 pb-3 pt-3">
          <div className="min-w-0 flex-1"><h2 className="truncate text-lg font-medium text-gray-900">{title}</h2></div>
          <button onClick={onClose} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gray-100 text-gray-600"><X size={18} /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-3">{children}</div>
        {footer && <div className="border-t border-gray-100 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3">{footer}</div>}
      </div>
    )
  }
  return (
    <div className="fixed inset-0 z-[1350] flex flex-col bg-white">
      <div className="flex items-start gap-2 border-b border-gray-100 px-4 pb-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div className="min-w-0 flex-1"><h2 className="truncate text-lg font-medium text-gray-900">{title}</h2></div>
        <button onClick={onClose} className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gray-100 text-gray-600"><X size={18} /></button>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-3">{children}</div>
      {footer && <div className="border-t border-gray-100 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3">{footer}</div>}
    </div>
  )
}

/** True inside the desktop side panel: Modal/FullScreen render in-flow instead of as overlays. */
export const InPanel = createContext(false)

/** md+ (≥768px): side panel + map split view. */
export function useWide() {
  const q = '(min-width: 768px)'
  const [wide, setWide] = useState(() => matchMedia(q).matches)
  useEffect(() => {
    const m = matchMedia(q), on = () => setWide(m.matches)
    m.addEventListener('change', on)
    return () => m.removeEventListener('change', on)
  }, [])
  return wide
}

/** Confirm dialog: must return a Promise; resolves true/false. */
export function confirmAction(title: string, body: string, okLabel = 'ยืนยัน', danger = false, cancelLabel = 'ยกเลิก'): Promise<boolean> {
  return new Promise((resolve) => {
    const id = 'confirm-' + Math.random().toString(36).slice(2, 8)
    const root = document.createElement('div')
    root.id = id
    root.dataset.confirmDialog = '' // useOverlayStack: Back cancels this dialog first
    root.className = 'fixed inset-0 z-[1400] flex items-end bg-black/40 md:items-center md:justify-center'
    root.innerHTML = `
      <div class="mx-auto w-full max-w-sm rounded-t-2xl bg-white p-5 shadow-xl md:rounded-2xl">
        <h3 class="mb-2 text-lg font-medium text-gray-900"></h3>
        <p class="mb-5 text-sm text-gray-600"></p>
        <div class="flex gap-2">
          <button data-act="cancel" class="flex-1 rounded-full border border-gray-300 py-3 text-sm text-gray-700">ยกเลิก</button>
          <button data-act="ok" class="flex-1 rounded-full py-3 text-sm font-medium text-white" style="background:${danger ? '#dc2626' : '#1a73e8'}"></button>
        </div>
      </div>`
    root.querySelector('h3')!.textContent = title
    root.querySelector('p')!.textContent = body
    ;(root.querySelector('[data-act=ok]') as HTMLButtonElement).textContent = okLabel
    ;(root.querySelector('[data-act=cancel]') as HTMLButtonElement).textContent = cancelLabel
    root.addEventListener('click', (e) => {
      const t = e.target as HTMLElement
      if (t === root) { root.remove(); resolve(false) }
      else if (t.dataset.act === 'cancel') { root.remove(); resolve(false) }
      else if (t.dataset.act === 'ok') { root.remove(); resolve(true) }
    })
    document.body.appendChild(root)
  })
}

/** True while a confirmAction() dialog is on screen. */
export const confirmOpen = () => document.querySelector('[data-confirm-dialog]') !== null

export type Overlay = { open: boolean; close: () => void }

/**
 * Android hardware back / edge swipe closes only the topmost open overlay instead of leaving
 * the PWA. `overlays` is ordered bottom → top. One history entry is pushed per open overlay;
 * closing through the UI pops our own entries back off. `close` may refuse (dirty-state
 * confirm) — the overlay stays open and its entry is re-pushed.
 */
export function useOverlayStack(overlays: Overlay[]) {
  const latest = useRefLatest(overlays)
  const entries = useRef(0) // history entries we pushed and still own
  const backPending = useRef(false) // our history.go(-n) in flight; its popstate is not a user Back
  const [tick, setTick] = useState(0)
  const depth = overlays.filter((o) => o.open).length

  useEffect(() => {
    if (backPending.current) return // reconcile after the traversal lands (popstate → tick)
    if (depth > entries.current) {
      while (entries.current < depth) history.pushState({ ...history.state, overlay: ++entries.current }, '')
    } else if (depth < entries.current) {
      backPending.current = true
      history.go(depth - entries.current)
      entries.current = depth
    }
  }, [depth, tick])

  useEffect(() => {
    const onPop = () => {
      if (backPending.current) { backPending.current = false; setTick((t) => t + 1); return }
      if (entries.current === 0) return
      entries.current--
      const cancel = document.querySelector<HTMLElement>('[data-confirm-dialog] [data-act=cancel]')
      if (cancel) cancel.click()
      else [...latest.current].reverse().find((o) => o.open)?.close()
      setTick((t) => t + 1)
    }
    window.addEventListener('popstate', onPop)
    return () => window.removeEventListener('popstate', onPop)
  }, [])
}

/** Download a string blob. */
export function download(blob: Blob, filename: string) {
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob); a.download = filename; a.click()
  setTimeout(() => URL.revokeObjectURL(a.href), 1000)
}

/** Export an SVG string as .svg file or as 2× PNG. */
export async function exportSvgString(svg: string, name: string, as: 'svg' | 'png', w: number, h: number): Promise<void> {
  let blob = new Blob([svg], { type: 'image/svg+xml' })
  if (as === 'png') {
    const img = new Image()
    img.src = URL.createObjectURL(blob)
    await img.decode()
    const c = document.createElement('canvas')
    c.width = w * 2; c.height = h * 2
    const g = c.getContext('2d')!
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height)
    g.drawImage(img, 0, 0, c.width, c.height)
    URL.revokeObjectURL(img.src)
    blob = await new Promise<Blob>((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('toBlob failed'))), 'image/png'))
  }
  download(blob, `${name}.${as}`)
}

/** LINE / Facebook in-app browser detection. Returns true if user is in a hostile embedded browser. */
export function isInAppBrowser(): { detected: boolean; vendor: string | null } {
  if (typeof navigator === 'undefined') return { detected: false, vendor: null }
  const ua = navigator.userAgent
  if (/Line\/|LIFF/i.test(ua)) return { detected: true, vendor: 'LINE' }
  if (/FBAN|FBAV|FB_IAB/i.test(ua)) return { detected: true, vendor: 'Facebook' }
  if (/Instagram/i.test(ua)) return { detected: true, vendor: 'Instagram' }
  if (/TelegramBot/i.test(ua)) return { detected: true, vendor: 'Telegram' }
  return { detected: false, vendor: null }
}

/** Copy text to clipboard. Returns true on success. */
export async function copyToClipboard(text: string): Promise<boolean> {
  try { await navigator.clipboard.writeText(text); return true } catch { return false }
}

/** useRef that holds the latest value without re-rendering. */
export function useRefLatest<T>(value: T) { const r = useRef(value); r.current = value; return r }

/** Small inline caution badge (handover note count). */
export function CautionBadge({ count, className }: { count: number; className?: string }) {
  if (count <= 0) return null
  return (
    <span className={`inline-flex items-center gap-0.5 rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-700 ${className ?? ''}`}>
      <AlertTriangle size={12} />
      {count}
    </span>
  )
}