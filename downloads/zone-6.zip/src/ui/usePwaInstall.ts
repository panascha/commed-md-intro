import { useEffect, useState } from 'react'

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
}

// Captured at module load: Chrome fires beforeinstallprompt once, often before any button mounts.
let deferred: InstallPromptEvent | null = null
let installed = false
const listeners = new Set<() => void>()
const notify = () => listeners.forEach((l) => l())

window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e as InstallPromptEvent; notify() })
window.addEventListener('appinstalled', () => { deferred = null; installed = true; notify() })

export const isStandalone = () =>
  matchMedia('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true

// iPadOS 13+ reports a desktop Mac UA; touch points give it away.
export const isIos = () =>
  /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)

/** 'manual' = no native prompt available (iOS, in-app browsers, Firefox) → caller shows the guide. */
export async function installApp(): Promise<'accepted' | 'dismissed' | 'manual'> {
  const e = deferred
  if (!e) return 'manual'
  deferred = null // the event can only be prompted once
  await e.prompt()
  const { outcome } = await e.userChoice
  notify()
  return outcome
}

export function usePwaInstall() {
  const [, rerender] = useState(0)
  useEffect(() => {
    const l = () => rerender((n) => n + 1)
    listeners.add(l)
    return () => { listeners.delete(l) }
  }, [])
  return { installed: installed || isStandalone(), ios: isIos(), installApp }
}
