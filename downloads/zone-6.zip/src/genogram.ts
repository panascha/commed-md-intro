// Pure SVG genogram auto-layout. Ported from app/src/features/family/GenogramModal.tsx.
// Takes flat lists (no Dexie), returns SVG markup string + dimensions.
// v2 scope: square=male, circle=female, deceased-X. No bedridden fill or chronic text.

const GAP = 120, ROW = 150, R = 20, PAD = 40

export interface Person {
  id: string
  placeId: string
  name: string
  nickname?: string
  gender: 'm' | 'f' | 'o'
  age?: number
  isDeceased: 0 | 1
  isBedridden: 0 | 1
  chronic?: string
}

export interface Relationship {
  id: string
  placeId: string
  person1Id: string
  person2Id: string
  relationType: 'spouse' | 'parent_child' | 'sibling' | 'other'
  relationLabel?: string
}

interface XY { x: number; y: number }

function layout(
  placeId: string,
  all: Person[],
  allRels: Relationship[],
): { pos: Map<string, XY>; people: Map<string, Person>; rels: Relationship[]; width: number; height: number } {
  const byId = new Map(all.map((p) => [p.id, p]))
  const rels = allRels.filter((r) => byId.has(r.person1Id) && byId.has(r.person2Id))
  const nbr = (id: string) => rels.filter((r) => r.person1Id === id || r.person2Id === id)
  const keep = new Set(all.filter((p) => p.placeId === placeId).map((p) => p.id))
  for (let d = 0, frontier = [...keep]; d < 2; d++) {
    const next: string[] = []
    for (const id of frontier) for (const r of nbr(id))
      for (const o of [r.person1Id, r.person2Id]) if (!keep.has(o)) { keep.add(o); next.push(o) }
    frontier = next
  }
  const used = rels.filter((r) => keep.has(r.person1Id) && keep.has(r.person2Id))

  // Generation: BFS over structural links (exclude 'other' = emotional)
  const structural = used.filter((r) => r.relationType !== 'other')
  const gen = new Map<string, number>()
  for (const start of keep) {
    if (gen.has(start)) continue
    gen.set(start, 0)
    const q = [start]
    while (q.length) {
      const id = q.shift()!
      for (const r of structural) {
        if (r.person1Id !== id && r.person2Id !== id) continue
        const o = r.person1Id === id ? r.person2Id : r.person1Id
        if (gen.has(o)) continue
        gen.set(o, r.relationType === 'parent_child'
          ? (r.person1Id === id ? (gen.get(id)! + 1) : (gen.get(id)! - 1))
          : gen.get(id)!)
        q.push(o)
      }
    }
  }
  if (gen.size === 0) return { pos: new Map(), people: byId, rels: [], width: 0, height: 2 * PAD }
  const min = Math.min(...gen.values())
  const rows: string[][] = []
  for (const [id, g] of gen) (rows[g - min] ??= []).push(id)
  // generations can skip (conflicting parent links) → fill holes; forEach skips them
  for (let i = 0; i < rows.length; i++) rows[i] ??= []

  // Partner pairing: couple = side-by-side, male-left
  const partner = new Map<string, string>()
  for (const r of structural) if (r.relationType === 'spouse' && !partner.has(r.person1Id) && !partner.has(r.person2Id)) {
    partner.set(r.person1Id, r.person2Id); partner.set(r.person2Id, r.person1Id)
  }
  const parentsOf = (id: string) => structural.filter((r) => r.relationType === 'parent_child' && r.person2Id === id).map((r) => r.person1Id)
  const pos = new Map<string, XY>()
  let width = 0
  rows.forEach((row, gi) => {
    const units: string[][] = []
    const seen = new Set<string>()
    for (const id of row) {
      if (seen.has(id)) continue
      const p = partner.get(id)
      const u = p && row.includes(p) && !seen.has(p)
        ? (byId.get(id)?.gender === 'm' ? [id, p] : [p, id])
        : [id]
      u.forEach((x) => seen.add(x)); units.push(u)
    }
    const bary = (u: string[]) => {
      const xs = u.flatMap(parentsOf).map((p) => pos.get(p)?.x).filter((x): x is number => x != null)
      return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : Infinity
    }
    units.sort((a, b) => bary(a) - bary(b))
    let x = 0
    for (const u of units) for (const id of u) { pos.set(id, { x, y: gi * ROW }); x += GAP }
    width = Math.max(width, x - GAP)
  })
  for (const row of rows) {
    const pts = row.map((id) => pos.get(id)).filter((p): p is XY => !!p)
    if (!pts.length) continue
    const xs = pts.map((p) => p.x)
    const shift = (width - (Math.max(...xs) - Math.min(...xs))) / 2 - Math.min(...xs)
    for (const p of pts) p.x += shift
  }
  for (const p of pos.values()) { p.x += PAD + 40; p.y += PAD + 30 }
  // only draw links whose both ends were placed
  const drawn = used.filter((r) => pos.has(r.person1Id) && pos.has(r.person2Id))
  return { pos, people: byId, rels: drawn, width: width + 2 * PAD + 80, height: rows.length * ROW + 2 * PAD + 60 }
}

/** Build an SVG element. Attribute values are escaped here; `body` must already be
 *  markup (nested tag() output) or text passed through escapeXml(). */
function tag(t: string, attrs: Record<string, string | number>, body?: string): string {
  const a = Object.entries(attrs).map(([k, v]) => ` ${k}="${escapeXml(String(v))}"`).join('')
  return body != null ? `<${t}${a}>${body}</${t}>` : `<${t}${a}/>`
}

/** Both endpoints of a relationship, or null if either wasn't laid out. */
function ends(pos: Map<string, XY>, r: Relationship): [XY, XY] | null {
  const a = pos.get(r.person1Id), b = pos.get(r.person2Id)
  return a && b ? [a, b] : null
}

export function genogramSvg(placeId: string, persons: Person[], rels: Relationship[]): { svg: string; width: number; height: number } {
  const L = layout(placeId, persons, rels)
  const { pos, people } = L
  const width = Math.max(L.width, 500), height = L.height + 70

  const house = [...pos.keys()].filter((id) => people.get(id)?.placeId === placeId).map((id) => pos.get(id)!)
  const H = house.length ? {
    x: Math.min(...house.map((p) => p.x)) - 45, y: Math.min(...house.map((p) => p.y)) - 35,
    w: Math.max(...house.map((p) => p.x)) - Math.min(...house.map((p) => p.x)) + 90,
    h: Math.max(...house.map((p) => p.y)) - Math.min(...house.map((p) => p.y)) + 95,
  } : null

  // Children grouped by parent set → sibling bar
  const groups = new Map<string, string[]>()
  for (const r of L.rels) if (r.relationType === 'parent_child') {
    const ps = L.rels.filter((x) => x.relationType === 'parent_child' && x.person2Id === r.person2Id).map((x) => x.person1Id).sort().join(',')
    const g = groups.get(ps) ?? []; if (!g.includes(r.person2Id)) g.push(r.person2Id); groups.set(ps, g)
  }

  const parts: string[] = []

  // House boundary
  if (H) parts.push(tag('rect', { x: H.x, y: H.y, width: H.w, height: H.h, rx: 45, fill: 'none', stroke: '#1a73e8', 'stroke-width': 1.5, 'stroke-dasharray': '6 4' }))

  // Couple connectors
  for (const r of L.rels) if (r.relationType === 'spouse') {
    const e = ends(pos, r); if (!e) continue
    const [a, b] = e
    const y = Math.max(a.y, b.y) + R + 12
    parts.push(tag('polyline', { points: `${a.x},${a.y + R} ${a.x},${y} ${b.x},${y} ${b.x},${b.y + R}`, stroke: '#111', 'stroke-width': 1.5, fill: 'none' }))
  }

  // Parents → children
  for (const [ps, kids] of groups) {
    const par = ps.split(',').map((id) => pos.get(id)).filter((p): p is XY => !!p)
    const cs = kids.map((k) => pos.get(k)).filter((p): p is XY => !!p)
    if (!par.length || !cs.length) continue
    const top = par.length > 1
      ? { x: (par[0].x + par[1].x) / 2, y: Math.max(par[0].y, par[1].y) + R + 12 }
      : { x: par[0].x, y: par[0].y + R }
    const bar = Math.min(...cs.map((c) => c.y)) - R - 22
    const xs = [top.x, ...cs.map((c) => c.x)]
    parts.push(tag('g', { stroke: '#111', 'stroke-width': 1.5, fill: 'none' },
      tag('line', { x1: top.x, y1: top.y, x2: top.x, y2: bar })
      + tag('line', { x1: Math.min(...xs), y1: bar, x2: Math.max(...xs), y2: bar })
      + cs.map((c) => tag('line', { x1: c.x, y1: bar, x2: c.x, y2: c.y - R })).join('')))
  }

  // Siblings without known parents
  for (const r of L.rels) if (r.relationType === 'sibling' && !L.rels.some((x) => x.relationType === 'parent_child' && (x.person2Id === r.person1Id || x.person2Id === r.person2Id))) {
    const e = ends(pos, r); if (!e) continue
    const [a, b] = e, y = Math.min(a.y, b.y) - R - 18
    parts.push(tag('polyline', { points: `${a.x},${a.y - R} ${a.x},${y} ${b.x},${y} ${b.x},${b.y - R}`, stroke: '#111', 'stroke-width': 1.5, fill: 'none' }))
  }

  // Emotional links
  for (const r of L.rels) if (r.relationType === 'other') {
    const e = ends(pos, r); if (!e) continue
    const [a, b] = e
    parts.push(tag('line', { x1: a.x, y1: a.y, x2: b.x, y2: b.y, stroke: '#6b7280', 'stroke-width': 1.2, 'stroke-dasharray': '4 3' }))
  }

  // People shapes
  for (const [id, { x, y }] of pos) {
    const p = people.get(id)
    if (!p) continue
    const fill = p.isBedridden ? '#fde68a' : '#fff'
    const shape = p.gender === 'm'
      ? tag('rect', { x: x - R, y: y - R, width: 2 * R, height: 2 * R, fill, stroke: '#111', 'stroke-width': 2 })
      : p.gender === 'f'
        ? tag('circle', { cx: x, cy: y, r: R, fill, stroke: '#111', 'stroke-width': 2 })
        : tag('polygon', { points: `${x},${y - R - 4} ${x + R + 4},${y} ${x},${y + R + 4} ${x - R - 4},${y}`, fill, stroke: '#111', 'stroke-width': 2 })
    let node = shape
    if (p.age != null) node += tag('text', { x, y: y + 5, 'text-anchor': 'middle', 'font-size': 13 }, escapeXml(String(p.age)))
    if (p.isDeceased) node += tag('line', { x1: x - R - 6, y1: y + R + 6, x2: x + R + 6, y2: y - R - 6, stroke: '#111', 'stroke-width': 2 })
    node += tag('text', { x, y: y + R + 28, 'text-anchor': 'middle', 'font-size': 12 }, escapeXml((p.nickname || p.name).slice(0, 14)))
    parts.push(tag('g', {}, node))
  }

  // Legend
  parts.push(tag('g', { transform: `translate(${PAD},${height - 40})`, 'font-size': 11, fill: '#374151' },
    tag('rect', { x: 0, y: -8, width: 14, height: 14, fill: '#fff', stroke: '#111' })
    + tag('text', { x: 20, y: 4 }, 'ชาย')
    + tag('circle', { cx: 60, cy: -1, r: 7, fill: '#fff', stroke: '#111' })
    + tag('text', { x: 72, y: 4 }, 'หญิง')
    + tag('line', { x1: 105, y1: 6, x2: 119, y2: -8, stroke: '#111', 'stroke-width': 2 })
    + tag('text', { x: 124, y: 4 }, 'เสียชีวิต')
    + tag('rect', { x: 175, y: -8, width: 14, height: 14, fill: '#fde68a', stroke: '#111' })
    + tag('text', { x: 195, y: 4 }, 'ติดเตียง')
    + tag('rect', { x: 375, y: -8, width: 20, height: 14, rx: 7, fill: 'none', stroke: '#1a73e8', 'stroke-dasharray': '4 3' })
    + tag('text', { x: 400, y: 4 }, 'อยู่บ้านเดียวกัน')
  ))

  // SVG header
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" font-family="sans-serif"><rect width="100%" height="100%" fill="#fff"/>${parts.join('\n')}</svg>`
  return { svg, width, height }
}

/** Escape text for XML/HTML text nodes and attribute values. */
export function escapeXml(str: string | undefined | null): string {
  if (!str) return ''
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;'
  }[c] || c))
}