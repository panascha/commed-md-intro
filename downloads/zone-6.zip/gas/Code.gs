/**
 * COMMED OS demo v2 — Google Apps Script backend.
 * Bind this script to a Google Sheet (Extensions → Apps Script).
 * Run setup() once from the editor to create the sheets + headers (re-run it
 * after updating this file: it adds new columns and plain-text formatting),
 * First deploy: Deploy → New deployment → Web app (execute as Me, access: Anyone).
 * Updates: Deploy → Manage deployments → Edit → Version: New version — keeps the
 * same /exec URL. A *new deployment* changes the URL and breaks every phone's setting.
 *
 * Flat sheets (+ Roles, + Photos = Drive file metadata per uploaded photo):
 *   Places      — houses/shops/etc, one row per Place
 *   Notes       — visit notes, append-only, isCaution flag
 *   Persons_Kin — people AND their relationships, one flat sheet
 *                 (recordType = 'person' | 'relationship')
 *   Geo_Layers  — custom-drawn building outlines / boundaries (GeoJSON string)
 *   Locations   — append-only GPS heartbeat pings from students
 *
 * Sync model:
 *   - Client batches all text writes into one POST {type:'batch', ...}.
 *   - Client pushes each photo separately {type:'photo', ...} (base64 -> Drive).
 *   - Client pulls manually via GET ?action=pull&since=<ISO> (no polling);
 *     `since` is the `serverTime` of the previous pull, compared to `syncedAt`.
 *   - Every response carries {ok:true|false}; HTTP is 200 either way.
 *   - Upsert by id, last-write-wins is enforced client-side; server just
 *     overwrites the matching row (or appends if the id is new).
 */

var SHEET_NAMES = {
  PLACES: 'Places',
  NOTES: 'Notes',
  PERSONS_KIN: 'Persons_Kin',
  GEO_LAYERS: 'Geo_Layers',
  LOCATIONS: 'Locations',
  ROLES: 'Roles',
  PHOTOS: 'Photos',
};

// `syncedAt` is stamped by the server on every write; pull filters on it, so rows
// pushed late by a phone that was offline (old client updatedAt) still reach others.
// It is always the LAST column so existing sheets just gain a column on setup().
var HEADERS = {
  Places: ['id', 'buildingId', 'houseNo', 'tag', 'status', 'note', 'lat', 'lng', 'createdBy', 'createdAt', 'updatedAt', 'deletedAt', 'syncedAt'],
  Notes: ['id', 'placeId', 'body', 'isCaution', 'author', 'createdAt', 'updatedAt', 'deletedAt', 'syncedAt'],
  Persons_Kin: ['id', 'placeId', 'recordType', 'name', 'nickname', 'gender', 'age', 'isDeceased', 'isBedridden', 'chronic', 'person1Id', 'person2Id', 'relationType', 'relationLabel', 'createdAt', 'updatedAt', 'deletedAt', 'syncedAt'],
  Geo_Layers: ['id', 'name', 'kind', 'geojson', 'createdBy', 'createdAt', 'updatedAt', 'deletedAt', 'syncedAt'],
  Locations: ['id', 'studentId', 'studentName', 'zone', 'house', 'lat', 'lng', 'accuracy', 'ts', 'syncedAt'],
  Roles: ['studentId', 'name', 'role', 'updatedAt', 'syncedAt'],
  Photos: ['id', 'placeId', 'fileId', 'url', 'createdBy', 'createdAt', 'updatedAt', 'deletedAt', 'syncedAt'],
};

var PHOTO_FOLDER_NAME = 'COMMED_OS_Photos';

// ---------------------------------------------------------------------------
// Setup — run once manually from the Apps Script editor.
// ---------------------------------------------------------------------------
function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(HEADERS).forEach(function (name) {
    var sheet = ss.getSheetByName(name);
    if (!sheet) sheet = ss.insertSheet(name);
    var headers = HEADERS[name];
    var range = sheet.getRange(1, 1, 1, headers.length);
    var existing = range.getValues()[0];
    var needsHeader = headers.some(function (h, i) { return existing[i] !== h; });
    if (needsHeader) {
      range.setValues([headers]);
      sheet.setFrozenRows(1);
    }
    setPlainText_(sheet, headers.length);
  });
  // remove the default "Sheet1" if it's empty and unused
  var def = ss.getSheetByName('Sheet1');
  if (def && def.getLastRow() === 0 && ss.getSheets().length > 1) {
    ss.deleteSheet(def);
  }
  Logger.log('setup() done — sheets: ' + ss.getSheets().map(function (s) { return s.getName(); }).join(', '));
}

// ---------------------------------------------------------------------------
// Sheet helpers
// ---------------------------------------------------------------------------
function getSheet_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, HEADERS[name].length).setValues([HEADERS[name]]);
    sheet.setFrozenRows(1);
    setPlainText_(sheet, HEADERS[name].length);
  }
  return sheet;
}

/** Format all data columns as plain text so Sheets never coerces values
 *  (house no. "1/2" -> date, "007" -> 7). Client re-parses numbers on pull. */
function setPlainText_(sheet, numCols) {
  sheet.getRange(1, 1, sheet.getMaxRows(), numCols).setNumberFormat('@');
}

/** Read all data rows of a sheet as an array of plain objects keyed by header. */
function readAll_(name) {
  var sheet = getSheet_(name);
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  var headers = HEADERS[name];
  var values = sheet.getRange(2, 1, lastRow - 1, headers.length).getValues();
  return values.map(function (row) {
    var obj = {};
    headers.forEach(function (h, i) { obj[h] = row[i]; });
    return obj;
  }).filter(function (obj) { return obj.id || obj.studentId; }); // skip fully-blank rows
}

/** Find the 1-based row index (including header) of a given id, or -1. */
function findRowById_(sheet, id) {
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return -1;
  var headers = HEADERS[sheet.getName()];
  var idCol = headers.indexOf('id');
  var studentIdCol = headers.indexOf('studentId');
  var col = idCol !== -1 ? idCol : studentIdCol !== -1 ? studentIdCol : 0;
  var values = sheet.getRange(2, col + 1, lastRow - 1, 1).getValues();
  for (var i = 0; i < values.length; i++) {
    if (String(values[i][0]) === String(id)) return i + 2; // +2: 1-based + header row
  }
  return -1;
}

function upsertRole_(role) {
  var sheet = getSheet_(SHEET_NAMES.ROLES);
  // sheets made before the syncedAt column existed: keep the header row in step with HEADERS
  sheet.getRange(1, 1, 1, HEADERS.Roles.length).setValues([HEADERS.Roles]);
  var rowValues = HEADERS.Roles.map(function (h) {
    var v = role[h];
    return v === undefined || v === null ? '' : v;
  });
  var rowIndex = findRowById_(sheet, role.studentId);
  if (rowIndex === -1) sheet.appendRow(rowValues);
  else sheet.getRange(rowIndex, 1, 1, HEADERS.Roles.length).setValues([rowValues]);
}

/** Upsert one record (plain object) into a sheet by its `id` field. */
function upsertRow_(name, record) {
  var sheet = getSheet_(name);
  var headers = HEADERS[name];
  var rowValues = headers.map(function (h) {
    var v = record[h];
    return v === undefined || v === null ? '' : v;
  });
  var rowIndex = findRowById_(sheet, record.id);
  if (rowIndex === -1) {
    sheet.appendRow(rowValues);
  } else {
    sheet.getRange(rowIndex, 1, 1, headers.length).setValues([rowValues]);
  }
}

function isoToDate_(iso) {
  var d = new Date(iso);
  return isNaN(d.getTime()) ? new Date(0) : d;
}

// ---------------------------------------------------------------------------
// doGet — manual pull only. ?action=pull&since=<ISO8601>
// ---------------------------------------------------------------------------
function doGet(e) {
  var action = (e.parameter && e.parameter.action) || '';
  if (action !== 'pull') {
    return ContentService.createTextOutput(JSON.stringify({ error: 'unknown action' }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  var sinceIso = (e.parameter && e.parameter.since) || '1970-01-01T00:00:00.000Z';
  var since = isoToDate_(sinceIso);
  // Next cursor. Pull takes no lock, and a batch stamps syncedAt before its setValues
  // lands, so back the cursor off 2 min: overlapping rows are re-sent and the client's
  // LWW upsert makes that harmless, while an in-flight write can never be skipped.
  var serverTime = new Date(Date.now() - 120000).toISOString();

  var placesAll = readAll_(SHEET_NAMES.PLACES);
  var notesAll = readAll_(SHEET_NAMES.NOTES);
  var kinAll = readAll_(SHEET_NAMES.PERSONS_KIN);
  var geoAll = readAll_(SHEET_NAMES.GEO_LAYERS);
  var locAll = readAll_(SHEET_NAMES.LOCATIONS);
  var photosAll = readAll_(SHEET_NAMES.PHOTOS);

  // Server-stamped syncedAt wins; rows written before that column existed fall back to tsField.
  function newerThan(rows, tsField) {
    return rows.filter(function (r) {
      return isoToDate_(r.syncedAt || r[tsField]) > since;
    });
  }

  var persons = kinAll.filter(function (r) { return r.recordType === 'person'; });
  var relationships = kinAll.filter(function (r) { return r.recordType === 'relationship'; });

  var payload = {
    serverTime: serverTime,
    places: newerThan(placesAll, 'updatedAt'),
    notes: newerThan(notesAll, 'updatedAt'),
    persons: newerThan(persons, 'updatedAt'),
    relationships: newerThan(relationships, 'updatedAt'),
    geoLayers: newerThan(geoAll, 'updatedAt'),
    locations: newerThan(locAll, 'ts'),
    photos: newerThan(photosAll, 'updatedAt'),
    roles: newerThan(readAll_(SHEET_NAMES.ROLES), 'updatedAt'),
  };

  return ContentService.createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}

// ---------------------------------------------------------------------------
// doPost — {type:'batch', place:[], note:[], person:[], relationship:[], geoLayer:[], location:[]}
//       or {type:'photo', id, placeId, base64, createdAt, ...}
// Client sends Content-Type: text/plain;charset=utf-8 to stay CORS-simple;
// the body is still JSON, so we just JSON.parse(e.postData.contents).
// ---------------------------------------------------------------------------
function doPost(e) {
  var body;
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(30000);
  } catch (err) {
    return jsonOut_({ ok: false, error: 'Server busy: Lock timeout. Please retry.' });
  }
  try {
    try {
      body = JSON.parse(e.postData.contents);
    } catch (err) {
      return jsonOut_({ ok: false, error: 'bad json: ' + err.message });
    }
    if (body.type === 'batch') return handleBatch_(body);
    if (body.type === 'photo') return handlePhoto_(body);
    if (body.type === 'role') return handleRole_(body);
    return jsonOut_({ ok: false, error: 'unknown type: ' + body.type });
  } catch (err) {
    return jsonOut_({ ok: false, error: err.message });
  } finally {
    lock.releaseLock();
  }
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function handleBatch_(body) {
  var counts = { places: 0, notes: 0, persons: 0, relationships: 0, geoLayers: 0, locations: 0 };

  /** Bulk upsert: build id→rowIndex map once, append new rows in one call. */
  function bulkUpsert_(sheetName, records, transform) {
    if (!records || !records.length) return 0;
    var sheet = getSheet_(sheetName);
    var headers = HEADERS[sheetName];
    var lastRow = sheet.getLastRow();
    // build id → {row, updatedAt} map in one read
    var rowMap = {};
    var idCol = headers.indexOf('id');
    if (idCol < 0) idCol = headers.indexOf('studentId');
    var tsCol = headers.indexOf('updatedAt'); // -1 for append-only Locations
    if (lastRow >= 2 && idCol >= 0) {
      var data = sheet.getRange(2, 1, lastRow - 1, headers.length).getValues();
      for (var i = 0; i < data.length; i++) {
        var id = data[i][idCol];
        if (id !== '' && id != null) rowMap[id] = { row: i + 2, updatedAt: tsCol >= 0 ? data[i][tsCol] : '' }; // 1-based + header
      }
    }
    var updates = {}; // sheet row → new values for rows that already exist
    var newRows = [];
    var newIdx = {}; // id → index in newRows (same id twice in one batch → overwrite, not append)
    var syncedAt = new Date().toISOString();
    for (var r = 0; r < records.length; r++) {
      var rec = Object.assign({}, transform ? transform(records[r]) : records[r], { syncedAt: syncedAt });
      // Clock drift guard: a phone with a fast clock must not lock the row against later edits (LWW).
      if (rec.updatedAt && isoToDate_(rec.updatedAt) > new Date(Date.now() + 120000)) {
        rec.updatedAt = new Date().toISOString();
      }
      var rowValues = headers.map(function (h) {
        var v = rec[h];
        return v === undefined || v === null ? '' : v;
      });
      var existing = rowMap[rec.id];
      if (existing) {
        // Server-side last-write-wins: a phone coming back online with an older edit
        // (e.g. of a place someone else since deleted) must not overwrite the newer row.
        if (tsCol >= 0 && existing.updatedAt && rec.updatedAt &&
            isoToDate_(existing.updatedAt) > isoToDate_(rec.updatedAt)) continue;
        updates[existing.row] = rowValues;
        existing.updatedAt = rec.updatedAt || existing.updatedAt;
      } else if (newIdx[rec.id] !== undefined) {
        var prev = newRows[newIdx[rec.id]];
        if (tsCol >= 0 && prev[tsCol] && rec.updatedAt && isoToDate_(prev[tsCol]) > isoToDate_(rec.updatedAt)) continue;
        newRows[newIdx[rec.id]] = rowValues;
      } else {
        newIdx[rec.id] = newRows.length;
        newRows.push(rowValues);
      }
    }
    // Existing rows: one setValues per run of neighbouring rows instead of one per row (each call
    // is a round trip made while holding the script lock). Rows outside the batch are not rewritten.
    var rows = Object.keys(updates).map(Number).sort(function (a, b) { return a - b; });
    for (var s = 0; s < rows.length;) {
      var e = s;
      while (e + 1 < rows.length && rows[e + 1] === rows[e] + 1) e++;
      sheet.getRange(rows[s], 1, e - s + 1, headers.length)
        .setValues(rows.slice(s, e + 1).map(function (n) { return updates[n]; }));
      s = e + 1;
    }
    if (newRows.length) {
      sheet.getRange(lastRow + 1, 1, newRows.length, headers.length).setNumberFormat('@').setValues(newRows);
    }
    return records.length;
  }

  counts.places = bulkUpsert_(SHEET_NAMES.PLACES, body.place || []);
  counts.notes = bulkUpsert_(SHEET_NAMES.NOTES, body.note || []);
  // Persons_Kin is shared — run persons first, then relationships
  counts.persons = bulkUpsert_(SHEET_NAMES.PERSONS_KIN, body.person || [], function (p) {
    return Object.assign({ recordType: 'person' }, p);
  });
  counts.relationships = bulkUpsert_(SHEET_NAMES.PERSONS_KIN, body.relationship || [], function (r) {
    return Object.assign({ recordType: 'relationship' }, r);
  });
  counts.geoLayers = bulkUpsert_(SHEET_NAMES.GEO_LAYERS, body.geoLayer || []);
  counts.locations = bulkUpsert_(SHEET_NAMES.LOCATIONS, body.location || []);

  return jsonOut_({ ok: true, counts: counts });
}

/** Upload one photo to Drive and record it in the Photos sheet.
 *  Idempotent by id: a retried upload (or a metadata-only re-send such as a delete)
 *  updates the existing row instead of creating a second Drive file. */
function handlePhoto_(body) {
  if (!body.id) return jsonOut_({ ok: false, error: 'missing id' });

  var sheet = getSheet_(SHEET_NAMES.PHOTOS);
  var rowIndex = findRowById_(sheet, body.id);
  if (rowIndex !== -1) {
    var headers = HEADERS.Photos;
    var cur = {};
    var vals = sheet.getRange(rowIndex, 1, 1, headers.length).getValues()[0];
    headers.forEach(function (h, i) { cur[h] = vals[i]; });
    cur.updatedAt = body.updatedAt || cur.updatedAt;
    cur.deletedAt = body.deletedAt || '';
    upsertPhotoRow_(cur);
    return jsonOut_({ ok: true, id: cur.id, url: cur.url, fileId: cur.fileId });
  }
  if (!body.base64) return jsonOut_({ ok: false, error: 'missing base64' });

  var folder = getOrCreatePhotoFolder_();
  var matches = body.base64.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.*)$/);
  var mime = matches ? matches[1] : 'image/jpeg';
  var data = matches ? matches[2] : body.base64;
  var bytes = Utilities.base64Decode(data);
  var ext = mime.indexOf('png') !== -1 ? 'png' : 'jpg';
  var blob = Utilities.newBlob(bytes, mime, body.placeId + '_' + body.id + '.' + ext);

  var file = folder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  var fileId = file.getId();
  // thumbnail endpoint works as an <img src>; file.getUrl() is an HTML viewer page
  var url = 'https://drive.google.com/thumbnail?id=' + fileId + '&sz=w1024';
  upsertPhotoRow_({
    id: body.id,
    placeId: body.placeId || '',
    fileId: fileId,
    url: url,
    createdBy: body.createdBy || body.updatedBy || '',
    createdAt: body.createdAt || new Date().toISOString(),
    updatedAt: body.updatedAt || body.createdAt || new Date().toISOString(),
    deletedAt: body.deletedAt || '',
  });
  return jsonOut_({ ok: true, id: body.id, url: url, fileId: fileId });
}

function upsertPhotoRow_(rec) {
  upsertRow_(SHEET_NAMES.PHOTOS, Object.assign({}, rec, { syncedAt: new Date().toISOString() }));
}

function handleRole_(body) {
  if (!body.studentId || !body.role) return jsonOut_({ ok: false, error: 'missing studentId/role' });
  // Empty Roles sheet → the first request may only make its sender the developer (zone lead bootstrap).
  // After that, only an existing developer/coreteam may assign roles. updatedBy is client-claimed (no auth).
  var roles = readAll_(SHEET_NAMES.ROLES);
  if (roles.length === 0) {
    if (body.role !== 'developer') return jsonOut_({ ok: false, error: 'first role must be developer' });
  } else {
    var by = String(body.updatedBy || '');
    var allowed = roles.some(function (r) {
      return String(r.studentId) === by && (r.role === 'developer' || r.role === 'coreteam');
    });
    if (!allowed) return jsonOut_({ ok: false, error: 'not allowed to assign roles' });
  }
  upsertRole_({
    studentId: body.studentId,
    name: body.name || '',
    role: body.role,
    updatedAt: body.ts || new Date().toISOString(),
    syncedAt: new Date().toISOString(),
  });
  return jsonOut_({ ok: true, role: body.role, studentId: body.studentId });
}

function getOrCreatePhotoFolder_() {
  var it = DriveApp.getFoldersByName(PHOTO_FOLDER_NAME);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(PHOTO_FOLDER_NAME);
}
